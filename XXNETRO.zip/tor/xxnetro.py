#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
============================================================
 XXNETRO v1.0.0  --  DARKPIPE EDITION
------------------------------------------------------------
 Modular cyber toolkit launcher.
 Every internal resource (theme, images, sound, wordlists,
 database) is stored inside /vault in proprietary encrypted
 formats (.nxt / .nxp / .nxs). Nothing opens outside this
 launcher -- the pipes and wiring stay behind the walls.
 Authorized testing use only.
============================================================
"""
import base64
import hashlib
import json
import os
import queue
import shutil
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib
import secrets
import string as _string
import concurrent.futures
from datetime import datetime

import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk, filedialog

# ============================================================
#  VAULT LAYER  (proprietary encrypted resource formats)
# ============================================================

APP_DIR = os.path.dirname(os.path.abspath(__file__))
VAULT_DIR = os.path.join(APP_DIR, "vault")

_VMF = ["Xx", "Ne", "Tr", "O-", "Vo", "Lt", "-20", "25"]
_VMAGIC = b"NXR"
_VVER = b"\x01"
_VHEAD = 13
_VFOOT = b"NXEND"
_VTYPES = (b"T", b"P", b"S", b"B")


def _vault_key() -> bytes:
    """Rolling key assembled at runtime from scattered fragments."""
    return hashlib.sha256(("".join(_VMF)).encode("utf-8")).digest()


def _vxor(data: bytes, key: bytes) -> bytes:
    kl = len(key)
    return bytes(b ^ key[i % kl] for i, b in enumerate(data))


def vault_encode(plain: bytes, ktype: bytes = b"T") -> bytes:
    if ktype not in _VTYPES:
        raise ValueError("bad vault type")
    key = _vault_key()
    layer1 = _vxor(plain, key)
    b1 = base64.b64encode(layer1)
    layer2 = _vxor(b1, key[::-1])
    b2 = base64.b64encode(layer2)
    header = _VMAGIC + _VVER + ktype + struct.pack(
        ">II", zlib.crc32(plain) & 0xFFFFFFFF, len(plain))
    return header + b2 + _VFOOT


def vault_decode(blob: bytes):
    """-> (plain_bytes, type_str) ; raises ValueError on tamper."""
    if len(blob) < _VHEAD + len(_VFOOT) + 8:
        raise ValueError("vault: file too small")
    if blob[:3] != _VMAGIC or blob[3:4] != _VVER:
        raise ValueError("vault: bad magic")
    if not blob.endswith(_VFOOT):
        raise ValueError("vault: broken container")
    ktype = blob[4:5]
    crc, plen = struct.unpack(">II", blob[5:_VHEAD])
    body = blob[_VHEAD:-len(_VFOOT)]
    key = _vault_key()
    l1 = base64.b64decode(body)
    b1 = _vxor(l1, key[::-1])
    l0 = base64.b64decode(b1)
    plain = _vxor(l0, key)
    if len(plain) != plen:
        raise ValueError("vault: length mismatch")
    if (zlib.crc32(plain) & 0xFFFFFFFF) != crc:
        raise ValueError("vault: integrity check failed")
    return plain, ktype.decode()


def vault_read(name: str):
    with open(os.path.join(VAULT_DIR, name), "rb") as f:
        return vault_decode(f.read())


def vault_write(name: str, plain: bytes, ktype: bytes = b"T"):
    with open(os.path.join(VAULT_DIR, name), "wb") as f:
        f.write(vault_encode(plain, ktype))


# ============================================================
#  CORE CONFIG  (decrypted from vault -- never on disk plain)
# ============================================================

try:
    _core_plain, _core_type = vault_read("core.nxt")
    CORE = json.loads(_core_plain.decode("utf-8"))
except Exception as exc:  # vault missing / tampered
    print("FATAL: vault unavailable ->", exc)
    sys.exit(1)

THEME = CORE["theme"]
CFG = CORE["defaults"]
PORTS = CORE["ports"]
APP_NAME = CORE["app"]
APP_VERSION = CORE["version"]
APP_CODENAME = CORE["codename"]

if sys.platform == "win32":
    import winsound  # noqa: E402


def play_boot_sound():
    """Decode boot.nxs from vault and play it. Best effort, never crashes."""
    try:
        wav, _ = vault_read("boot.nxs")
        fd, tmp = tempfile.mkstemp(suffix=".wav")
        os.close(fd)
        with open(tmp, "wb") as f:
            f.write(wav)
        if sys.platform == "win32":
            def _w():
                try:
                    winsound.PlaySound(tmp, winsound.SND_FILENAME)
                finally:
                    try:
                        os.remove(tmp)
                    except OSError:
                        pass
            threading.Thread(target=_w, daemon=True).start()
        else:
            played = False
            for player, args in (("paplay", []), ("aplay", ["-q"]),
                                 ("ffplay", ["-nodisp", "-autoexit", "-loglevel", "quiet"])):
                exe = shutil.which(player)
                if exe:
                    try:
                        subprocess.Popen(
                            [exe] + args + [tmp],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL)
                        played = True
                        break
                    except OSError:
                        continue
            if not played:
                try:
                    os.remove(tmp)
                except OSError:
                    pass
    except Exception:
        pass


# ============================================================
#  DATA STORE  (scan database -- lives encrypted in db.nxt)
# ============================================================

class DataStore:
    """All scan results persist here, encrypted inside the vault."""

    def __init__(self):
        try:
            plain, _ = vault_read("db.nxt")
            self.data = json.loads(plain.decode("utf-8"))
        except Exception:
            self.data = {"ip_records": [], "logs": []}

    def save(self):
        try:
            vault_write("db.nxt",
                        json.dumps(self.data, indent=1).encode("utf-8"), b"B")
        except Exception:
            pass

    # -- IP records -----------------------------------------
    def add_ip_record(self, rec):
        rec["id"] = datetime.now().strftime("%H%M%S%f")
        self.data["ip_records"].insert(0, rec)
        self.data["ip_records"] = self.data["ip_records"][:400]
        self.save()

    def ip_records(self):
        return self.data["ip_records"]

    def clear_ip_records(self):
        self.data["ip_records"] = []
        self.save()

    # -- session log -----------------------------------------
    def logs(self):
        return self.data["logs"]

    def clear_logs(self):
        self.data["logs"] = []
        self.save()
    def log(self, tool, action, target, note=""):
        entry = {
            "ts": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "tool": tool,
            "action": action,
            "target": str(target)[:120],
            "note": str(note)[:120],
        }
        self.data["logs"].insert(0, entry)
        self.data["logs"] = self.data["logs"][:1000]
        self.save()


# ============================================================
#  NETWORK LAYER  (pure stdlib -- no external tools required)
# ============================================================

IPV4_RE = None  # compiled lazily


def ip_regex():
    global IPV4_RE
    if IPV4_RE is None:
        import re
        IPV4_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
    return IPV4_RE


def http_request(url, timeout=None, method="GET", headers=None, max_body=3_000_000):
    """-> dict(status, headers, body, elapsed_ms, error, url)"""
    timeout = timeout or CFG["api_timeout"]
    h = {"User-Agent": CFG["user_agent"],
         "Accept": "*/*",
         "Connection": "close"}
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, headers=h, method=method)
    t0 = time.perf_counter()
    status, rheaders, body, err = None, {}, b"", None
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            status = r.status
            rheaders = {k.lower(): v for k, v in r.headers.items()}
            body = r.read(max_body)
    except urllib.error.HTTPError as e:
        status = e.code
        rheaders = {k.lower(): v for k, v in e.headers.items()} if e.headers else {}
        try:
            body = e.read(max_body)
        except Exception:
            body = b""
    except Exception as e:
        err = str(e) or e.__class__.__name__
    return {
        "status": status,
        "headers": rheaders,
        "body": body,
        "elapsed_ms": int((time.perf_counter() - t0) * 1000),
        "error": err,
        "url": url,
    }


def api_json(url, timeout=None):
    r = http_request(url, timeout=timeout)
    if r["error"] and not r["status"]:
        raise RuntimeError(r["error"])
    try:
        return json.loads(r["body"].decode("utf-8", "replace"))
    except Exception:
        raise RuntimeError("bad API response")


def resolve_host(host):
    """-> list of ip strings"""
    infos = socket.getaddrinfo(host.strip(), None, socket.AF_INET)
    out, seen = [], set()
    for inf in infos:
        ip = inf[4][0]
        if ip not in seen:
            seen.add(ip)
            out.append(ip)
    return out


def ip_info(query, deep=False):
    """IP/domain intelligence via public API (no key needed)."""
    if deep:
        fields = ("status,message,country,countryCode,region,regionName,city,"
                  "district,zip,lat,lon,timezone,offset,currency,isp,org,as,"
                  "asname,reverse,mobile,proxy,hosting,query")
    else:
        fields = ("status,message,country,countryCode,regionName,city,"
                  "timezone,isp,org,as,lat,lon,query")
    data = api_json("http://ip-api.com/json/{}?fields={}".format(
        urllib.parse.quote(str(query)), fields))
    if deep and data.get("status") == "success":
        try:
            socket.gethostbyaddr(data["query"])
        except Exception:
            pass
    return data


def mac_vendor(mac):
    """Vendor lookup for a MAC address (rate limited upstream, 1 req/sec)."""
    mac = mac.replace(":", "").replace("-", "").replace(".", "").strip().upper()
    if len(mac) < 6 or not all(c in "0123456789ABCDEF" for c in mac[:6]):
        raise ValueError("invalid MAC address")
    prefix = mac[:6]
    r = http_request("https://api.macvendors.com/" + prefix, timeout=6)
    if r["status"] == 200 and r["body"]:
        return r["body"].decode("utf-8", "replace").strip()
    if r["status"] == 404:
        return "UNKNOWN VENDOR"
    raise RuntimeError(r["error"] or ("HTTP " + str(r["status"])))


def tcp_probe(host, port, timeout=None, banner_wait=0.9, http_probe=False):
    """Single TCP connect. Returns dict(ok, latency_ms, banner)."""
    timeout = timeout or CFG["scan_timeout"]
    out = {"port": port, "ok": False, "latency_ms": None, "banner": ""}
    t0 = time.perf_counter()
    sock = None
    try:
        sock = socket.create_connection((host, port), timeout=timeout)
        out["ok"] = True
        out["latency_ms"] = int((time.perf_counter() - t0) * 1000)
        sock.settimeout(banner_wait)
        try:
            chunk = sock.recv(512)
            out["banner"] = chunk.decode("utf-8", "replace").strip()
        except Exception:
            pass
        if http_probe and not out["banner"]:
            try:
                sock.sendall(("GET / HTTP/1.1\r\nHost: {}\r\n"
                              "User-Agent: {}\r\nConnection: close\r\n\r\n"
                              ).format(host, CFG["user_agent"]).encode())
                chunk = sock.recv(512)
                out["banner"] = chunk.decode("utf-8", "replace").strip()
            except Exception:
                pass
    except Exception:
        out["ok"] = False
    finally:
        if sock:
            try:
                sock.close()
            except Exception:
                pass
    return out


def scan_ports(host, ports, timeout=None, workers=64, stop=None, progress=None):
    """Threaded TCP port scan with service names + banner grabbing.
    -> list of open-port dicts sorted by port."""
    results = []
    total = len(ports)
    done = [0]
    lock = threading.Lock()

    def work(port):
        if stop is not None and stop.is_set():
            return None
        probe = tcp_probe(host, port, timeout=timeout)
        with lock:
            done[0] += 1
            if progress is not None and done[0] % 5 == 0:
                progress(done[0], total)
        if probe["ok"]:
            return {
                "port": port,
                "service": PORTS.get(str(port), "unknown"),
                "latency_ms": probe["latency_ms"],
                "banner": probe["banner"][:200],
            }
        return None

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futs = [pool.submit(work, p) for p in ports]
        for f in concurrent.futures.as_completed(futs):
            if stop is not None and stop.is_set():
                break
            r = f.result()
            if r:
                results.append(r)
    results.sort(key=lambda d: d["port"])
    return results


def port_list(preset, custom=None):
    """Build the port list from a preset name."""
    common = [21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 161, 389, 443,
              445, 465, 587, 631, 636, 993, 995, 1433, 1521, 2049, 3306, 3389,
              5432, 5900, 6379, 8080, 8443, 9200, 27017]
    wide = common + [20, 23, 67, 69, 79, 88, 113, 123, 138, 144, 162, 179,
                     514, 515, 548, 554, 1080, 1723, 1883, 2082, 2083, 2181,
                     3128, 3268, 4444, 5000, 5555, 5672, 5984, 6667, 8000,
                     8008, 8081, 8888, 9000, 9090, 11211, 32768, 49152, 6443]
    if preset == "QUICK (32 PORTS)":
        return common
    if preset == "STANDARD (80 PORTS)":
        return wide
    if preset == "FULL (1-1024)":
        return list(range(1, 1025))
    if preset == "CUSTOM" and custom:
        ports = set()
        for part in str(custom).split(","):
            part = part.strip()
            if not part:
                continue
            if "-" in part:
                a, b = part.split("-", 1)
                ports.update(range(int(a), int(b) + 1))
            else:
                ports.add(int(part))
        return sorted(p for p in ports if 0 < p < 65536)
    return common


# ------------------------------------------------------------
#  WHOIS (raw socket, port 43, iana referral)
# ------------------------------------------------------------

def whois_query(server, query, timeout=8):
    s = socket.create_connection((server, 43), timeout=timeout)
    try:
        s.sendall((query + "\r\n").encode())
        chunks = []
        s.settimeout(timeout)
        while True:
            try:
                chunk = s.recv(4096)
            except socket.timeout:
                break
            if not chunk:
                break
            chunks.append(chunk)
        return b"".join(chunks).decode("utf-8", "replace")
    finally:
        s.close()


def whois(domain, timeout=8):
    domain = domain.strip().lower()
    if "/" in domain or "@" in domain:
        raise ValueError("not a domain name")
    first = whois_query("whois.iana.org", domain, timeout)
    for line in first.splitlines():
        low = line.strip().lower()
        if low.startswith("refer:") or low.startswith("whois:") or low.startswith("registrar whois server:"):
            server = line.split(":", 1)[1].strip()
            if server:
                try:
                    return whois_query(server, domain, timeout), server
                except Exception:
                    pass
    return first, "whois.iana.org"


# ------------------------------------------------------------
#  RAW DNS RESOLVER (UDP -- A/AAAA/MX/NS/TXT/CNAME/SOA)
# ------------------------------------------------------------

QTYPE = {"A": 1, "NS": 2, "CNAME": 5, "SOA": 6, "MX": 15, "TXT": 16, "AAAA": 28}
RTYPE = {v: k for k, v in QTYPE.items()}
RESOLVERS = ["8.8.8.8", "1.1.1.1", "9.9.9.9"]


def _enc_name(name):
    out = b""
    for part in name.strip(".").split("."):
        if part:
            b = part.encode("idna") if any(ord(c) > 127 for c in part) else part.encode()
            out += bytes([len(b)]) + b
    return out + b"\x00"


def _dns_packet(name, qtype):
    ident = secrets.randbits(16)
    header = struct.pack(">HHHHHH", ident, 0x0100, 1, 0, 0, 0)
    return ident, header + _enc_name(name) + struct.pack(">HH", qtype, 1)


def _read_name(data, off):
    labels, jumped = [], False
    orig = off
    while True:
        if off >= len(data):
            raise ValueError("dns: truncated")
        ln = data[off]
        if ln == 0:
            off += 1
            break
        if ln & 0xC0 == 0xC0:
            ptr = struct.unpack(">H", data[off:off + 2])[0] & 0x3FFF
            if not jumped:
                orig = off + 2
            off = ptr
            jumped = True
            continue
        labels.append(data[off + 1:off + 1 + ln].decode("utf-8", "replace"))
        off += 1 + ln
    name = ".".join(labels) if labels else "."
    return name, (orig if jumped else off)


def dns_lookup(name, rtype="A", timeout=4, resolver=None):
    """-> list of record value strings"""
    qtype = QTYPE[rtype.upper()]
    name = name.strip().rstrip(".")
    servers = [resolver] if resolver else RESOLVERS
    last_err = None
    for srv in servers:
        try:
            ident, pkt = _dns_packet(name, qtype)
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(timeout)
            s.sendto(pkt, (srv, 53))
            data, _ = s.recvfrom(4096)
            s.close()
            if len(data) < 12 or struct.unpack(">H", data[:2])[0] != ident:
                continue
            flags = struct.unpack(">H", data[2:4])[0]
            rcode = flags & 0x0F
            qd, an = struct.unpack(">HH", data[4:8])
            off = 12
            for _ in range(qd):
                _, off = _read_name(data, off)
                off += 4
            values = []
            for _ in range(an):
                _, off = _read_name(data, off)
                rtype_n, _, _, rdlen = struct.unpack(">HHIH", data[off:off + 10])
                off += 10
                rd = data[off:off + rdlen]
                if rcode == 3:  # NXDOMAIN
                    return ["NXDOMAIN"]
                if rtype_n == 1 and len(rd) == 4:
                    values.append(socket.inet_ntoa(rd))
                elif rtype_n == 28 and len(rd) == 16:
                    values.append(socket.inet_ntop(socket.AF_INET6, rd))
                elif rtype_n in (2, 5, 12):
                    target, _ = _read_name(data, off)
                    values.append(target)
                elif rtype_n == 15 and len(rd) >= 3:
                    pref = struct.unpack(">H", rd[:2])[0]
                    host, _ = _read_name(data, off + 2)
                    values.append("{} {}".format(pref, host))
                elif rtype_n == 16:
                    parts, p = [], 0
                    while p < len(rd):
                        ln = rd[p]
                        parts.append(rd[p + 1:p + 1 + ln].decode("utf-8", "replace"))
                        p += 1 + ln
                    values.append(" ".join(parts))
                elif rtype_n == 6:
                    mname, o1 = _read_name(data, off)
                    rname, _ = _read_name(data, o1)
                    values.append("{} {}".format(mname, rname))
                off += rdlen
            if values:
                return values
            if rcode == 0:
                return []
        except Exception as e:
            last_err = e
            continue
    if last_err:
        raise RuntimeError("DNS failed: {}".format(last_err))
    return []


def subdomain_scan(domain, prefixes, workers=24, stop=None):
    """Resolve candidate subdomains. -> list of (subdomain, ip)"""
    found = []

    def work(prefix):
        if stop is not None and stop.is_set():
            return None
        host = "{}.{}".format(prefix.strip(), domain)
        try:
            ip = socket.gethostbyname(host)
            return (host, ip)
        except Exception:
            return None

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futs = [pool.submit(work, p) for p in prefixes]
        for f in concurrent.futures.as_completed(futs):
            if stop is not None and stop.is_set():
                break
            r = f.result()
            if r:
                found.append(r)
    found.sort(key=lambda t: t[0])
    return found


# ------------------------------------------------------------
#  UTILITIES: hash / encoders / password / ping
# ------------------------------------------------------------

def hash_compute(text, algo):
    h = hashlib.new(algo)
    h.update(text.encode("utf-8"))
    return h.hexdigest()


HASH_LEN_MAP = {
    32: ["MD5", "NTLM", "MD4", "LM"],
    40: ["SHA-1", "MySQL5"],
    56: ["SHA-224", "SHA3-224"],
    64: ["SHA-256", "SHA3-256", "BLAKE2s"],
    96: ["SHA-384", "SHA3-384"],
    128: ["SHA-512", "SHA3-512", "BLAKE2b", "Whirlpool"],
}


def hash_identify(value):
    v = value.strip().lower()
    if not v:
        return []
    if not all(c in "0123456789abcdef" for c in v):
        return []
    if "$" in value:
        if value.startswith("$2"):
            return ["bcrypt"]
        if value.startswith("$6$"):
            return ["sha512crypt"]
        if value.startswith("$5$"):
            return ["sha256crypt"]
        if value.startswith("$1$"):
            return ["md5crypt"]
        return ["salted hash (crypt format)"]
    return HASH_LEN_MAP.get(len(v), ["UNKNOWN LENGTH {}".format(len(v))])


def enc_transform(text, method, mode):
    if method == "BASE64":
        if mode == "ENCODE":
            return base64.b64encode(text.encode("utf-8")).decode("ascii")
        pad = "=" * (-len(text.strip()) % 4)
        return base64.b64decode(text.strip() + pad).decode("utf-8", "replace")
    if method == "HEX":
        if mode == "ENCODE":
            return text.encode("utf-8").hex()
        return bytes.fromhex(text.strip()).decode("utf-8", "replace")
    if method == "URL":
        if mode == "ENCODE":
            return urllib.parse.quote(text, safe="")
        return urllib.parse.unquote(text)
    if method == "ROT13":
        return text.encode("utf-8").decode("rot13") if False else _rot13(text)
    raise ValueError("unknown method")


def _rot13(text):
    out = []
    for ch in text:
        o = ord(ch)
        if 65 <= o <= 90:
            out.append(chr((o - 65 + 13) % 26 + 65))
        elif 97 <= o <= 122:
            out.append(chr((o - 97 + 13) % 26 + 97))
        else:
            out.append(ch)
    return "".join(out)


PASS_SETS = {
    "lowercase": _string.ascii_lowercase,
    "uppercase": _string.ascii_uppercase,
    "digits": _string.digits,
    "symbols": "!@#$%^&*()-_=+[]{}<>?/",
}


def password_generate(length=16, sets=("lowercase", "uppercase", "digits", "symbols")):
    pool = "".join(PASS_SETS[s] for s in sets if s in PASS_SETS)
    if not pool:
        raise ValueError("select at least one character set")
    while True:
        pwd = "".join(secrets.choice(pool) for _ in range(length))
        if all(any(c in PASS_SETS[s] for c in pwd) for s in sets):
            return pwd, len(pool)


def entropy_bits(length, pool_size):
    if pool_size <= 1:
        return 0.0
    import math
    return length * math.log2(pool_size)


# ============================================================
#  UI PRIMITIVES  (neon / cut-corner design system)
# ============================================================

def pick_font(candidates, fallback):
    try:
        families = set(tkfont.families())
        for c in candidates:
            if c in families:
                return c
    except Exception:
        pass
    return fallback


def cut_pts(w, h, c=9):
    """Polygon points for a box with 45-degree cut corners."""
    return (c, 0, w - c, 0, w, c, w, h - c, w - c, h, c, h, 0, h - c, 0, c)


class NeonButton(tk.Canvas):
    """Cut-corner button with neon outline + hover glow."""

    def __init__(self, master, text, command=None, width=150, height=34,
                 cut=8, font=None, accent=None, text_color=None,
                 fill=None, dim=None, glow=None, **kw):
        try:
            base_bg = master.cget("bg")
        except Exception:
            base_bg = THEME["bg"]
        super().__init__(master, width=width, height=height, bg=base_bg,
                         highlightthickness=0, bd=0, **kw)
        self.cmd = command
        self.accent = accent or THEME["accent"]
        self.dim = dim or THEME["accent_dim"]
        self.glow = glow or THEME["glow"]
        self.text_color = text_color or THEME["text"]
        self.fill = fill or THEME["panel2"]
        self.enabled = True
        pts = cut_pts(width, height, cut)
        self._poly = self.create_polygon(pts, fill=self.fill,
                                         outline=self.dim, width=1)
        self._txt = self.create_text(width // 2, height // 2, text=text,
                                     fill=self.text_color,
                                     font=font or (APP_NAME, 10, "bold"),
                                     justify="center")
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<Button-1>", self._on_click)
        self.bind("<ButtonRelease-1>", self._on_release)

    def _on_enter(self, _):
        if self.enabled:
            self.itemconfig(self._poly, outline=self.accent, width=2)
            self.itemconfig(self._txt, fill=self.glow)
            self.config(cursor="hand2")

    def _on_leave(self, _):
        self.itemconfig(self._poly, outline=self.dim, width=1)
        self.itemconfig(self._txt, fill=self.text_color)

    def _on_click(self, _):
        if self.enabled:
            self.itemconfig(self._poly, fill=self.dim)

    def _on_release(self, _):
        if self.enabled:
            self.itemconfig(self._poly, fill=self.fill)
            if self.cmd:
                self.cmd()

    def set_enabled(self, enabled):
        self.enabled = enabled
        if not enabled:
            self.itemconfig(self._txt, fill=THEME["dim"])
            self.itemconfig(self._poly, outline=self.dim)
        else:
            self.itemconfig(self._txt, fill=self.text_color)


class CutPanel(tk.Canvas):
    """A panel with cut corners; child widgets placed via .put()."""

    def __init__(self, master, width, height, bg=None, outline=None,
                 cut=12, outline_w=1, **kw):
        try:
            base_bg = master.cget("bg")
        except Exception:
            base_bg = THEME["bg"]
        super().__init__(master, width=width, height=height, bg=base_bg,
                         highlightthickness=0, bd=0, **kw)
        self._cut = cut
        self._poly = self.create_polygon(cut_pts(width, height, cut),
                                         fill=bg or THEME["panel"],
                                         outline=outline or THEME["accent_dim"],
                                         width=outline_w)

    def put(self, widget, x, y, anchor="nw"):
        return self.create_window(x, y, window=widget, anchor=anchor)

    def set_outline(self, color):
        self.itemconfig(self._poly, outline=color)


class ScrollFrame(tk.Frame):
    """Vertical-scrollable frame (canvas trick)."""

    def __init__(self, master, bg=None, width=260, height=400):
        super().__init__(master, bg=bg or THEME["panel"], width=width,
                         height=height, highlightthickness=0)
        self.canvas = tk.Canvas(self, bg=bg or THEME["panel"],
                                highlightthickness=0, bd=0,
                                width=width, height=height)
        self.vsb = ttk.Scrollbar(self, orient="vertical",
                                 command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.vsb.set)
        self.vsb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.inner = tk.Frame(self.canvas, bg=bg or THEME["panel"])
        self._win = self.canvas.create_window((0, 0), window=self.inner,
                                              anchor="nw")
        self.inner.bind("<Configure>", self._on_inner_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)
        self.canvas.bind("<Enter>", self._bind_wheel)
        self.canvas.bind("<Leave>", self._unbind_wheel)

    def _on_inner_configure(self, _):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas_configure(self, event):
        self.canvas.itemconfig(self._win, width=event.width)

    def _wheel(self, event):
        delta = -1 if getattr(event, "delta", 0) > 0 or event.num == 4 else 1
        self.canvas.yview_scroll(delta, "units")

    def _bind_wheel(self, _):
        self.canvas.bind_all("<MouseWheel>", self._wheel)
        self.canvas.bind_all("<Button-4>", self._wheel)
        self.canvas.bind_all("<Button-5>", self._wheel)

    def _unbind_wheel(self, _):
        self.canvas.unbind_all("<MouseWheel>")
        self.canvas.unbind_all("<Button-4>")
        self.canvas.unbind_all("<Button-5>")


class ResultCard(tk.Frame):
    """Draggable result card: header bar (drag/open) + info grid."""

    def __init__(self, desk, app, rec):
        super().__init__(desk, bg=THEME["panel2"], highlightthickness=1,
                         highlightbackground=THEME["accent"], bd=0)
        self.desk = desk
        self.app = app
        self.rec = rec
        self.wid = None
        self.width = 312
        header = tk.Frame(self, bg=THEME["panel3"], height=30)
        header.pack(fill="x")
        header.pack_propagate(False)
        self.title = tk.Label(header, text=str(rec.get("ip", "?")),
                              bg=THEME["panel3"], fg=THEME["glow"],
                              font=(app.f_mono, 11, "bold"))
        self.title.pack(side="left", padx=10)
        mode = rec.get("mode", "SINGLE")
        tag_color = {"SINGLE": THEME["accent"], "DEEP": THEME["ok"],
                     "FILE": THEME["warn"]}.get(mode, THEME["accent"])
        tk.Label(header, text=mode, bg=THEME["panel3"], fg=tag_color,
                 font=(app.f_mono, 8, "bold")).pack(side="left", padx=6)
        close_lbl = tk.Label(header, text="[X]", bg=THEME["panel3"],
                             fg=THEME["dim"], font=(app.f_mono, 9, "bold"),
                             cursor="hand2")
        close_lbl.pack(side="right", padx=8)
        close_lbl.bind("<Button-1>", lambda e: desk.remove_card(self))

        body = tk.Frame(self, bg=THEME["panel2"])
        body.pack(fill="both", expand=True, padx=8, pady=(6, 2))
        rows = rec.get("rows", [])
        for i, (k, v) in enumerate(rows[:14]):
            tk.Label(body, text=k.upper(), bg=THEME["panel2"], fg=THEME["dim"],
                     font=(app.f_mono, 8, "bold"), anchor="w").grid(
                row=i, column=0, sticky="w", padx=(2, 10), pady=1)
            tk.Label(body, text=str(v)[:34], bg=THEME["panel2"],
                     fg=THEME["text"], font=(app.f_mono, 8), anchor="w").grid(
                row=i, column=1, sticky="w", pady=1)
        foot = tk.Frame(self, bg=THEME["panel2"])
        foot.pack(fill="x", pady=(2, 6), padx=8)
        if rec.get("mode") != "DEEP":
            b1 = tk.Label(foot, text="[ DEEP INFO ]", bg=THEME["panel2"],
                          fg=THEME["accent"], font=(app.f_mono, 8, "bold"),
                          cursor="hand2")
            b1.pack(side="left", padx=(2, 8))
            b1.bind("<Button-1>", lambda e: app.open_ip_record(rec, deep=True))
        ts = rec.get("saved_at", "")
        tk.Label(foot, text=ts, bg=THEME["panel2"], fg=THEME["dim"],
                 font=(app.f_mono, 7)).pack(side="right")
        self._bind_drag(header)
        self._bind_drag(self.title)
        header.bind("<Double-Button-1>", lambda e: app.open_ip_record(rec))

    # -- drag mechanics (header = titlebar) -------------------
    def _bind_drag(self, widget):
        widget.bind("<Button-1>", self._press, add="+")
        widget.bind("<B1-Motion>", self._motion, add="+")
        widget.bind("<ButtonRelease-1>", self._release, add="+")

    def _press(self, event):
        if self.wid is None:
            return
        x, y = self.desk.coords(self.wid)
        self._drag = {"px": event.x_root, "py": event.y_root,
                      "cx": x, "cy": y, "moved": False}

    def _motion(self, event):
        d = getattr(self, "_drag", None)
        if not d:
            return
        dx, dy = event.x_root - d["px"], event.y_root - d["py"]
        if abs(dx) + abs(dy) > 4:
            d["moved"] = True
        self.desk.coords(self.wid, d["cx"] + dx, d["cy"] + dy)

    def _release(self, event):
        d = getattr(self, "_drag", None)
        if d and not d["moved"]:
            self.app.open_ip_record(self.rec)
        self._drag = None


class Desk(tk.Canvas):
    """Workspace canvas where result cards float and drag."""

    def __init__(self, master, app):
        super().__init__(master, bg=THEME["bg"], highlightthickness=0, bd=0)
        self.app = app
        self.cards = {}
        self.bind("<Configure>", lambda e: self._draw_grid())

    def _draw_grid(self):
        self.delete("grid")
        w = max(self.winfo_width(), 400)
        h = max(self.winfo_height(), 300)
        for x in range(0, w, 46):
            self.create_line(x, 0, x, h, fill=THEME["accent_dim"],
                             dash=(1, 7), tags="grid")
        for y in range(0, h, 46):
            self.create_line(0, y, w, y, fill=THEME["accent_dim"],
                             dash=(1, 7), tags="grid")
        self.tag_lower("grid")

    def add_card(self, rec, x=24, y=24, cascade=True):
        rid = rec.get("id")
        if rid:
            for wid, c in self.cards.items():
                if c.rec.get("id") == rid:
                    self.coords(wid, 24, 24)
                    self.tag_raise(wid)
                    return c
        n = len(self.cards)
        if cascade:
            x = 24 + (n % 7) * 36
            y = 24 + (n // 7) * 46
        card = ResultCard(self, self.app, rec)
        card.wid = self.create_window(x, y, window=card, anchor="nw")
        self.cards[card.wid] = card
        self.tag_raise(card.wid)
        return card

    def remove_card(self, card):
        for wid, c in list(self.cards.items()):
            if c is card:
                del self.cards[wid]
                self.delete(wid)
                card.destroy()
                return

    def clear(self):
        for wid, c in list(self.cards.items()):
            self.delete(wid)
            c.destroy()
        self.cards = {}


# ============================================================
#  SPLASH  (boot sequence: logo, vault decryption, sound)
# ============================================================

class Splash(tk.Toplevel):

    def __init__(self, app, on_done):
        super().__init__(app, bg="#05030a")
        self.overrideredirect(True)
        self.on_done = on_done
        W, H = 560, 690
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry("{}x{}+{}+{}".format(W, H, (sw - W) // 2, (sh - H) // 2))
        self.attributes("-topmost", True)

        c = tk.Canvas(self, width=W, height=H, bg="#05030a",
                      highlightthickness=0)
        c.pack(fill="both", expand=True)

        # outer frame
        c.create_polygon(cut_pts(W - 24, H - 24, 16), fill="",
                         outline=THEME["accent_dim"], width=1)

        # logo (square, dead center top)
        c.create_image(W // 2, 150, image=app.assets.logo_splash)

        # glowing brand text (layered)
        ty = 300
        for ox, oy, col in ((3, 0, THEME["accent2"]), (-3, 0, THEME["accent2"]),
                            (0, 3, THEME["accent2"]), (0, -3, THEME["accent2"])):
            c.create_text(W // 2 + ox, ty + oy, text=APP_NAME,
                          fill=col, font=(app.f_ui, 40, "bold"))
        self._brand_glow = c.create_text(W // 2, ty, text=APP_NAME,
                                         fill=THEME["glow"],
                                         font=(app.f_ui, 40, "bold"))
        c.create_text(W // 2, ty + 38, text="DARKPIPE EDITION // v" + APP_VERSION,
                      fill=THEME["dim"], font=(app.f_mono, 10))

        # anonymous image under the brand name
        c.create_image(W // 2, 452, image=app.assets.mask_splash)
        c.create_text(W // 2, 530, text="ANONYMOUS ACCESS MODULE",
                      fill=THEME["accent"], font=(app.f_mono, 9, "bold"))

        # progress bar (cut-corner frame, fill grows from left)
        bx, by, bw, bh = 110, 588, 340, 14
        _bp = cut_pts(bw, bh, 5)
        c.create_polygon([(bx + _bp[i], by + _bp[i + 1])
                          for i in range(0, len(_bp), 2)],
                         fill=THEME["panel2"], outline=THEME["accent_dim"])
        self._bar_cv = c
        self._bar_x, self._bar_y = bx, by
        self._bar_w, self._bar_h = bw, bh

        self._status = c.create_text(W // 2, 634, text="DECRYPTING VAULT...",
                                     fill=THEME["accent"],
                                     font=(app.f_mono, 10, "bold"))
        c.create_text(W // 2, 660, text="AUTHORIZED USE ONLY",
                      fill=THEME["dim"], font=(app.f_mono, 8))

        # boot timeline
        lines = CORE["boot_lines"]
        times = [300, 750, 1250, 1800, 2350, 2900]
        for i, line in enumerate(lines):
            frac = (i + 1) / len(lines)
            self.after(times[i], lambda f=frac, s=line:
                       self._step(f, s))
        self._pulse_state = 0
        self._pulse()
        self.after(150, play_boot_sound)
        self.after(3450, self._finish)

    def _pulse(self):
        self._pulse_state = 1 - self._pulse_state
        col = THEME["glow"] if self._pulse_state else THEME["accent"]
        try:
            self._bar_cv.itemconfig(self._brand_glow, fill=col)
        except Exception:
            return
        self.after(420, self._pulse)

    def _step(self, frac, status):
        self._bar_cv.delete("barfill")
        self._bar_cv.create_rectangle(
            self._bar_x + 2, self._bar_y + 2,
            self._bar_x + 2 + int((self._bar_w - 4) * frac),
            self._bar_y + self._bar_h - 2,
            fill=THEME["accent"], width=0, tags="barfill")
        self._bar_cv.itemconfig(self._status, text=status + " ...")

    def _finish(self):
        try:
            self.on_done()
        finally:
            self.destroy()


# ============================================================
#  APPLICATION SHELL
# ============================================================

MENU = [
    ("ip",   "01", "IP SCANNER",     "IP SCANNER",       "SINGLE / FILE BATCH / DEEP INFO"),
    ("nmap", "02", "NMAP SCAN",      "NMAP SCAN",        "PORTS / SERVICES / LATENCY / ISP"),
    ("fuzz", "03", "FUZZER",         "PATH FUZZER",      "DIRECTORY GUESS // site.com/admin"),
    ("dns",  "04", "DNS / WHOIS",    "DNS / WHOIS",      "RECORDS + REGISTRY DATA"),
    ("subd", "05", "SUBDOMAINS",     "SUBDOMAIN FINDER", "DNS BRUTE RESOLUTION"),
    ("head", "06", "HEADERS",        "HEADER ANALYZER",  "RESPONSE + SECURITY AUDIT"),
    ("bann", "07", "BANNER GRAB",    "BANNER GRABBER",   "RAW SERVICE IDENTIFICATION"),
    ("hash", "08", "HASH TOOLS",     "HASH TOOLS",       "GENERATE / IDENTIFY"),
    ("enc",  "09", "ENCODER",        "ENCODER / DECODER","BASE64 / HEX / URL / ROT13"),
    ("mac",  "10", "MAC VENDOR",     "MAC VENDOR",       "OUI VENDOR LOOKUP"),
    ("ping", "11", "PING MONITOR",   "PING MONITOR",     "LIVE LATENCY TRACKING"),
    ("pgen", "12", "PASS GEN",       "PASSWORD GENERATOR", "CRYPTO-STRENGTH"),
    ("log",  "13", "SESSION LOG",    "SESSION LOG",      "FULL OPERATION HISTORY"),
]


class Assets:
    """Every image is decoded from the encrypted vault, memory only."""

    def __init__(self, root):
        def img(name):
            # GIF payload loads on every Tk build (8.6 / 9.x)
            raw, _ = vault_read(name)
            return tk.PhotoImage(
                data=base64.b64encode(raw).decode("ascii"))

        self.logo_full = img("logo.nxp")                    # 1024x1024
        self.logo_splash = self.logo_full.subsample(5)      # ~205px
        self.logo_side = self.logo_full.subsample(16)       # 64px
        self.mask_full = img("mask.nxp")
        self.mask_splash = self.mask_full.subsample(8)      # 128px
        self.bg_full = img("bg.nxp")                        # 1344x768


class App(tk.Tk):

    def __init__(self):
        super().__init__()
        self.withdraw()
        self.title(APP_NAME + " // " + APP_CODENAME + " v" + APP_VERSION)
        self.configure(bg=THEME["bg"])
        self.f_mono = pick_font(
            ["Cascadia Mono", "Consolas", "JetBrains Mono",
             "DejaVu Sans Mono", "Menlo"], "Courier")
        self.f_ui = pick_font(
            ["Segoe UI", "Helvetica Neue", "Arial"], "Helvetica")
        self.assets = Assets(self)
        self.store = DataStore()
        self.q = queue.Queue()
        self.pages = {}
        self.menu_buttons = {}
        self.current = None
        self.online = None
        self._setup_styles()
        self.after(90, self._poll)

    # ---- thread -> UI bridge --------------------------------
    def run_async(self, fn, on_done, on_error=None):
        def worker():
            try:
                res = fn()
                self.q.put(("ok", on_done, res))
            except Exception as e:
                self.q.put(("err", on_error, e))
        threading.Thread(target=worker, daemon=True).start()

    def _poll(self):
        try:
            while True:
                kind, cb, val = self.q.get_nowait()
                if kind == "ok" and cb:
                    cb(val)
                elif kind == "err":
                    if cb:
                        cb(val)
                    else:
                        self.default_error(val)
        except queue.Empty:
            pass
        self.after(90, self._poll)

    def default_error(self, e):
        self.hstatus.config(text="ERR: " + str(e)[:64], fg=THEME["bad"])
        self.after(6000, lambda: self._reset_hstatus())

    def _reset_hstatus(self):
        try:
            self.hstatus.config(text="STANDBY", fg=THEME["dim"])
        except Exception:
            pass

    # ---- boot -----------------------------------------------
    def start_splash(self):
        Splash(self, self._enter_main)

    def _enter_main(self):
        self.build_main()
        self.deiconify()
        self._check_online()

    def _check_online(self):
        def fn():
            r = http_request("http://ip-api.com/json/?fields=status", timeout=6)
            return r["status"] == 200
        self.run_async(fn, self._set_online)

    def _set_online(self, ok):
        self.online = bool(ok)
        col = THEME["ok"] if ok else THEME["warn"]
        try:
            self.dot.itemconfig(self._dot_item, fill=col)
        except Exception:
            pass
        self.netlbl.config(text="ONLINE" if ok else "OFFLINE", fg=col)
        self.hstatus.config(text="LINK " + ("ACTIVE" if ok else "DEGRADED"),
                            fg=col)
        self.after(6000, self._reset_hstatus)

    # ---- styles ---------------------------------------------
    def _setup_styles(self):
        st = ttk.Style(self)
        try:
            st.theme_use("clam")
        except Exception:
            pass
        st.configure("Treeview",
                     background=THEME["panel2"],
                     fieldbackground=THEME["panel2"],
                     foreground=THEME["text"],
                     rowheight=24,
                     bordercolor=THEME["accent_dim"],
                     borderwidth=1,
                     font=(self.f_mono, 9))
        st.configure("Treeview.Heading",
                     background=THEME["panel3"],
                     foreground=THEME["accent"],
                     font=(self.f_mono, 9, "bold"),
                     borderwidth=0)
        st.map("Treeview",
               background=[("selected", THEME["accent_dim"])],
               foreground=[("selected", THEME["glow"])])
        st.configure("TScrollbar",
                     background=THEME["panel3"],
                     troughcolor=THEME["bg"],
                     bordercolor=THEME["accent_dim"],
                     arrowcolor=THEME["accent"])
        st.configure("TCombobox",
                     fieldbackground=THEME["panel2"],
                     background=THEME["panel3"],
                     foreground=THEME["text"],
                     arrowcolor=THEME["accent"],
                     bordercolor=THEME["accent_dim"],
                     lightcolor=THEME["panel2"],
                     darkcolor=THEME["panel2"])
        st.map("TCombobox",
               fieldbackground=[("readonly", THEME["panel2"])],
               foreground=[("readonly", THEME["text"])])
        st.configure("Horizontal.TProgressbar",
                     background=THEME["accent"],
                     troughcolor=THEME["panel2"],
                     bordercolor=THEME["accent_dim"],
                     thickness=10)
        self.option_add("*TCombobox*Listbox.background", THEME["panel2"])
        self.option_add("*TCombobox*Listbox.foreground", THEME["text"])
        self.option_add("*TCombobox*Listbox.selectBackground",
                        THEME["accent_dim"])
        self.option_add("*TCombobox*Listbox.selectForeground", THEME["glow"])

    # ---- main window ----------------------------------------
    def build_main(self):
        W, H = 1280, 800
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry("{}x{}+{}+{}".format(W, H, (sw - W) // 2, (sh - H) // 2))
        self.minsize(1120, 700)

        bg = tk.Label(self, image=self.assets.bg_full, bd=0)
        bg.place(relx=0.5, rely=0.5, anchor="center")

        # --- sidebar ---
        self.sidebar = tk.Frame(self, bg=THEME["panel"], width=232,
                                highlightthickness=1,
                                highlightbackground=THEME["accent_dim"])
        self.sidebar.place(x=10, y=10, width=232, relheight=1.0, height=-20)
        self.sidebar.pack_propagate(False)

        top = tk.Frame(self.sidebar, bg=THEME["panel"])
        top.pack(fill="x", pady=(16, 10), padx=14)
        tk.Label(top, image=self.assets.logo_side,
                 bg=THEME["panel"]).pack(side="left")
        tbox = tk.Frame(top, bg=THEME["panel"])
        tbox.pack(side="left", padx=10)
        tk.Label(tbox, text=APP_NAME, bg=THEME["panel"], fg=THEME["glow"],
                 font=(self.f_ui, 16, "bold")).pack(anchor="w")
        tk.Label(tbox, text=APP_CODENAME + " v" + APP_VERSION,
                 bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.f_mono, 8)).pack(anchor="w")

        menu = tk.Frame(self.sidebar, bg=THEME["panel"])
        menu.pack(fill="both", expand=True, pady=(4, 0))
        for key, num, label, _t, _s in MENU:
            btn = NeonButton(menu, num + "   " + label, width=206, height=32,
                             font=(self.f_mono, 9, "bold"),
                             command=lambda k=key: self.show_tool(k))
            btn.pack(pady=2, padx=13, anchor="w")
            self.menu_buttons[key] = btn

        foot = tk.Frame(self.sidebar, bg=THEME["panel"])
        foot.pack(fill="x", pady=10, padx=16)
        tk.Label(foot, text="VAULT : LOCKED", bg=THEME["panel"],
                 fg=THEME["ok"], font=(self.f_mono, 8, "bold")).pack(anchor="w")
        tk.Label(foot, text="PIPELINE : ENCRYPTED", bg=THEME["panel"],
                 fg=THEME["dim"], font=(self.f_mono, 8)).pack(anchor="w")
        tk.Label(foot, text="AUTHORIZED USE ONLY", bg=THEME["panel"],
                 fg=THEME["accent_dim"], font=(self.f_mono, 7)).pack(anchor="w")

        # --- main column ---
        mc = tk.Frame(self, bg=THEME["bg"])
        mc.place(x=252, y=10, relwidth=1.0, width=-262, relheight=1.0,
                 height=-20)
        header = tk.Frame(mc, bg=THEME["panel"], height=58,
                          highlightthickness=1,
                          highlightbackground=THEME["accent_dim"])
        header.pack(fill="x")
        header.pack_propagate(False)
        hleft = tk.Frame(header, bg=THEME["panel"])
        hleft.pack(side="left", padx=16)
        self.h_title = tk.Label(hleft, text=APP_NAME, bg=THEME["panel"],
                                fg=THEME["glow"], font=(self.f_ui, 15, "bold"))
        self.h_title.pack(anchor="w")
        self.h_sub = tk.Label(hleft, text="INITIALIZING...",
                              bg=THEME["panel"], fg=THEME["dim"],
                              font=(self.f_mono, 8))
        self.h_sub.pack(anchor="w")
        hright = tk.Frame(header, bg=THEME["panel"])
        hright.pack(side="right", padx=16)
        self.dot = tk.Canvas(hright, width=10, height=10, bg=THEME["panel"],
                             highlightthickness=0)
        self._dot_item = self.dot.create_oval(1, 1, 9, 9, fill=THEME["warn"],
                                              outline="")
        self.dot.pack(side="left", pady=(0, 0))
        self.netlbl = tk.Label(hright, text="SCANNING", bg=THEME["panel"],
                               fg=THEME["warn"], font=(self.f_mono, 8, "bold"))
        self.netlbl.pack(side="left", padx=(6, 14))
        self.clock = tk.Label(hright, text="--:--:--", bg=THEME["panel"],
                              fg=THEME["accent"],
                              font=(self.f_mono, 11, "bold"))
        self.clock.pack(side="left")
        self.hstatus = tk.Label(header, text="STANDBY", bg=THEME["panel"],
                                fg=THEME["dim"], font=(self.f_mono, 9))
        self.hstatus.place(relx=0.52, rely=0.5, anchor="center")

        self.container = tk.Frame(mc, bg=THEME["bg"])
        self.container.pack(fill="both", expand=True, pady=(8, 0))
        self._tick_clock()
        self.show_tool("ip")

    def show_tool(self, key):
        if key not in self.pages:
            cls = PAGE_CLASSES[key]
            page = cls(self.container, self)
            page.place(x=0, y=0, relwidth=1.0, relheight=1.0)
            self.pages[key] = page
        page = self.pages[key]
        page.tkraise()
        self.current = key
        for k, btn in self.menu_buttons.items():
            btn.itemconfig(btn._poly,
                           outline=THEME["accent"] if k == key else THEME["dim"],
                           width=2 if k == key else 1)
        entry = next(m for m in MENU if m[0] == key)
        self.h_title.config(text=entry[3])
        self.h_sub.config(text=entry[4])
        if hasattr(page, "on_show"):
            page.on_show()

    def _tick_clock(self):
        self.clock.config(text=datetime.now().strftime("%H:%M:%S"))
        self.after(1000, self._tick_clock)

    # ---- record flow ----------------------------------------
    def open_ip_record(self, rec, deep=False):
        self.show_tool("ip")
        page = self.pages["ip"]
        if deep:
            page.run(lambda: ip_info(rec["ip"], deep=True),
                     lambda data: page.add_deep(rec, data),
                     busy="DEEP INFO: " + str(rec["ip"]))
        else:
            page.show_record(rec)


# ============================================================
#  PAGE BASE
# ============================================================

class BasePage(tk.Frame):

    TITLE = "TOOL"
    SUB = ""

    def __init__(self, master, app):
        super().__init__(master, bg=THEME["bg"])
        self.app = app
        self._stop = threading.Event()
        self._build_header()
        self.build()

    def _build_header(self):
        bar = tk.Frame(self, bg=THEME["bg"])
        bar.pack(fill="x", padx=14, pady=(6, 10))
        left = tk.Frame(bar, bg=THEME["bg"])
        left.pack(side="left")
        tk.Label(left, text=self.TITLE, bg=THEME["bg"], fg=THEME["glow"],
                 font=(self.app.f_ui, 18, "bold")).pack(anchor="w")
        tk.Label(left, text=self.SUB, bg=THEME["bg"], fg=THEME["dim"],
                 font=(self.app.f_mono, 8)).pack(anchor="w")
        self._status = tk.Label(bar, text="STANDBY", bg=THEME["bg"],
                                fg=THEME["dim"], font=(self.app.f_mono, 9, "bold"))
        self._status.pack(side="right")

    def status(self, text, color=None):
        self._status.config(text=text, fg=color or THEME["dim"])

    def run(self, fn, on_done, on_error=None, busy="RUNNING..."):
        self.status(busy, THEME["warn"])

        def ok(res):
            self.status("DONE", THEME["ok"])
            on_done(res)

        def err(e):
            self.status("ERROR", THEME["bad"])
            if on_error:
                on_error(e)
            else:
                self.app.default_error(e)

        self.app.run_async(fn, ok, err)

    def build(self):
        raise NotImplementedError

    def on_show(self):
        pass

    def entry(self, parent, width=28, placeholder=""):
        e = tk.Entry(parent, bg=THEME["panel2"], fg=THEME["text"],
                     insertbackground=THEME["accent"], relief="flat",
                     font=(self.app.f_mono, 10), width=width,
                     highlightthickness=1,
                     highlightbackground=THEME["accent_dim"],
                     highlightcolor=THEME["accent"])
        if placeholder:
            e.insert(0, placeholder)
        return e

    def label_pair(self, parent, key):
        row = tk.Frame(parent, bg=THEME["panel"])
        row.pack(fill="x", pady=1)
        tk.Label(row, text=key, bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.app.f_mono, 8, "bold"), width=12,
                 anchor="w").pack(side="left")
        val = tk.Label(row, text="--", bg=THEME["panel"], fg=THEME["text"],
                       font=(self.app.f_mono, 9), anchor="w")
        val.pack(side="left", padx=4)
        return val


# ============================================================
#  TOOL 01 -- IP SCANNER
# ============================================================

def ip_rows(data, deep=False):
    rows = [
        ("COUNTRY", "{} ({})".format(data.get("country", "?"),
                                     data.get("countryCode", "--"))),
        ("CITY", "{}, {}".format(data.get("city", "--"),
                                 data.get("regionName", "--"))),
        ("ISP", data.get("isp", "--")),
        ("ORG", data.get("org", "--")),
        ("AS", data.get("as", "--")),
        ("TIMEZONE", data.get("timezone", "--")),
        ("LAT/LON", "{}, {}".format(data.get("lat", "--"),
                                    data.get("lon", "--"))),
    ]
    if deep:
        rows += [
            ("DISTRICT", data.get("district", "--") or "--"),
            ("ZIP", data.get("zip", "--") or "--"),
            ("CURRENCY", data.get("currency", "--") or "--"),
            ("REVERSE DNS", data.get("reverse", "--") or "--"),
            ("MOBILE", "YES" if data.get("mobile") else "NO"),
            ("PROXY/VPN", "YES" if data.get("proxy") else "NO"),
            ("HOSTING/DC", "YES" if data.get("hosting") else "NO"),
            ("GMT OFFSET", str(data.get("offset", "--"))),
        ]
    return rows


class SavedBox(tk.Frame):
    """Box in the left rail: every scan lands here, headed by the IP."""

    def __init__(self, master, app, rec):
        super().__init__(master, bg=THEME["panel2"], highlightthickness=1,
                         highlightbackground=THEME["accent_dim"], cursor="hand2")
        head = tk.Frame(self, bg=THEME["panel3"], height=24)
        head.pack(fill="x")
        head.pack_propagate(False)
        tk.Label(head, text=str(rec.get("ip", "?")), bg=THEME["panel3"],
                 fg=THEME["glow"], font=(app.f_mono, 9, "bold")).pack(
            side="left", padx=8)
        tk.Label(head, text=rec.get("mode", ""), bg=THEME["panel3"],
                 fg=THEME["accent"], font=(app.f_mono, 7, "bold")).pack(
            side="right", padx=8)
        tk.Label(self, text=rec.get("saved_at", ""), bg=THEME["panel2"],
                 fg=THEME["dim"], font=(app.f_mono, 7)).pack(
            anchor="w", padx=8, pady=2)
        for w in (self, head):
            w.bind("<Button-1>", lambda e, r=rec: app.open_ip_record(r))
            w.bind("<Enter>",
                   lambda e, s=self: s.config(
                       highlightbackground=THEME["accent"]))
            w.bind("<Leave>",
                   lambda e, s=self: s.config(
                       highlightbackground=THEME["accent_dim"]))


class IpPage(BasePage):

    TITLE = "IP SCANNER"
    SUB = "SINGLE TARGET / FILE BATCH / DEEP INTELLIGENCE"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="TARGET", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.target = self.entry(inner, width=30, placeholder="8.8.8.8 or example.com")
        self.target.pack(side="left", padx=(10, 10))
        self.target.bind("<Return>", lambda e: self.scan_single(False))
        NeonButton(inner, "SCAN", width=110, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=lambda: self.scan_single(False)).pack(side="left",
                                                                 padx=2)
        NeonButton(inner, "SCAN + DEEP", width=150, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=lambda: self.scan_single(True)).pack(side="left",
                                                                padx=2)
        NeonButton(inner, "LOAD FILE", width=120, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.load_file).pack(side="left", padx=2)
        NeonButton(inner, "STOP", width=70, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.stop_batch).pack(side="left", padx=2)
        tk.Label(inner, text="AUTO-DETECT: IP / DOMAIN", bg=THEME["panel"],
                 fg=THEME["dim"], font=(self.app.f_mono, 8)).pack(
            side="right", padx=4)

        body = tk.Frame(self, bg=THEME["bg"])
        body.pack(fill="both", expand=True, padx=14)

        # left rail: saved target boxes
        rail = tk.Frame(body, bg=THEME["panel"], width=270,
                        highlightthickness=1,
                        highlightbackground=THEME["accent_dim"])
        rail.pack(side="left", fill="y")
        rail.pack_propagate(False)
        rail_head = tk.Frame(rail, bg=THEME["panel"])
        rail_head.pack(fill="x", padx=10, pady=(10, 4))
        tk.Label(rail_head, text="SAVED TARGETS", bg=THEME["panel"],
                 fg=THEME["accent"], font=(self.app.f_mono, 10, "bold")).pack(
            side="left")
        clr = tk.Label(rail_head, text="[CLEAR]", bg=THEME["panel"],
                       fg=THEME["bad"], font=(self.app.f_mono, 8, "bold"),
                       cursor="hand2")
        clr.pack(side="right")
        clr.bind("<Button-1>", self._clear_saved)
        self.rail_list = ScrollFrame(rail, bg=THEME["panel"], width=262,
                                     height=420)
        self.rail_list.pack(fill="both", expand=True, padx=6, pady=(0, 10))

        # desk: draggable cards
        desk_wrap = tk.Frame(body, bg=THEME["bg"])
        desk_wrap.pack(side="left", fill="both", expand=True, padx=(10, 0))
        self.desk = Desk(desk_wrap, self.app)
        self.desk.pack(fill="both", expand=True)

    # ---- actions --------------------------------------------
    def _scan_one(self, target, deep):
        target = target.strip()
        if not target:
            raise ValueError("enter a target first")
        query = target
        if not ip_regex().match(target):
            try:
                query = socket.gethostbyname(target)
            except Exception:
                raise RuntimeError("cannot resolve: " + target)
        data = ip_info(query, deep=deep)
        if data.get("status") != "success":
            raise RuntimeError(data.get("message", "lookup failed"))
        rec = {
            "ip": query,
            "mode": "DEEP" if deep else "SINGLE",
            "rows": ip_rows(data, deep),
            "info": data,
            "saved_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        }
        return rec

    def scan_single(self, deep):
        t = self.target.get().strip()
        if not t:
            self.status("ENTER A TARGET FIRST", THEME["warn"])
            return
        self.run(lambda: self._scan_one(t, deep),
                 self._after_scan, busy="SCANNING " + t)

    def _after_scan(self, rec):
        self.app.store.add_ip_record(rec)
        self.app.store.log("IP-SCANNER", "scan", rec["ip"], rec["mode"])
        self._refresh_saved()
        self.desk.add_card(rec)

    def load_file(self):
        path = filedialog.askopenfilename(
            title="LOAD IP LIST",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if not path:
            return
        self._stop.clear()
        self.run(lambda: self._scan_file(path), self._after_file_batch,
                 busy="READING FILE")

    def stop_batch(self):
        self._stop.set()
        self.status("STOPPING BATCH...", THEME["warn"])

    def _scan_file(self, path):
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
        ips = []
        for m in ip_regex().finditer(content):
            ip = m.group(0)
            if ip not in ips and all(int(o) <= 255 for o in ip.split(".")):
                ips.append(ip)
        if not ips:
            raise ValueError("no IPv4 addresses found in file")
        recs = []
        n = len(ips)
        for i, ip in enumerate(ips):
            if self._stop.is_set():
                break
            self.app.q.put(("ok",
                            lambda _r, i=i, n=n: self.status(
                                "BATCH {}/{} -- {}".format(i + 1, n, ip),
                                THEME["warn"]), None))
            try:
                data = ip_info(ip, deep=False)
            except Exception:
                continue
            if data.get("status") != "success":
                continue
            recs.append({
                "ip": ip, "mode": "FILE", "rows": ip_rows(data, False),
                "info": data,
                "saved_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            })
            time.sleep(0.85)  # public API rate limit
        return recs

    def _after_file_batch(self, recs):
        for rec in recs:
            self.app.store.add_ip_record(rec)
            self.desk.add_card(rec)
        self.app.store.log("IP-SCANNER", "file batch", "{} targets".format(len(recs)))
        self._refresh_saved()
        self.status("BATCH COMPLETE: {} TARGETS".format(len(recs)), THEME["ok"])

    def add_deep(self, rec, data):
        if data.get("status") != "success":
            self.app.default_error(RuntimeError(data.get("message", "deep lookup failed")))
            return
        deep_rec = {
            "ip": rec["ip"], "mode": "DEEP", "rows": ip_rows(data, True),
            "info": data,
            "saved_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        }
        self.app.store.add_ip_record(deep_rec)
        self.app.store.log("IP-SCANNER", "deep info", rec["ip"])
        self._refresh_saved()
        self.desk.add_card(deep_rec)

    def show_record(self, rec):
        self.desk.add_card(rec)

    def _refresh_saved(self):
        for w in self.rail_list.inner.winfo_children():
            w.destroy()
        for rec in self.app.store.ip_records()[:80]:
            SavedBox(self.rail_list.inner, self.app, rec).pack(
                fill="x", padx=4, pady=3)

    def _clear_saved(self, _e=None):
        self.app.store.clear_ip_records()
        self._refresh_saved()
        self.status("SAVED LIST CLEARED", THEME["warn"])

    def on_show(self):
        self._refresh_saved()


# ============================================================
#  TOOL 02 -- NMAP SCAN
# ============================================================

class NmapPage(BasePage):

    TITLE = "NMAP SCAN"
    SUB = "TCP PORTS / SERVICES / LATENCY / ISP INTEL"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="TARGET", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.host_e = self.entry(inner, width=24, placeholder="scanme.nmap.org")
        self.host_e.pack(side="left", padx=(10, 10))
        self.host_e.bind("<Return>", lambda e: self.start_scan())
        tk.Label(inner, text="PORTS", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.preset = ttk.Combobox(inner, state="readonly", width=18,
                                   values=["QUICK (32 PORTS)",
                                           "STANDARD (80 PORTS)",
                                           "FULL (1-1024)", "CUSTOM"],
                                   font=(self.app.f_mono, 9))
        self.preset.current(0)
        self.preset.pack(side="left", padx=(8, 8))
        self.custom_e = self.entry(inner, width=16, placeholder="80,443,1000-2000")
        self.custom_e.pack(side="left", padx=(0, 10))
        NeonButton(inner, "SCAN", width=100, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.start_scan).pack(side="left", padx=2)
        NeonButton(inner, "STOP", width=70, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.stop_scan).pack(side="left", padx=2)

        body = tk.Frame(self, bg=THEME["bg"])
        body.pack(fill="both", expand=True, padx=14)

        tree_wrap = tk.Frame(body, bg=THEME["bg"])
        tree_wrap.pack(side="left", fill="both", expand=True)
        cols = ("port", "service", "state", "latency", "banner")
        self.tree = ttk.Treeview(tree_wrap, columns=cols, show="headings")
        for cid, txt, w in (("port", "PORT", 70), ("service", "SERVICE", 130),
                            ("state", "STATE", 70), ("latency", "LATENCY", 90),
                            ("banner", "BANNER", 380)):
            self.tree.heading(cid, text=txt)
            self.tree.column(cid, width=w, anchor="w")
        vsb = ttk.Scrollbar(tree_wrap, orient="vertical",
                            command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)
        self.tree.tag_configure("open", foreground=THEME["text"])

        info = tk.Frame(body, bg=THEME["panel"], width=260,
                        highlightthickness=1,
                        highlightbackground=THEME["accent_dim"])
        info.pack(side="left", fill="y", padx=(10, 0))
        info.pack_propagate(False)
        tk.Label(info, text="TARGET INTEL", bg=THEME["panel"],
                 fg=THEME["accent"], font=(self.app.f_mono, 10, "bold")).pack(
            anchor="w", padx=12, pady=(12, 6))
        self.i_target = self.label_pair(info, "TARGET")
        self.i_isp = self.label_pair(info, "ISP")
        self.i_org = self.label_pair(info, "ORG")
        self.i_as = self.label_pair(info, "AS")
        self.i_country = self.label_pair(info, "COUNTRY")
        self.i_city = self.label_pair(info, "CITY")
        self.i_open = self.label_pair(info, "OPEN PORTS")
        self.i_time = self.label_pair(info, "SCAN TIME")

    def stop_scan(self):
        self._stop.set()
        self.status("STOPPING...", THEME["warn"])

    def _prog_cb(self, done, total):
        self.app.q.put(("ok", lambda _r, d=done, t=total:
                        self.status("SCANNING... {}/{}".format(d, t),
                                    THEME["warn"]), None))

    def start_scan(self):
        host = self.host_e.get().strip()
        if not host:
            self.status("ENTER A TARGET FIRST", THEME["warn"])
            return
        try:
            ports = port_list(self.preset.get(), self.custom_e.get())
        except Exception:
            self.status("BAD CUSTOM PORT LIST", THEME["bad"])
            return
        if not ports:
            self.status("EMPTY PORT LIST", THEME["warn"])
            return
        for w in self.tree.get_children():
            self.tree.delete(w)
        self._stop.clear()

        def work():
            t0 = time.perf_counter()
            res = scan_ports(host, ports,
                             timeout=float(CFG["scan_timeout"]),
                             stop=self._stop, progress=self._prog_cb)
            intel = None
            try:
                intel = ip_info(host, deep=False)
            except Exception:
                pass
            return res, intel, round(time.perf_counter() - t0, 2)

        self.run(work, self._done,
                 busy="SCANNING {} [{} PORTS]".format(host, len(ports)))

    def _done(self, payload):
        results, intel, elapsed = payload
        for r in results:
            self.tree.insert("", "end", values=(
                r["port"], r["service"], "OPEN",
                "{} ms".format(r["latency_ms"]), r["banner"] or "--"))
        self.i_open.config(text=str(len(results)))
        self.i_time.config(text="{}s".format(elapsed))
        if intel and intel.get("status") == "success":
            self.i_target.config(text=str(intel.get("query", "--")))
            self.i_isp.config(text=str(intel.get("isp", "--"))[:30])
            self.i_org.config(text=str(intel.get("org", "--"))[:30])
            self.i_as.config(text=str(intel.get("as", "--"))[:30])
            self.i_country.config(text=str(intel.get("country", "--")))
            self.i_city.config(text=str(intel.get("city", "--")))
        self.app.store.log("NMAP-SCAN", "port scan", self.host_e.get(),
                           "{} open".format(len(results)))
        if self._stop.is_set():
            self.status("STOPPED -- {} OPEN".format(len(results)), THEME["warn"])
        else:
            self.status("SCAN COMPLETE -- {} OPEN".format(len(results)),
                        THEME["ok"])

    def on_show(self):
        pass


# ============================================================
#  TOOL 03 -- PATH FUZZER
# ============================================================

class FuzzPage(BasePage):

    TITLE = "PATH FUZZER"
    SUB = "DIRECTORY GUESSING // example.com/admin"

    def build(self):
        self.wl = json.loads(vault_read("wordlists.nxt")[0].decode("utf-8"))

        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 6))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="TARGET URL", bg=THEME["panel"],
                 fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.url_e = self.entry(inner, width=34, placeholder="http://example.com/")
        self.url_e.pack(side="left", padx=(10, 10))
        self.url_e.bind("<Return>", lambda e: self.start())
        NeonButton(inner, "START FUZZ", width=130, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.start).pack(side="left", padx=2)
        NeonButton(inner, "STOP", width=70, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.stop).pack(side="left", padx=2)

        opt = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        opt.pack(fill="x", padx=14, pady=(0, 8))
        oi = tk.Frame(opt, bg=THEME["panel"])
        oi.pack(fill="x", padx=10, pady=8)
        tk.Label(oi, text="WORDLIST", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        n_paths = len(self.wl.get("paths", []))
        n_users = len(self.wl.get("users", []))
        n_passes = len(self.wl.get("passes", []))
        self.wl_sel = ttk.Combobox(
            oi, state="readonly", width=20,
            values=["PATHS ({})".format(n_paths),
                    "USERS ({})".format(n_users),
                    "PASSES ({})".format(n_passes)],
            font=(self.app.f_mono, 9))
        self.wl_sel.current(0)
        self.wl_sel.pack(side="left", padx=(8, 14))
        tk.Label(oi, text="EXT", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.ext_e = self.entry(oi, width=16, placeholder="php,html,bak")
        self.ext_e.pack(side="left", padx=(8, 14))
        tk.Label(oi, text="THREADS", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.th_sel = ttk.Combobox(oi, state="readonly", width=6,
                                   values=["10", "20", "30", "50"],
                                   font=(self.app.f_mono, 9))
        self.th_sel.current(0)
        self.th_sel.pack(side="left", padx=(8, 14))
        self.hide404 = tk.BooleanVar(value=False)
        ttk.Checkbutton(oi, text="HIDE 404", variable=self.hide404).pack(
            side="left", padx=8)

        prog = tk.Frame(self, bg=THEME["bg"])
        prog.pack(fill="x", padx=14, pady=(0, 6))
        self.pb = ttk.Progressbar(prog, style="Horizontal.TProgressbar",
                                  maximum=100, value=0)
        self.pb.pack(fill="x")
        row = tk.Frame(prog, bg=THEME["bg"])
        row.pack(fill="x", pady=4)
        self.c_tried = tk.Label(row, text="TRIED: 0", bg=THEME["bg"],
                                fg=THEME["dim"], font=(self.app.f_mono, 9, "bold"))
        self.c_tried.pack(side="left", padx=(0, 16))
        self.c_found = tk.Label(row, text="RESPONDED: 0", bg=THEME["bg"],
                                fg=THEME["ok"], font=(self.app.f_mono, 9, "bold"))
        self.c_found.pack(side="left", padx=(0, 16))
        self.c_total = tk.Label(row, text="TASKS: 0", bg=THEME["bg"],
                                fg=THEME["dim"], font=(self.app.f_mono, 9, "bold"))
        self.c_total.pack(side="left", padx=(0, 16))
        self.c_time = tk.Label(row, text="ELAPSED: 0s", bg=THEME["bg"],
                               fg=THEME["accent"],
                               font=(self.app.f_mono, 9, "bold"))
        self.c_time.pack(side="left")

        wrap = tk.Frame(self, bg=THEME["bg"])
        wrap.pack(fill="both", expand=True, padx=14)
        cols = ("path", "status", "size", "note")
        self.tree = ttk.Treeview(wrap, columns=cols, show="headings")
        for cid, txt, w in (("path", "PATH", 300), ("status", "STATUS", 80),
                            ("size", "SIZE", 100), ("note", "NOTE", 330)):
            self.tree.heading(cid, text=txt)
            self.tree.column(cid, width=w, anchor="w")
        vsb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)
        self.tree.tag_configure("s200", foreground=THEME["ok"])
        self.tree.tag_configure("s3xx", foreground=THEME["warn"])
        self.tree.tag_configure("s4xx", foreground=THEME["dim"])
        self.tree.tag_configure("s5xx", foreground=THEME["bad"])

    def stop(self):
        self._stop.set()
        self.status("STOPPING...", THEME["warn"])

    def _live_row(self, item):
        path, status, size, note, _ms = item
        if status == "ERR":
            tag = "s5xx"
        elif status == 200:
            tag = "s200"
        elif isinstance(status, int) and 300 <= status < 400:
            tag = "s3xx"
        elif isinstance(status, int) and 400 <= status < 500:
            tag = "s4xx"
        else:
            tag = "s5xx"
        if not (self.hide404.get() and status == 404):
            self.tree.insert("", "end", values=(
                path, status, "{} B".format(size) if size else "0 B",
                note or "--"), tags=(tag,))
        c = self._counters
        self.c_tried.config(text="TRIED: {}".format(c["tried"]))
        self.c_found.config(text="RESPONDED: {}".format(c["found"]))
        self.c_time.config(text="ELAPSED: {}s".format(int(time.time() - c["t0"])))
        self.pb.config(value=c["tried"])

    def start(self):
        base = self.url_e.get().strip()
        if not base:
            self.status("ENTER A TARGET URL", THEME["warn"])
            return
        if not base.startswith(("http://", "https://")):
            base = "http://" + base
        if not base.endswith("/"):
            base = base.rstrip("/") + "/"
        wl_key = {"PATHS": "paths", "USERS": "users",
                  "PASSES": "passes"}[self.wl_sel.get().split(" ")[0]]
        words = self.wl.get(wl_key, [])
        exts = [e.strip().lstrip(".") for e in self.ext_e.get().split(",")
                if e.strip()]
        tasks, seen = [], set()
        for w in words:
            p = "/" + str(w).strip().lstrip("/")
            if p == "/":
                continue
            if p not in seen:
                seen.add(p)
                tasks.append(p)
            if not p.endswith("/") and "." not in p.split("/")[-1]:
                for ext in exts:
                    q = p + "." + ext
                    if q not in seen:
                        seen.add(q)
                        tasks.append(q)
        if not tasks:
            self.status("EMPTY WORDLIST", THEME["bad"])
            return
        for w in self.tree.get_children():
            self.tree.delete(w)
        self._stop.clear()
        threads = int(self.th_sel.get())
        self.pb.config(maximum=len(tasks), value=0)
        self._counters = {"tried": 0, "found": 0, "t0": time.time()}
        lock = threading.Lock()
        self.c_total.config(text="TASKS: {}".format(len(tasks)))

        def probe(path):
            if self._stop.is_set():
                return None
            url = base.rstrip("/") + path
            r = http_request(url, timeout=float(CFG["fuzz_timeout"]),
                             max_body=60000)
            with lock:
                self._counters["tried"] += 1
                if r["status"] is not None:
                    self._counters["found"] += 1
            note = ""
            if r["status"] in (301, 302, 303, 307, 308):
                note = "-> " + r["headers"].get("location", "")[:60]
            item = (path, r["status"] if r["status"] is not None else "ERR",
                    len(r["body"]), note, r["elapsed_ms"])
            self.app.q.put(("ok", lambda _r, it=item: self._live_row(it), None))
            return None  # rows are added live

        def work():
            with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as pool:
                futs = [pool.submit(probe, t) for t in tasks]
                for f in concurrent.futures.as_completed(futs):
                    if self._stop.is_set():
                        break
                    f.result()
            return len(tasks)

        self.run(work, self._done,
                 busy="FUZZING {} [{}]".format(base, wl_key.upper()))

    def _done(self, total):
        c = self._counters
        self.pb.config(value=c["tried"])
        self.app.store.log("FUZZER", "path fuzz", self.url_e.get(),
                           "{} tasks".format(total))
        if self._stop.is_set():
            self.status("STOPPED", THEME["warn"])
        else:
            self.status("FUZZ COMPLETE", THEME["ok"])


# ============================================================
#  TOOL 04 -- DNS / WHOIS
# ============================================================

class DnsPage(BasePage):

    TITLE = "DNS / WHOIS"
    SUB = "FULL RECORD ENUMERATION + REGISTRY DATA"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="DOMAIN", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.dom_e = self.entry(inner, width=30, placeholder="example.com")
        self.dom_e.pack(side="left", padx=(10, 10))
        self.dom_e.bind("<Return>", lambda e: self.resolve_all())
        NeonButton(inner, "RESOLVE ALL", width=130, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.resolve_all).pack(side="left", padx=2)
        NeonButton(inner, "WHOIS", width=90, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.do_whois).pack(side="left", padx=2)

        body = tk.Frame(self, bg=THEME["bg"])
        body.pack(fill="both", expand=True, padx=14)
        left = tk.Frame(body, bg=THEME["bg"])
        left.pack(side="left", fill="both", expand=True)
        cols = ("type", "value")
        self.tree = ttk.Treeview(left, columns=cols, show="headings")
        for cid, txt, w in (("type", "TYPE", 90), ("value", "VALUE", 620)):
            self.tree.heading(cid, text=txt)
            self.tree.column(cid, width=w, anchor="w")
        vsb = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)

        right = tk.Frame(body, bg=THEME["panel"], width=380,
                         highlightthickness=1,
                         highlightbackground=THEME["accent_dim"])
        right.pack(side="left", fill="y", padx=(10, 0))
        right.pack_propagate(False)
        tk.Label(right, text="WHOIS RAW", bg=THEME["panel"],
                 fg=THEME["accent"], font=(self.app.f_mono, 10, "bold")).pack(
            anchor="w", padx=12, pady=(12, 6))
        self.whois_txt = tk.Text(right, bg=THEME["panel2"], fg=THEME["text"],
                                 insertbackground=THEME["accent"], bd=0,
                                 font=(self.app.f_mono, 8), wrap="word",
                                 width=44)
        self.whois_txt.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    def resolve_all(self):
        dom = self.dom_e.get().strip()
        if not dom:
            self.status("ENTER A DOMAIN", THEME["warn"])
            return
        for w in self.tree.get_children():
            self.tree.delete(w)

        def work():
            rows = []
            for rtype in ("A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA"):
                try:
                    vals = dns_lookup(dom, rtype)
                    if vals == ["NXDOMAIN"]:
                        rows.append((rtype, "NXDOMAIN -- domain not found"))
                        break
                    for v in vals:
                        rows.append((rtype, v))
                    if not vals:
                        rows.append((rtype, "(none)"))
                except Exception as e:
                    rows.append((rtype, "ERROR: " + str(e)[:40]))
            return rows

        def done(rows):
            for rtype, val in rows:
                color = "ok" if rtype == "A" else None
                tag = ("recA",) if color else ()
                self.tree.insert("", "end", values=(rtype, val), tags=tag)
            self.tree.tag_configure("recA", foreground=THEME["ok"])
            self.app.store.log("DNS", "resolve", dom,
                               "{} records".format(len(rows)))
            self.status("RESOLVED -- {} RECORDS".format(len(rows)), THEME["ok"])

        self.run(work, done, busy="RESOLVING " + dom)

    def do_whois(self):
        dom = self.dom_e.get().strip()
        if not dom:
            self.status("ENTER A DOMAIN", THEME["warn"])
            return
        self.whois_txt.delete("1.0", "end")

        def work():
            text, server = whois(dom)
            return text, server

        def done(payload):
            text, server = payload
            lines = [l for l in text.splitlines()
                     if l.strip() and not l.startswith("%")][:60]
            self.whois_txt.insert("1.0", "\n".join(lines))
            self.whois_txt.insert("1.0", "// SERVER: {}\n\n".format(server))
            self.app.store.log("WHOIS", "lookup", dom)
            self.status("WHOIS DONE", THEME["ok"])

        self.run(work, done, busy="WHOIS " + dom)


# ============================================================
#  TOOL 05 -- SUBDOMAIN FINDER
# ============================================================

class SubdPage(BasePage):

    TITLE = "SUBDOMAIN FINDER"
    SUB = "DNS BRUTE RESOLUTION FROM VAULT PREFIXES"

    def build(self):
        self.prefixes = json.loads(
            vault_read("wordlists.nxt")[0].decode("utf-8")).get("subs", [])

        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="DOMAIN", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.dom_e = self.entry(inner, width=30, placeholder="example.com")
        self.dom_e.pack(side="left", padx=(10, 10))
        self.dom_e.bind("<Return>", lambda e: self.start())
        NeonButton(inner, "FIND", width=100, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.start).pack(side="left", padx=2)
        NeonButton(inner, "STOP", width=70, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.stop).pack(side="left", padx=2)
        tk.Label(inner, text="{} PREFIXES IN VAULT".format(len(self.prefixes)),
                 bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.app.f_mono, 8)).pack(side="right", padx=4)

        self.c_found = tk.Label(self, text="FOUND: 0", bg=THEME["bg"],
                                fg=THEME["ok"],
                                font=(self.app.f_mono, 10, "bold"))
        self.c_found.pack(anchor="w", padx=14, pady=(0, 4))

        wrap = tk.Frame(self, bg=THEME["bg"])
        wrap.pack(fill="both", expand=True, padx=14)
        cols = ("sub", "ip")
        self.tree = ttk.Treeview(wrap, columns=cols, show="headings")
        for cid, txt, w in (("sub", "SUBDOMAIN", 420), ("ip", "RESOLVED IP", 300)):
            self.tree.heading(cid, text=txt)
            self.tree.column(cid, width=w, anchor="w")
        vsb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)

    def stop(self):
        self._stop.set()
        self.status("STOPPING...", THEME["warn"])

    def start(self):
        dom = self.dom_e.get().strip().lower()
        if not dom or "." not in dom:
            self.status("ENTER A VALID DOMAIN", THEME["warn"])
            return
        if not self.prefixes:
            self.status("NO PREFIXES IN VAULT", THEME["bad"])
            return
        for w in self.tree.get_children():
            self.tree.delete(w)
        self._stop.clear()
        self.c_found.config(text="FOUND: 0")
        self._n = 0

        def work():
            return subdomain_scan(dom, self.prefixes, workers=24,
                                  stop=self._stop)

        def done(rows):
            for sub, ip in rows:
                self.tree.insert("", "end", values=(sub, ip))
            self._n = len(rows)
            self.c_found.config(text="FOUND: {}".format(self._n))
            self.app.store.log("SUBDOMAINS", "scan", dom,
                               "{} found".format(self._n))
            if self._stop.is_set():
                self.status("STOPPED", THEME["warn"])
            else:
                self.status("SCAN COMPLETE", THEME["ok"])

        self.run(work, done,
                 busy="RESOLVING {} SUBDOMAINS...".format(len(self.prefixes)))


# ============================================================
#  TOOL 06 -- HEADER ANALYZER
# ============================================================

SEC_CHECKS = [
    ("strict-transport-security", "HSTS"),
    ("content-security-policy", "CSP"),
    ("x-content-type-options", "X-CONTENT-TYPE"),
    ("x-frame-options", "X-FRAME-OPTIONS"),
    ("referrer-policy", "REFERRER-POLICY"),
    ("permissions-policy", "PERMISSIONS-POLICY"),
]


class HeadersPage(BasePage):

    TITLE = "HEADER ANALYZER"
    SUB = "RESPONSE HEADERS + SECURITY AUDIT"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="URL", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.url_e = self.entry(inner, width=36, placeholder="http://example.com")
        self.url_e.pack(side="left", padx=(10, 10))
        self.url_e.bind("<Return>", lambda e: self.analyze())
        NeonButton(inner, "ANALYZE", width=110, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.analyze).pack(side="left", padx=2)

        body = tk.Frame(self, bg=THEME["bg"])
        body.pack(fill="both", expand=True, padx=14)
        left = tk.Frame(body, bg=THEME["bg"])
        left.pack(side="left", fill="both", expand=True)
        tk.Label(left, text="RESPONSE HEADERS", bg=THEME["bg"],
                 fg=THEME["accent"],
                 font=(self.app.f_mono, 10, "bold")).pack(anchor="w",
                                                          pady=(0, 4))
        cols = ("header", "value")
        self.tree = ttk.Treeview(left, columns=cols, show="headings")
        for cid, txt, w in (("header", "HEADER", 220), ("value", "VALUE", 560)):
            self.tree.heading(cid, text=txt)
            self.tree.column(cid, width=w, anchor="w")
        vsb = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)

        right = tk.Frame(body, bg=THEME["panel"], width=290,
                         highlightthickness=1,
                         highlightbackground=THEME["accent_dim"])
        right.pack(side="left", fill="y", padx=(10, 0))
        right.pack_propagate(False)
        tk.Label(right, text="SECURITY AUDIT", bg=THEME["panel"],
                 fg=THEME["accent"], font=(self.app.f_mono, 10, "bold")).pack(
            anchor="w", padx=12, pady=(12, 4))
        self.audit_rows = {}
        for _hdr, name in SEC_CHECKS:
            row = tk.Frame(right, bg=THEME["panel"])
            row.pack(fill="x", padx=12, pady=2)
            tk.Label(row, text=name, bg=THEME["panel"], fg=THEME["text"],
                     font=(self.app.f_mono, 8, "bold"), width=18,
                     anchor="w").pack(side="left")
            badge = tk.Label(row, text="--", bg=THEME["panel"], fg=THEME["dim"],
                             font=(self.app.f_mono, 8, "bold"))
            badge.pack(side="right")
            self.audit_rows[name] = badge
        tk.Label(right, text="EXPOSURE", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 10, "bold")).pack(
            anchor="w", padx=12, pady=(12, 4))
        self.x_server = self.label_pair(right, "SERVER")
        self.x_powered = self.label_pair(right, "X-POWERED-BY")
        self.x_cookie = self.label_pair(right, "COOKIE FLAGS")

    def analyze(self):
        url = self.url_e.get().strip()
        if not url:
            self.status("ENTER A URL", THEME["warn"])
            return
        if not url.startswith(("http://", "https://")):
            url = "http://" + url
        for w in self.tree.get_children():
            self.tree.delete(w)

        def work():
            return http_request(url)

        def done(r):
            if r["status"] is None:
                raise RuntimeError(r["error"] or "request failed")
            self.tree.insert("", "end", values=(
                "STATUS", str(r["status"]) + "  ({} ms)".format(r["elapsed_ms"])),
                tags=("st",))
            self.tree.tag_configure("st", foreground=THEME["ok"])
            found = set()
            for k, v in r["headers"].items():
                self.tree.insert("", "end", values=(k, str(v)[:200]))
                if k.lower() in [h for h, _n in SEC_CHECKS]:
                    found.add(k.lower())
            for hdr, name in SEC_CHECKS:
                if hdr in found:
                    self.audit_rows[name].config(text="OK", fg=THEME["ok"])
                else:
                    self.audit_rows[name].config(text="MISSING", fg=THEME["bad"])
            self.x_server.config(text=str(r["headers"].get("server", "--"))[:26])
            self.x_powered.config(
                text=str(r["headers"].get("x-powered-by", "--"))[:26])
            cookie = r["headers"].get("set-cookie", "")
            if cookie:
                flags = []
                if "httponly" in cookie.lower():
                    flags.append("HTTPONLY")
                if "secure" in cookie.lower():
                    flags.append("SECURE")
                self.x_cookie.config(text=", ".join(flags) or "NONE", fg=THEME["warn"])
            else:
                self.x_cookie.config(text="NO COOKIES", fg=THEME["dim"])
            self.app.store.log("HEADERS", "analyze", url, str(r["status"]))
            self.status("ANALYZED -- {} HEADERS, {} CONTROLS".format(
                len(r["headers"]), len(found)), THEME["ok"])

        self.run(work, done, busy="FETCHING HEADERS")


# ============================================================
#  TOOL 07 -- BANNER GRABBER
# ============================================================

class BannerPage(BasePage):

    TITLE = "BANNER GRABBER"
    SUB = "RAW SERVICE IDENTIFICATION"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="HOST", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.host_e = self.entry(inner, width=24, placeholder="target.com")
        self.host_e.pack(side="left", padx=(10, 10))
        tk.Label(inner, text="PORT", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.port_e = self.entry(inner, width=8, placeholder="21")
        self.port_e.pack(side="left", padx=(8, 10))
        NeonButton(inner, "GRAB", width=90, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.grab(False)).pack(side="left", padx=2)
        NeonButton(inner, "HTTP PROBE", width=130, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.grab(True)).pack(side="left", padx=2)

        wrap = tk.Frame(self, bg=THEME["bg"])
        wrap.pack(fill="both", expand=True, padx=14)
        self.out = tk.Text(wrap, bg=THEME["panel2"], fg=THEME["text"],
                           insertbackground=THEME["accent"], bd=0,
                           font=(self.app.f_mono, 10), wrap="none")
        ssb = ttk.Scrollbar(wrap, orient="vertical", command=self.out.yview)
        self.out.configure(yscrollcommand=ssb.set)
        ssb.pack(side="right", fill="y")
        self.out.pack(fill="both", expand=True)
        self.out.insert("1.0", "// connect to a port and read the raw service banner\n"
                               "// HTTP PROBE sends a minimal GET for silent HTTP services\n")

    def grab(self, http_probe):
        def cmd():
            host = self.host_e.get().strip()
            try:
                port = int(self.port_e.get().strip() or "0")
            except ValueError:
                self.status("BAD PORT", THEME["bad"])
                return
            if not host or not (0 < port < 65536):
                self.status("ENTER HOST + PORT", THEME["warn"])
                return
            self.out.delete("1.0", "end")

            def work():
                return tcp_probe(host, port, timeout=6, banner_wait=1.5,
                                 http_probe=http_probe)

            def done(p):
                if not p["ok"]:
                    self.out.insert("1.0", "// connection refused / filtered: {}:{}\n".format(host, port))
                    self.status("CLOSED OR FILTERED", THEME["bad"])
                    return
                self.out.insert("1.0",
                                "// {}:{} OPEN  ({} ms)  service: {}\n".format(
                                    host, port, p["latency_ms"],
                                    PORTS.get(str(port), "unknown")))
                self.out.insert("end", p["banner"] or "(no banner -- empty response)")
                self.app.store.log("BANNER", "grab", "{}:{}".format(host, port))
                self.status("BANNER CAPTURED ({} ms)".format(p["latency_ms"]),
                            THEME["ok"])

            self.run(work, done, busy="CONNECTING {}:{}".format(host, port))
        return cmd


# ============================================================
#  TOOL 08 -- HASH TOOLS
# ============================================================

class HashPage(BasePage):

    TITLE = "HASH TOOLS"
    SUB = "GENERATE / IDENTIFY"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="TEXT", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.in_e = self.entry(inner, width=40, placeholder="input string")
        self.in_e.pack(side="left", padx=(10, 10))
        for algo in ("MD5", "SHA1", "SHA256", "SHA512"):
            NeonButton(inner, algo, width=90, height=30,
                       font=(self.app.f_mono, 9, "bold"),
                       command=lambda a=algo: self.gen(a)).pack(side="left",
                                                                padx=2)

        wrap = tk.Frame(self, bg=THEME["bg"])
        wrap.pack(fill="both", expand=True, padx=14)
        self.results = {}
        for algo in ("MD5", "SHA1", "SHA256", "SHA512"):
            box = tk.Frame(wrap, bg=THEME["panel"], highlightthickness=1,
                           highlightbackground=THEME["accent_dim"])
            box.pack(fill="x", pady=4)
            head = tk.Frame(box, bg=THEME["panel3"], height=26)
            head.pack(fill="x")
            head.pack_propagate(False)
            tk.Label(head, text=algo, bg=THEME["panel3"], fg=THEME["accent"],
                     font=(self.app.f_mono, 9, "bold")).pack(side="left",
                                                             padx=10)
            cp = tk.Label(head, text="[COPY]", bg=THEME["panel3"],
                          fg=THEME["dim"], font=(self.app.f_mono, 8, "bold"),
                          cursor="hand2")
            cp.pack(side="right", padx=10)
            lbl = tk.Label(box, text="--", bg=THEME["panel"], fg=THEME["text"],
                           font=(self.app.f_mono, 10), anchor="w")
            lbl.pack(fill="x", padx=10, pady=6)
            self.results[algo] = lbl
            cp.bind("<Button-1>", lambda e, a=algo: self.copy(a))

        idbar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                         highlightbackground=THEME["accent_dim"])
        idbar.pack(fill="x", padx=14, pady=8)
        iid = tk.Frame(idbar, bg=THEME["panel"])
        iid.pack(fill="x", padx=10, pady=10)
        tk.Label(iid, text="IDENTIFY", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.id_e = self.entry(iid, width=52, placeholder="paste a hash")
        self.id_e.pack(side="left", padx=(10, 10))
        NeonButton(iid, "IDENTIFY", width=100, height=30,
                   font=(self.app.f_mono, 9, "bold"),
                   command=self.identify).pack(side="left", padx=2)
        self.id_out = tk.Label(iid, text="--", bg=THEME["panel"],
                               fg=THEME["warn"], font=(self.app.f_mono, 9, "bold"))
        self.id_out.pack(side="left", padx=10)

    def gen(self, algo):
        text = self.in_e.get()
        if text == "":
            self.status("ENTER TEXT FIRST", THEME["warn"])
            return
        algo_map = {"MD5": "md5", "SHA1": "sha1", "SHA256": "sha256",
                    "SHA512": "sha512"}
        h = hash_compute(text, algo_map[algo])
        self.results[algo].config(text=h, fg=THEME["glow"])
        self.app.store.log("HASH", "generate " + algo, "(input)")
        self.status(algo + " GENERATED", THEME["ok"])

    def copy(self, algo):
        val = self.results[algo].cget("text")
        if val == "--":
            return
        self.clipboard_clear()
        self.clipboard_append(val)
        self.status("COPIED " + algo, THEME["ok"])

    def identify(self):
        v = self.id_e.get().strip()
        guesses = hash_identify(v)
        self.id_out.config(text=" / ".join(guesses) if guesses else "NOT A HASH",
                           fg=THEME["ok"] if guesses else THEME["bad"])
        self.status("IDENTIFY DONE", THEME["ok"])


# ============================================================
#  TOOL 09 -- ENCODER / DECODER
# ============================================================

class EncodePage(BasePage):

    TITLE = "ENCODER / DECODER"
    SUB = "BASE64 / HEX / URL / ROT13"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="METHOD", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.method = ttk.Combobox(inner, state="readonly", width=10,
                                   values=["BASE64", "HEX", "URL", "ROT13"],
                                   font=(self.app.f_mono, 9))
        self.method.current(0)
        self.method.pack(side="left", padx=(8, 14))
        NeonButton(inner, "ENCODE", width=100, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=lambda: self.do("ENCODE")).pack(side="left", padx=2)
        NeonButton(inner, "DECODE", width=100, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=lambda: self.do("DECODE")).pack(side="left", padx=2)
        NeonButton(inner, "COPY", width=80, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.copy).pack(side="left", padx=2)

        wrap = tk.Frame(self, bg=THEME["bg"])
        wrap.pack(fill="both", expand=True, padx=14)
        tk.Label(wrap, text="INPUT", bg=THEME["bg"], fg=THEME["dim"],
                 font=(self.app.f_mono, 9, "bold")).pack(anchor="w")
        self.in_txt = tk.Text(wrap, height=6, bg=THEME["panel2"],
                              fg=THEME["text"],
                              insertbackground=THEME["accent"], bd=0,
                              font=(self.app.f_mono, 10), wrap="word")
        self.in_txt.pack(fill="both", expand=True, pady=(2, 8))
        tk.Label(wrap, text="OUTPUT", bg=THEME["bg"], fg=THEME["dim"],
                 font=(self.app.f_mono, 9, "bold")).pack(anchor="w")
        self.out_txt = tk.Text(wrap, height=6, bg=THEME["panel2"],
                               fg=THEME["glow"],
                               insertbackground=THEME["accent"], bd=0,
                               font=(self.app.f_mono, 10), wrap="word")
        self.out_txt.pack(fill="both", expand=True, pady=(2, 0))

    def do(self, mode):
        text = self.in_txt.get("1.0", "end").rstrip("\n")
        if not text:
            self.status("INPUT IS EMPTY", THEME["warn"])
            return
        try:
            out = enc_transform(text, self.method.get(), mode)
        except Exception as e:
            self.status("FAILED: " + str(e)[:40], THEME["bad"])
            return
        self.out_txt.delete("1.0", "end")
        self.out_txt.insert("1.0", out)
        self.app.store.log("ENCODER", mode, self.method.get())
        self.status(mode + " OK [" + self.method.get() + "]", THEME["ok"])

    def copy(self):
        out = self.out_txt.get("1.0", "end").rstrip("\n")
        if not out:
            return
        self.clipboard_clear()
        self.clipboard_append(out)
        self.status("COPIED", THEME["ok"])


# ============================================================
#  TOOL 10 -- MAC VENDOR
# ============================================================

class MacPage(BasePage):

    TITLE = "MAC VENDOR"
    SUB = "OUI VENDOR LOOKUP"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="MAC", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.mac_e = self.entry(inner, width=26,
                                placeholder="AA:BB:CC:DD:EE:FF")
        self.mac_e.pack(side="left", padx=(10, 10))
        self.mac_e.bind("<Return>", lambda e: self.lookup())
        NeonButton(inner, "LOOKUP", width=100, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.lookup).pack(side="left", padx=2)

        box = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        box.pack(fill="x", padx=14)
        ib = tk.Frame(box, bg=THEME["panel"])
        ib.pack(fill="x", padx=12, pady=14)
        tk.Label(ib, text="VENDOR", bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.app.f_mono, 9, "bold")).pack(anchor="w")
        self.out = tk.Label(ib, text="--", bg=THEME["panel"], fg=THEME["glow"],
                            font=(self.app.f_mono, 16, "bold"), anchor="w")
        self.out.pack(anchor="w")
        tk.Label(box, text="NOTE: upstream lookup allows ~1 request/second",
                 bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.app.f_mono, 7)).pack(anchor="w", padx=12,
                                                 pady=(0, 10))

    def lookup(self):
        mac = self.mac_e.get().strip()

        def work():
            return mac_vendor(mac)

        def done(vendor):
            self.out.config(text=vendor)
            self.app.store.log("MAC", "lookup", mac, vendor)
            self.status("LOOKUP OK", THEME["ok"])

        self.run(work, done, busy="LOOKING UP " + mac)


# ============================================================
#  TOOL 11 -- PING MONITOR
# ============================================================

class PingPage(BasePage):

    TITLE = "PING MONITOR"
    SUB = "LIVE TCP LATENCY TRACKING"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="HOST", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.host_e = self.entry(inner, width=22, placeholder="1.1.1.1")
        self.host_e.pack(side="left", padx=(10, 10))
        tk.Label(inner, text="PORT", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.port_e = self.entry(inner, width=7, placeholder="443")
        self.port_e.pack(side="left", padx=(8, 10))
        tk.Label(inner, text="EVERY", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.int_e = self.entry(inner, width=6, placeholder="1.0")
        self.int_e.pack(side="left", padx=(8, 4))
        tk.Label(inner, text="s", bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.app.f_mono, 9)).pack(side="left", padx=(0, 10))
        self.start_b = NeonButton(inner, "START", width=90, height=32,
                                  font=(self.app.f_mono, 10, "bold"),
                                  command=self.start)
        self.start_b.pack(side="left", padx=2)
        NeonButton(inner, "STOP", width=70, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.stop).pack(side="left", padx=2)

        self.chart = tk.Canvas(self, height=170, bg=THEME["panel2"],
                               highlightthickness=1,
                               highlightbackground=THEME["accent_dim"])
        self.chart.pack(fill="x", padx=14, pady=(0, 8))

        stats = tk.Frame(self, bg=THEME["bg"])
        stats.pack(fill="x", padx=14, pady=(0, 6))
        self.s_min = tk.Label(stats, text="MIN: --", bg=THEME["bg"],
                              fg=THEME["ok"], font=(self.app.f_mono, 9, "bold"))
        self.s_min.pack(side="left", padx=(0, 18))
        self.s_avg = tk.Label(stats, text="AVG: --", bg=THEME["bg"],
                              fg=THEME["accent"],
                              font=(self.app.f_mono, 9, "bold"))
        self.s_avg.pack(side="left", padx=(0, 18))
        self.s_max = tk.Label(stats, text="MAX: --", bg=THEME["bg"],
                              fg=THEME["warn"],
                              font=(self.app.f_mono, 9, "bold"))
        self.s_max.pack(side="left", padx=(0, 18))
        self.s_loss = tk.Label(stats, text="LOSS: --", bg=THEME["bg"],
                               fg=THEME["bad"],
                               font=(self.app.f_mono, 9, "bold"))
        self.s_loss.pack(side="left", padx=(0, 18))
        self.s_state = tk.Label(stats, text="STATE: IDLE", bg=THEME["bg"],
                                fg=THEME["dim"],
                                font=(self.app.f_mono, 9, "bold"))
        self.s_state.pack(side="left")

        self._lats = []
        self._fails = 0
        self._tries = 0
        self._running = False
        self.chart.bind("<Configure>", lambda e: self._redraw())

    def start(self):
        host = self.host_e.get().strip()
        try:
            port = int(self.port_e.get().strip() or "443")
            interval = max(0.5, float(self.int_e.get().strip() or "1.0"))
        except ValueError:
            self.status("BAD PORT / INTERVAL", THEME["bad"])
            return
        if not host:
            self.status("ENTER A HOST", THEME["warn"])
            return
        if self._running:
            return
        self._running = True
        self._stop.clear()
        self._lats = []
        self._fails = 0
        self._tries = 0
        self.s_state.config(text="STATE: RUNNING", fg=THEME["ok"])
        self.app.store.log("PING", "monitor start", "{}:{}".format(host, port))

        def loop():
            while not self._stop.is_set():
                p = tcp_probe(host, port, timeout=2.5)
                self._tries += 1
                if p["ok"]:
                    self._lats.append(p["latency_ms"])
                    if len(self._lats) > 120:
                        self._lats.pop(0)
                else:
                    self._fails += 1
                line = "{}  {}:{}  {} ms".format(
                    datetime.now().strftime("%H:%M:%S"), host, port,
                    p["latency_ms"] if p["ok"] else "TIMEOUT")
                self.app.q.put(("ok",
                                lambda _r, s=line: self._log_line(s), None))
                self._update_stats()
                self.app.q.put(("ok", lambda _r: self._redraw(), None))
                for _ in range(int(interval * 10)):
                    if self._stop.is_set():
                        break
                    time.sleep(0.1)
            self.app.q.put(("ok", lambda _r: self._on_end(), None))

        threading.Thread(target=loop, daemon=True).start()
        self.status("MONITORING {}:{}".format(host, port), THEME["ok"])

    def stop(self):
        self._stop.set()
        self.status("STOPPING...", THEME["warn"])

    def _on_end(self):
        self._running = False
        self.s_state.config(text="STATE: IDLE", fg=THEME["dim"])
        self.status("MONITOR STOPPED", THEME["warn"])

    def _log_line(self, s):
        self.status(s[:70], THEME["dim"])

    def _update_stats(self):
        if self._lats:
            mn = min(self._lats)
            mx = max(self._lats)
            avg = sum(self._lats) / len(self._lats)
            jit = (max(self._lats[-10:]) - min(self._lats[-10:])
                   if len(self._lats) >= 2 else 0)
        else:
            mn = mx = avg = jit = 0
        loss = (self._fails / self._tries * 100) if self._tries else 0

        def upd(_r=None):
            self.s_min.config(text="MIN: {} ms".format(mn or "--"))
            self.s_avg.config(text="AVG: {:.1f} ms".format(avg))
            self.s_max.config(text="MAX: {} ms".format(mx or "--"))
            self.s_loss.config(text="LOSS: {:.0f}%".format(loss))
            self.s_state.config(text="STATE: RUNNING ({} PINGS)".format(self._tries),
                                fg=THEME["ok"])

        self.app.q.put(("ok", upd, None))

    def _redraw(self):
        c = self.chart
        c.delete("all")
        w = max(c.winfo_width(), 300)
        h = max(c.winfo_height(), 100)
        for x in range(0, w, 44):
            c.create_line(x, 0, x, h, fill=THEME["accent_dim"], dash=(1, 7))
        if not self._lats:
            c.create_text(w // 2, h // 2, text="NO DATA -- START A MONITOR",
                          fill=THEME["dim"], font=(self.app.f_mono, 10, "bold"))
            return
        mx = max(self._lats) or 1
        pts = []
        n = len(self._lats)
        for i, v in enumerate(self._lats):
            x = 14 + (w - 28) * i / max(n - 1, 1)
            y = h - 14 - (h - 28) * (v / mx)
            pts += [x, y]
        if len(pts) >= 4:
            c.create_line(pts, fill=THEME["accent"], width=2)
        c.create_text(w - 10, 12, text="{} ms max".format(mx),
                      fill=THEME["dim"], font=(self.app.f_mono, 8),
                      anchor="e")

    def on_show(self):
        self._redraw()


# ============================================================
#  TOOL 12 -- PASSWORD GENERATOR
# ============================================================

class PassGenPage(BasePage):

    TITLE = "PASSWORD GENERATOR"
    SUB = "CRYPTO-STRENGTH RANDOM KEYS"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="LENGTH", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.len_v = tk.IntVar(value=20)
        self.len_lbl = tk.Label(inner, text="20", bg=THEME["panel"],
                                fg=THEME["glow"],
                                font=(self.app.f_mono, 11, "bold"), width=3)
        self.len_lbl.pack(side="left", padx=(6, 6))
        tk.Scale(inner, from_=8, to=64, orient="horizontal", length=180,
                 variable=self.len_v, bg=THEME["panel"], fg=THEME["text"],
                 highlightthickness=0, troughcolor=THEME["panel2"],
                 command=lambda v: self.len_lbl.config(text=v),
                 showvalue=False).pack(side="left", padx=(0, 16))
        self.vars = {}
        for name, label in (("lowercase", "a-z"), ("uppercase", "A-Z"),
                            ("digits", "0-9"), ("symbols", "SYMBOLS")):
            v = tk.BooleanVar(value=True)
            self.vars[name] = v
            ttk.Checkbutton(inner, text=label, variable=v).pack(
                side="left", padx=6)
        NeonButton(inner, "GENERATE", width=120, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.generate).pack(side="left", padx=2)
        NeonButton(inner, "COPY", width=80, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.copy).pack(side="left", padx=2)

        box = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        box.pack(fill="x", padx=14)
        bb = tk.Frame(box, bg=THEME["panel"])
        bb.pack(fill="x", padx=14, pady=16)
        self.out = tk.Label(bb, text="--", bg=THEME["panel"], fg=THEME["glow"],
                            font=(self.app.f_mono, 16, "bold"), anchor="w")
        self.out.pack(anchor="w")
        self.strength = tk.Label(bb, text="STRENGTH: --", bg=THEME["panel"],
                                 fg=THEME["dim"],
                                 font=(self.app.f_mono, 9, "bold"))
        self.strength.pack(anchor="w", pady=(6, 0))

        tip = tk.Label(self, text="generated with the secrets module (OS entropy)",
                       bg=THEME["bg"], fg=THEME["dim"],
                       font=(self.app.f_mono, 8))
        tip.pack(anchor="w", padx=14, pady=6)

    def generate(self):
        sets = tuple(k for k, v in self.vars.items() if v.get())
        try:
            pwd, pool = password_generate(int(self.len_v.get()), sets)
        except Exception as e:
            self.status(str(e), THEME["bad"])
            return
        self.out.config(text=pwd)
        bits = entropy_bits(int(self.len_v.get()), pool)
        if bits < 50:
            label, col = "WEAK", THEME["bad"]
        elif bits < 70:
            label, col = "GOOD", THEME["warn"]
        elif bits < 100:
            label, col = "STRONG", THEME["ok"]
        else:
            label, col = "EXTREME", THEME["accent"]
        self.strength.config(text="STRENGTH: {}  ({:.0f} bits entropy)".format(
            label, bits), fg=col)
        self.app.store.log("PASS-GEN", "generate",
                           "{} chars".format(self.len_v.get()))
        self.status("GENERATED [{}]".format(label), THEME["ok"])

    def copy(self):
        val = self.out.cget("text")
        if val == "--":
            return
        self.clipboard_clear()
        self.clipboard_append(val)
        self.status("COPIED", THEME["ok"])


# ============================================================
#  TOOL 13 -- SESSION LOG
# ============================================================

class LogPage(BasePage):

    TITLE = "SESSION LOG"
    SUB = "FULL OPERATION HISTORY (PERSISTED IN VAULT)"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        NeonButton(inner, "REFRESH", width=100, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.refresh).pack(side="left", padx=2)
        NeonButton(inner, "EXPORT .NXT", width=140, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.export).pack(side="left", padx=2)
        NeonButton(inner, "CLEAR", width=90, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.clear).pack(side="left", padx=2)
        tk.Label(inner, text="logs persist encrypted inside vault/db.nxt",
                 bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.app.f_mono, 8)).pack(side="right", padx=4)

        wrap = tk.Frame(self, bg=THEME["bg"])
        wrap.pack(fill="both", expand=True, padx=14)
        cols = ("time", "tool", "action", "target", "note")
        self.tree = ttk.Treeview(wrap, columns=cols, show="headings")
        for cid, txt, w in (("time", "TIME", 150), ("tool", "TOOL", 120),
                            ("action", "ACTION", 140),
                            ("target", "TARGET", 240),
                            ("note", "NOTE", 180)):
            self.tree.heading(cid, text=txt)
            self.tree.column(cid, width=w, anchor="w")
        vsb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)

    def refresh(self):
        for w in self.tree.get_children():
            self.tree.delete(w)
        for e in self.app.store.logs()[:300]:
            self.tree.insert("", "end", values=(
                e.get("ts", ""), e.get("tool", ""), e.get("action", ""),
                e.get("target", ""), e.get("note", "")))
        self.status("{} ENTRIES".format(len(self.app.store.logs())),
                    THEME["ok"])

    def export(self):
        path = filedialog.asksaveasfilename(
            title="EXPORT SESSION LOG",
            defaultextension=".nxt",
            filetypes=[("XXNETRO Vault", "*.nxt"), ("All files", "*.*")])
        if not path:
            return
        data = json.dumps({"exported": datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"), "logs": self.app.store.logs()},
            indent=1).encode("utf-8")
        with open(path, "wb") as f:
            f.write(vault_encode(data, b"T"))
        self.app.store.log("LOG", "export", os.path.basename(path))
        self.refresh()
        self.status("EXPORTED: " + os.path.basename(path), THEME["ok"])

    def clear(self):
        self.app.store.data["logs"] = []
        self.app.store.save()
        self.refresh()
        self.status("LOG CLEARED", THEME["warn"])

    def on_show(self):
        self.refresh()


# ============================================================
#  REGISTRY + ENTRY POINT
# ============================================================

PAGE_CLASSES = {
    "ip": IpPage,
    "nmap": NmapPage,
    "fuzz": FuzzPage,
    "dns": DnsPage,
    "subd": SubdPage,
    "head": HeadersPage,
    "bann": BannerPage,
    "hash": HashPage,
    "enc": EncodePage,
    "mac": MacPage,
    "ping": PingPage,
    "pgen": PassGenPage,
    "log": LogPage,
}


def main():
    app = App()
    app.start_splash()
    app.mainloop()


if __name__ == "__main__":
    main()
