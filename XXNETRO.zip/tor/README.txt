============================================================
 XXNETRO v1.0.0 -- DARKPIPE EDITION
============================================================

REQUIREMENTS
  - Python 3.8+ with Tkinter (standard on Windows Python)
  - No third-party packages. No pip install needed.
  - Internet connection required for the online tools
    (IP intel, fuzzing, DNS, headers...).

HOW TO RUN
  1. Keep the folder structure intact:
       tor/
       |-- xxnetro.py      (the launcher -- the only entry point)
       \-- vault/          (encrypted resource containers)
           core.nxt        theme / config / port database
           db.nxt          scan database (your results)
           logo.nxp        brand assets
           mask.nxp
           bg.nxp
           boot.nxs        boot sound
           wordlists.nxt   fuzz / subdomain wordlists
  2. Double-click xxnetro.py  (Windows) or run:
       python xxnetro.py

THE VAULT
  Every resource inside /vault uses proprietary encrypted
  containers (.nxt / .nxp / .nxs). They are unreadable with
  any external program -- only this launcher can decode them
  (in memory). If you edit or rename vault files, the
  integrity check will fail and the tool will not start.
  Your scan results (IP records, session log) live inside
  vault/db.nxt and persist between runs.

MODULES
  01 IP SCANNER      single IP / domain or a whole file,
                     deep info mode, draggable result cards,
                     every scan saved as a box
  02 NMAP SCAN       TCP port scanner with service names,
                     latency, banner grabbing, ISP intel
  03 PATH FUZZER     directory guessing (site.com/admin),
                     wordlists from the vault
  04 DNS / WHOIS     A/AAAA/MX/NS/TXT/CNAME/SOA + raw whois
  05 SUBDOMAINS      DNS brute resolution
  06 HEADERS         response headers + security audit
  07 BANNER GRAB     raw service identification
  08 HASH TOOLS      MD5/SHA1/SHA256/SHA512 + hash identify
  09 ENCODER         Base64 / Hex / URL / ROT13
  10 MAC VENDOR      OUI vendor lookup
  11 PING MONITOR    live TCP latency graph
  12 PASS GEN        crypto-strength password generator
  13 SESSION LOG     full operation history + encrypted export

NOTES
  - Scan only systems you are authorized to test.
  - Some targets rate-limit or block scanners. That is
    normal and will show as errors in the status line.
  - The boot sound plays on Windows out of the box; on
    Linux it uses paplay/aplay/ffplay when available.
============================================================
