#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
============================================================
 XXNETRO v1.0.0  --  DARKPIPE EDITION
------------------------------------------------------------
 Modular cyber toolkit launcher.
 Every internal resource (theme, images, sound, wordlists,
 database) is stored inside /vault in proprietary encrypted
 formats (.nxt / .nxp / .nxs). Nothing opens outside this
 launcher -- the pipes and wiring stay behind the walls.
 Authorized testing use only.
============================================================
"""
import base64
import hashlib
import json
import os
import queue
import shutil
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib
import secrets
import string as _string
import concurrent.futures
from datetime import datetime

import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk, filedialog

# ============================================================
#  VAULT LAYER  (proprietary encrypted resource formats)
# ============================================================

APP_DIR = os.path.dirname(os.path.abspath(__file__))
VAULT_DIR = os.path.join(APP_DIR, "vault")

_VMF = ["Xx", "Ne", "Tr", "O-", "Vo", "Lt", "-20", "25"]
_VMAGIC = b"NXR"
_VVER = b"\x01"
_VHEAD = 13
_VFOOT = b"NXEND"
_VTYPES = (b"T", b"P", b"S", b"B", b"M")


def _vault_key() -> bytes:
    """Rolling key assembled at runtime from scattered fragments."""
    return hashlib.sha256(("".join(_VMF)).encode("utf-8")).digest()


def _vxor(data: bytes, key: bytes) -> bytes:
    kl = len(key)
    return bytes(b ^ key[i % kl] for i, b in enumerate(data))


def vault_encode(plain: bytes, ktype: bytes = b"T") -> bytes:
    if ktype not in _VTYPES:
        raise ValueError("bad vault type")
    key = _vault_key()
    layer1 = _vxor(plain, key)
    b1 = base64.b64encode(layer1)
    layer2 = _vxor(b1, key[::-1])
    b2 = base64.b64encode(layer2)
    header = _VMAGIC + _VVER + ktype + struct.pack(
        ">II", zlib.crc32(plain) & 0xFFFFFFFF, len(plain))
    return header + b2 + _VFOOT


def vault_decode(blob: bytes):
    """-> (plain_bytes, type_str) ; raises ValueError on tamper."""
    if len(blob) < _VHEAD + len(_VFOOT) + 8:
        raise ValueError("vault: file too small")
    if blob[:3] != _VMAGIC or blob[3:4] != _VVER:
        raise ValueError("vault: bad magic")
    if not blob.endswith(_VFOOT):
        raise ValueError("vault: broken container")
    ktype = blob[4:5]
    crc, plen = struct.unpack(">II", blob[5:_VHEAD])
    body = blob[_VHEAD:-len(_VFOOT)]
    key = _vault_key()
    l1 = base64.b64decode(body)
    b1 = _vxor(l1, key[::-1])
    l0 = base64.b64decode(b1)
    plain = _vxor(l0, key)
    if len(plain) != plen:
        raise ValueError("vault: length mismatch")
    if (zlib.crc32(plain) & 0xFFFFFFFF) != crc:
        raise ValueError("vault: integrity check failed")
    return plain, ktype.decode()


def vault_read(name: str):
    with open(os.path.join(VAULT_DIR, name), "rb") as f:
        return vault_decode(f.read())


def vault_write(name: str, plain: bytes, ktype: bytes = b"T"):
    with open(os.path.join(VAULT_DIR, name), "wb") as f:
        f.write(vault_encode(plain, ktype))


# ============================================================
#  CORE CONFIG  (decrypted from vault -- never on disk plain)
# ============================================================

try:
    _core_plain, _core_type = vault_read("core.nxt")
    CORE = json.loads(_core_plain.decode("utf-8"))
except Exception as exc:  # vault missing / tampered
    print("FATAL: vault unavailable ->", exc)
    sys.exit(1)

THEME = CORE["theme"]
CFG = CORE["defaults"]
PORTS = CORE["ports"]
APP_NAME = CORE["app"]
APP_VERSION = CORE["version"]
APP_CODENAME = CORE["codename"]

if sys.platform == "win32":
    import winsound  # noqa: E402


def play_boot_sound():
    """Decode boot.nxs from vault and play it. Best effort, never crashes."""
    try:
        wav, _ = vault_read("boot.nxs")
        fd, tmp = tempfile.mkstemp(suffix=".wav")
        os.close(fd)
        with open(tmp, "wb") as f:
            f.write(wav)
        if sys.platform == "win32":
            def _w():
                try:
                    winsound.PlaySound(tmp, winsound.SND_FILENAME)
                finally:
                    try:
                        os.remove(tmp)
                    except OSError:
                        pass
            threading.Thread(target=_w, daemon=True).start()
        else:
            played = False
            for player, args in (("paplay", []), ("aplay", ["-q"]),
                                 ("ffplay", ["-nodisp", "-autoexit", "-loglevel", "quiet"])):
                exe = shutil.which(player)
                if exe:
                    try:
                        subprocess.Popen(
                            [exe] + args + [tmp],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL)
                        played = True
                        break
                    except OSError:
                        continue
            if not played:
                try:
                    os.remove(tmp)
                except OSError:
                    pass
    except Exception:
        pass


# ============================================================
#  DATA STORE  (scan database -- lives encrypted in db.nxt)
# ============================================================

class DataStore:
    """All scan results persist here, encrypted inside the vault."""

    def __init__(self):
        try:
            plain, _ = vault_read("db.nxt")
            self.data = json.loads(plain.decode("utf-8"))
        except Exception:
            self.data = {"ip_records": [], "logs": []}
        self.data.setdefault("apks", [])

    def save(self):
        try:
            vault_write("db.nxt",
                        json.dumps(self.data, indent=1).encode("utf-8"), b"B")
        except Exception:
            pass

    # -- IP records -----------------------------------------
    def add_ip_record(self, rec):
        rec["id"] = datetime.now().strftime("%H%M%S%f")
        self.data["ip_records"].insert(0, rec)
        self.data["ip_records"] = self.data["ip_records"][:400]
        self.save()

    def ip_records(self):
        return self.data["ip_records"]

    def clear_ip_records(self):
        self.data["ip_records"] = []
        self.save()

    # -- session log -----------------------------------------
    def logs(self):
        return self.data["logs"]

    def clear_logs(self):
        self.data["logs"] = []
        self.save()

    # -- APK sentinel reports --------------------------------
    def add_apk_record(self, rec):
        rec["id"] = datetime.now().strftime("%H%M%S%f")
        self.data["apks"].insert(0, rec)
        self.data["apks"] = self.data["apks"][:200]
        self.save()

    def apk_records(self):
        return self.data.get("apks", [])

    def clear_apk_records(self):
        self.data["apks"] = []
        self.save()

    def log(self, tool, action, target, note=""):
        entry = {
            "ts": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "tool": tool,
            "action": action,
            "target": str(target)[:120],
            "note": str(note)[:120],
        }
        self.data["logs"].insert(0, entry)
        self.data["logs"] = self.data["logs"][:1000]
        self.save()


# ============================================================
#  NETWORK LAYER  (pure stdlib -- no external tools required)
# ============================================================

IPV4_RE = None  # compiled lazily


def ip_regex():
    global IPV4_RE
    if IPV4_RE is None:
        import re
        IPV4_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
    return IPV4_RE


def http_request(url, timeout=None, method="GET", headers=None, max_body=3_000_000):
    """-> dict(status, headers, body, elapsed_ms, error, url)"""
    timeout = timeout or CFG["api_timeout"]
    h = {"User-Agent": CFG["user_agent"],
         "Accept": "*/*",
         "Connection": "close"}
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, headers=h, method=method)
    t0 = time.perf_counter()
    status, rheaders, body, err = None, {}, b"", None
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            status = r.status
            rheaders = {k.lower(): v for k, v in r.headers.items()}
            body = r.read(max_body)
    except urllib.error.HTTPError as e:
        status = e.code
        rheaders = {k.lower(): v for k, v in e.headers.items()} if e.headers else {}
        try:
            body = e.read(max_body)
        except Exception:
            body = b""
    except Exception as e:
        err = str(e) or e.__class__.__name__
    return {
        "status": status,
        "headers": rheaders,
        "body": body,
        "elapsed_ms": int((time.perf_counter() - t0) * 1000),
        "error": err,
        "url": url,
    }


def api_json(url, timeout=None):
    r = http_request(url, timeout=timeout)
    if r["error"] and not r["status"]:
        raise RuntimeError(r["error"])
    try:
        return json.loads(r["body"].decode("utf-8", "replace"))
    except Exception:
        raise RuntimeError("bad API response")


def resolve_host(host):
    """-> list of ip strings"""
    infos = socket.getaddrinfo(host.strip(), None, socket.AF_INET)
    out, seen = [], set()
    for inf in infos:
        ip = inf[4][0]
        if ip not in seen:
            seen.add(ip)
            out.append(ip)
    return out


def ip_info(query, deep=False):
    """IP/domain intelligence via public API (no key needed)."""
    if deep:
        fields = ("status,message,country,countryCode,region,regionName,city,"
                  "district,zip,lat,lon,timezone,offset,currency,isp,org,as,"
                  "asname,reverse,mobile,proxy,hosting,query")
    else:
        fields = ("status,message,country,countryCode,regionName,city,"
                  "timezone,isp,org,as,lat,lon,query")
    data = api_json("http://ip-api.com/json/{}?fields={}".format(
        urllib.parse.quote(str(query)), fields))
    if deep and data.get("status") == "success":
        try:
            socket.gethostbyaddr(data["query"])
        except Exception:
            pass
    return data


def mac_vendor(mac):
    """Vendor lookup for a MAC address (rate limited upstream, 1 req/sec)."""
    mac = mac.replace(":", "").replace("-", "").replace(".", "").strip().upper()
    if len(mac) < 6 or not all(c in "0123456789ABCDEF" for c in mac[:6]):
        raise ValueError("invalid MAC address")
    prefix = mac[:6]
    r = http_request("https://api.macvendors.com/" + prefix, timeout=6)
    if r["status"] == 200 and r["body"]:
        return r["body"].decode("utf-8", "replace").strip()
    if r["status"] == 404:
        return "UNKNOWN VENDOR"
    raise RuntimeError(r["error"] or ("HTTP " + str(r["status"])))


def tcp_probe(host, port, timeout=None, banner_wait=0.9, http_probe=False):
    """Single TCP connect. Returns dict(ok, latency_ms, banner)."""
    timeout = timeout or CFG["scan_timeout"]
    out = {"port": port, "ok": False, "latency_ms": None, "banner": ""}
    t0 = time.perf_counter()
    sock = None
    try:
        sock = socket.create_connection((host, port), timeout=timeout)
        out["ok"] = True
        out["latency_ms"] = int((time.perf_counter() - t0) * 1000)
        sock.settimeout(banner_wait)
        try:
            chunk = sock.recv(512)
            out["banner"] = chunk.decode("utf-8", "replace").strip()
        except Exception:
            pass
        if http_probe and not out["banner"]:
            try:
                sock.sendall(("GET / HTTP/1.1\r\nHost: {}\r\n"
                              "User-Agent: {}\r\nConnection: close\r\n\r\n"
                              ).format(host, CFG["user_agent"]).encode())
                chunk = sock.recv(512)
                out["banner"] = chunk.decode("utf-8", "replace").strip()
            except Exception:
                pass
    except Exception:
        out["ok"] = False
    finally:
        if sock:
            try:
                sock.close()
            except Exception:
                pass
    return out


def scan_ports(host, ports, timeout=None, workers=64, stop=None, progress=None):
    """Threaded TCP port scan with service names + banner grabbing.
    -> list of open-port dicts sorted by port."""
    results = []
    total = len(ports)
    done = [0]
    lock = threading.Lock()

    def work(port):
        if stop is not None and stop.is_set():
            return None
        probe = tcp_probe(host, port, timeout=timeout)
        with lock:
            done[0] += 1
            if progress is not None and done[0] % 5 == 0:
                progress(done[0], total)
        if probe["ok"]:
            return {
                "port": port,
                "service": PORTS.get(str(port), "unknown"),
                "latency_ms": probe["latency_ms"],
                "banner": probe["banner"][:200],
            }
        return None

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futs = [pool.submit(work, p) for p in ports]
        for f in concurrent.futures.as_completed(futs):
            if stop is not None and stop.is_set():
                break
            r = f.result()
            if r:
                results.append(r)
    results.sort(key=lambda d: d["port"])
    return results


def port_list(preset, custom=None):
    """Build the port list from a preset name."""
    common = [21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 161, 389, 443,
              445, 465, 587, 631, 636, 993, 995, 1433, 1521, 2049, 3306, 3389,
              5432, 5900, 6379, 8080, 8443, 9200, 27017]
    wide = common + [20, 23, 67, 69, 79, 88, 113, 123, 138, 144, 162, 179,
                     514, 515, 548, 554, 1080, 1723, 1883, 2082, 2083, 2181,
                     3128, 3268, 4444, 5000, 5555, 5672, 5984, 6667, 8000,
                     8008, 8081, 8888, 9000, 9090, 11211, 32768, 49152, 6443]
    if preset == "QUICK (32 PORTS)":
        return common
    if preset == "STANDARD (80 PORTS)":
        return wide
    if preset == "FULL (1-1024)":
        return list(range(1, 1025))
    if preset == "CUSTOM" and custom:
        ports = set()
        for part in str(custom).split(","):
            part = part.strip()
            if not part:
                continue
            if "-" in part:
                a, b = part.split("-", 1)
                ports.update(range(int(a), int(b) + 1))
            else:
                ports.add(int(part))
        return sorted(p for p in ports if 0 < p < 65536)
    return common


# ------------------------------------------------------------
#  WHOIS (raw socket, port 43, iana referral)
# ------------------------------------------------------------

def whois_query(server, query, timeout=8):
    s = socket.create_connection((server, 43), timeout=timeout)
    try:
        s.sendall((query + "\r\n").encode())
        chunks = []
        s.settimeout(timeout)
        while True:
            try:
                chunk = s.recv(4096)
            except socket.timeout:
                break
            if not chunk:
                break
            chunks.append(chunk)
        return b"".join(chunks).decode("utf-8", "replace")
    finally:
        s.close()


def whois(domain, timeout=8):
    domain = domain.strip().lower()
    if "/" in domain or "@" in domain:
        raise ValueError("not a domain name")
    first = whois_query("whois.iana.org", domain, timeout)
    for line in first.splitlines():
        low = line.strip().lower()
        if low.startswith("refer:") or low.startswith("whois:") or low.startswith("registrar whois server:"):
            server = line.split(":", 1)[1].strip()
            if server:
                try:
                    return whois_query(server, domain, timeout), server
                except Exception:
                    pass
    return first, "whois.iana.org"


# ------------------------------------------------------------
#  RAW DNS RESOLVER (UDP -- A/AAAA/MX/NS/TXT/CNAME/SOA)
# ------------------------------------------------------------

QTYPE = {"A": 1, "NS": 2, "CNAME": 5, "SOA": 6, "MX": 15, "TXT": 16, "AAAA": 28}
RTYPE = {v: k for k, v in QTYPE.items()}
RESOLVERS = ["8.8.8.8", "1.1.1.1", "9.9.9.9"]


def _enc_name(name):
    out = b""
    for part in name.strip(".").split("."):
        if part:
            b = part.encode("idna") if any(ord(c) > 127 for c in part) else part.encode()
            out += bytes([len(b)]) + b
    return out + b"\x00"


def _dns_packet(name, qtype):
    ident = secrets.randbits(16)
    header = struct.pack(">HHHHHH", ident, 0x0100, 1, 0, 0, 0)
    return ident, header + _enc_name(name) + struct.pack(">HH", qtype, 1)


def _read_name(data, off):
    labels, jumped = [], False
    orig = off
    while True:
        if off >= len(data):
            raise ValueError("dns: truncated")
        ln = data[off]
        if ln == 0:
            off += 1
            break
        if ln & 0xC0 == 0xC0:
            ptr = struct.unpack(">H", data[off:off + 2])[0] & 0x3FFF
            if not jumped:
                orig = off + 2
            off = ptr
            jumped = True
            continue
        labels.append(data[off + 1:off + 1 + ln].decode("utf-8", "replace"))
        off += 1 + ln
    name = ".".join(labels) if labels else "."
    return name, (orig if jumped else off)


def dns_lookup(name, rtype="A", timeout=4, resolver=None):
    """-> list of record value strings"""
    qtype = QTYPE[rtype.upper()]
    name = name.strip().rstrip(".")
    servers = [resolver] if resolver else RESOLVERS
    last_err = None
    for srv in servers:
        try:
            ident, pkt = _dns_packet(name, qtype)
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(timeout)
            s.sendto(pkt, (srv, 53))
            data, _ = s.recvfrom(4096)
            s.close()
            if len(data) < 12 or struct.unpack(">H", data[:2])[0] != ident:
                continue
            flags = struct.unpack(">H", data[2:4])[0]
            rcode = flags & 0x0F
            qd, an = struct.unpack(">HH", data[4:8])
            off = 12
            for _ in range(qd):
                _, off = _read_name(data, off)
                off += 4
            values = []
            for _ in range(an):
                _, off = _read_name(data, off)
                rtype_n, _, _, rdlen = struct.unpack(">HHIH", data[off:off + 10])
                off += 10
                rd = data[off:off + rdlen]
                if rcode == 3:  # NXDOMAIN
                    return ["NXDOMAIN"]
                if rtype_n == 1 and len(rd) == 4:
                    values.append(socket.inet_ntoa(rd))
                elif rtype_n == 28 and len(rd) == 16:
                    values.append(socket.inet_ntop(socket.AF_INET6, rd))
                elif rtype_n in (2, 5, 12):
                    target, _ = _read_name(data, off)
                    values.append(target)
                elif rtype_n == 15 and len(rd) >= 3:
                    pref = struct.unpack(">H", rd[:2])[0]
                    host, _ = _read_name(data, off + 2)
                    values.append("{} {}".format(pref, host))
                elif rtype_n == 16:
                    parts, p = [], 0
                    while p < len(rd):
                        ln = rd[p]
                        parts.append(rd[p + 1:p + 1 + ln].decode("utf-8", "replace"))
                        p += 1 + ln
                    values.append(" ".join(parts))
                elif rtype_n == 6:
                    mname, o1 = _read_name(data, off)
                    rname, _ = _read_name(data, o1)
                    values.append("{} {}".format(mname, rname))
                off += rdlen
            if values:
                return values
            if rcode == 0:
                return []
        except Exception as e:
            last_err = e
            continue
    if last_err:
        raise RuntimeError("DNS failed: {}".format(last_err))
    return []


def subdomain_scan(domain, prefixes, workers=24, stop=None):
    """Resolve candidate subdomains. -> list of (subdomain, ip)"""
    found = []

    def work(prefix):
        if stop is not None and stop.is_set():
            return None
        host = "{}.{}".format(prefix.strip(), domain)
        try:
            ip = socket.gethostbyname(host)
            return (host, ip)
        except Exception:
            return None

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futs = [pool.submit(work, p) for p in prefixes]
        for f in concurrent.futures.as_completed(futs):
            if stop is not None and stop.is_set():
                break
            r = f.result()
            if r:
                found.append(r)
    found.sort(key=lambda t: t[0])
    return found


# ------------------------------------------------------------
#  UTILITIES: hash / encoders / password / ping
# ------------------------------------------------------------

def hash_compute(text, algo):
    h = hashlib.new(algo)
    h.update(text.encode("utf-8"))
    return h.hexdigest()


HASH_LEN_MAP = {
    32: ["MD5", "NTLM", "MD4", "LM"],
    40: ["SHA-1", "MySQL5"],
    56: ["SHA-224", "SHA3-224"],
    64: ["SHA-256", "SHA3-256", "BLAKE2s"],
    96: ["SHA-384", "SHA3-384"],
    128: ["SHA-512", "SHA3-512", "BLAKE2b", "Whirlpool"],
}


def hash_identify(value):
    v = value.strip().lower()
    if not v:
        return []
    if not all(c in "0123456789abcdef" for c in v):
        return []
    if "$" in value:
        if value.startswith("$2"):
            return ["bcrypt"]
        if value.startswith("$6$"):
            return ["sha512crypt"]
        if value.startswith("$5$"):
            return ["sha256crypt"]
        if value.startswith("$1$"):
            return ["md5crypt"]
        return ["salted hash (crypt format)"]
    return HASH_LEN_MAP.get(len(v), ["UNKNOWN LENGTH {}".format(len(v))])


def enc_transform(text, method, mode):
    if method == "BASE64":
        if mode == "ENCODE":
            return base64.b64encode(text.encode("utf-8")).decode("ascii")
        pad = "=" * (-len(text.strip()) % 4)
        return base64.b64decode(text.strip() + pad).decode("utf-8", "replace")
    if method == "HEX":
        if mode == "ENCODE":
            return text.encode("utf-8").hex()
        return bytes.fromhex(text.strip()).decode("utf-8", "replace")
    if method == "URL":
        if mode == "ENCODE":
            return urllib.parse.quote(text, safe="")
        return urllib.parse.unquote(text)
    if method == "ROT13":
        return text.encode("utf-8").decode("rot13") if False else _rot13(text)
    raise ValueError("unknown method")


def _rot13(text):
    out = []
    for ch in text:
        o = ord(ch)
        if 65 <= o <= 90:
            out.append(chr((o - 65 + 13) % 26 + 65))
        elif 97 <= o <= 122:
            out.append(chr((o - 97 + 13) % 26 + 97))
        else:
            out.append(ch)
    return "".join(out)


PASS_SETS = {
    "lowercase": _string.ascii_lowercase,
    "uppercase": _string.ascii_uppercase,
    "digits": _string.digits,
    "symbols": "!@#$%^&*()-_=+[]{}<>?/",
}


def password_generate(length=16, sets=("lowercase", "uppercase", "digits", "symbols")):
    pool = "".join(PASS_SETS[s] for s in sets if s in PASS_SETS)
    if not pool:
        raise ValueError("select at least one character set")
    while True:
        pwd = "".join(secrets.choice(pool) for _ in range(length))
        if all(any(c in PASS_SETS[s] for c in pwd) for s in sets):
            return pwd, len(pool)


def entropy_bits(length, pool_size):
    if pool_size <= 1:
        return 0.0
    import math
    return length * math.log2(pool_size)


# ============================================================
#  UI PRIMITIVES  (neon / cut-corner design system)
# ============================================================

def pick_font(candidates, fallback):
    try:
        families = set(tkfont.families())
        for c in candidates:
            if c in families:
                return c
    except Exception:
        pass
    return fallback


def cut_pts(w, h, c=9):
    """Polygon points for a box with 45-degree cut corners."""
    return (c, 0, w - c, 0, w, c, w, h - c, w - c, h, c, h, 0, h - c, 0, c)


class NeonButton(tk.Canvas):
    """Cut-corner button with neon outline + hover glow."""

    def __init__(self, master, text, command=None, width=150, height=34,
                 cut=8, font=None, accent=None, text_color=None,
                 fill=None, dim=None, glow=None, **kw):
        try:
            base_bg = master.cget("bg")
        except Exception:
            base_bg = THEME["bg"]
        super().__init__(master, width=width, height=height, bg=base_bg,
                         highlightthickness=0, bd=0, **kw)
        self.cmd = command
        self.accent = accent or THEME["accent"]
        self.dim = dim or THEME["accent_dim"]
        self.glow = glow or THEME["glow"]
        self.text_color = text_color or THEME["text"]
        self.fill = fill or THEME["panel2"]
        self.enabled = True
        pts = cut_pts(width, height, cut)
        self._poly = self.create_polygon(pts, fill=self.fill,
                                         outline=self.dim, width=1)
        self._txt = self.create_text(width // 2, height // 2, text=text,
                                     fill=self.text_color,
                                     font=font or (APP_NAME, 10, "bold"),
                                     justify="center")
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<Button-1>", self._on_click)
        self.bind("<ButtonRelease-1>", self._on_release)

    def _on_enter(self, _):
        if self.enabled:
            self.itemconfig(self._poly, outline=self.accent, width=2)
            self.itemconfig(self._txt, fill=self.glow)
            self.config(cursor="hand2")

    def _on_leave(self, _):
        self.itemconfig(self._poly, outline=self.dim, width=1)
        self.itemconfig(self._txt, fill=self.text_color)

    def _on_click(self, _):
        if self.enabled:
            self.itemconfig(self._poly, fill=self.dim)

    def _on_release(self, _):
        if self.enabled:
            self.itemconfig(self._poly, fill=self.fill)
            if self.cmd:
                self.cmd()

    def set_enabled(self, enabled):
        self.enabled = enabled
        if not enabled:
            self.itemconfig(self._txt, fill=THEME["dim"])
            self.itemconfig(self._poly, outline=self.dim)
        else:
            self.itemconfig(self._txt, fill=self.text_color)


class CutPanel(tk.Canvas):
    """A panel with cut corners; child widgets placed via .put()."""

    def __init__(self, master, width, height, bg=None, outline=None,
                 cut=12, outline_w=1, **kw):
        try:
            base_bg = master.cget("bg")
        except Exception:
            base_bg = THEME["bg"]
        super().__init__(master, width=width, height=height, bg=base_bg,
                         highlightthickness=0, bd=0, **kw)
        self._cut = cut
        self._poly = self.create_polygon(cut_pts(width, height, cut),
                                         fill=bg or THEME["panel"],
                                         outline=outline or THEME["accent_dim"],
                                         width=outline_w)

    def put(self, widget, x, y, anchor="nw"):
        return self.create_window(x, y, window=widget, anchor=anchor)

    def set_outline(self, color):
        self.itemconfig(self._poly, outline=color)


class ScrollFrame(tk.Frame):
    """Vertical-scrollable frame (canvas trick)."""

    def __init__(self, master, bg=None, width=260, height=400):
        super().__init__(master, bg=bg or THEME["panel"], width=width,
                         height=height, highlightthickness=0)
        self.canvas = tk.Canvas(self, bg=bg or THEME["panel"],
                                highlightthickness=0, bd=0,
                                width=width, height=height)
        self.vsb = ttk.Scrollbar(self, orient="vertical",
                                 command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.vsb.set)
        self.vsb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.inner = tk.Frame(self.canvas, bg=bg or THEME["panel"])
        self._win = self.canvas.create_window((0, 0), window=self.inner,
                                              anchor="nw")
        self.inner.bind("<Configure>", self._on_inner_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)
        self.canvas.bind("<Enter>", self._bind_wheel)
        self.canvas.bind("<Leave>", self._unbind_wheel)

    def _on_inner_configure(self, _):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas_configure(self, event):
        self.canvas.itemconfig(self._win, width=event.width)

    def _wheel(self, event):
        delta = -1 if getattr(event, "delta", 0) > 0 or event.num == 4 else 1
        self.canvas.yview_scroll(delta, "units")

    def _bind_wheel(self, _):
        self.canvas.bind_all("<MouseWheel>", self._wheel)
        self.canvas.bind_all("<Button-4>", self._wheel)
        self.canvas.bind_all("<Button-5>", self._wheel)

    def _unbind_wheel(self, _):
        self.canvas.unbind_all("<MouseWheel>")
        self.canvas.unbind_all("<Button-4>")
        self.canvas.unbind_all("<Button-5>")


class ResultCard(tk.Frame):
    """Draggable result card: header bar (drag/open) + info grid."""

    def __init__(self, desk, app, rec):
        super().__init__(desk, bg=THEME["panel2"], highlightthickness=1,
                         highlightbackground=THEME["accent"], bd=0)
        self.desk = desk
        self.app = app
        self.rec = rec
        self.wid = None
        self.width = 312
        header = tk.Frame(self, bg=THEME["panel3"], height=30)
        header.pack(fill="x")
        header.pack_propagate(False)
        self.title = tk.Label(header, text=str(rec.get("ip", "?")),
                              bg=THEME["panel3"], fg=THEME["glow"],
                              font=(app.f_mono, 11, "bold"))
        self.title.pack(side="left", padx=10)
        mode = rec.get("mode", "SINGLE")
        tag_color = {"SINGLE": THEME["accent"], "DEEP": THEME["ok"],
                     "FILE": THEME["warn"]}.get(mode, THEME["accent"])
        tk.Label(header, text=mode, bg=THEME["panel3"], fg=tag_color,
                 font=(app.f_mono, 8, "bold")).pack(side="left", padx=6)
        close_lbl = tk.Label(header, text="[X]", bg=THEME["panel3"],
                             fg=THEME["dim"], font=(app.f_mono, 9, "bold"),
                             cursor="hand2")
        close_lbl.pack(side="right", padx=8)
        close_lbl.bind("<Button-1>", lambda e: desk.remove_card(self))

        body = tk.Frame(self, bg=THEME["panel2"])
        body.pack(fill="both", expand=True, padx=8, pady=(6, 2))
        rows = rec.get("rows", [])
        for i, (k, v) in enumerate(rows[:14]):
            tk.Label(body, text=k.upper(), bg=THEME["panel2"], fg=THEME["dim"],
                     font=(app.f_mono, 8, "bold"), anchor="w").grid(
                row=i, column=0, sticky="w", padx=(2, 10), pady=1)
            tk.Label(body, text=str(v)[:34], bg=THEME["panel2"],
                     fg=THEME["text"], font=(app.f_mono, 8), anchor="w").grid(
                row=i, column=1, sticky="w", pady=1)
        foot = tk.Frame(self, bg=THEME["panel2"])
        foot.pack(fill="x", pady=(2, 6), padx=8)
        if rec.get("mode") != "DEEP":
            b1 = tk.Label(foot, text="[ DEEP INFO ]", bg=THEME["panel2"],
                          fg=THEME["accent"], font=(app.f_mono, 8, "bold"),
                          cursor="hand2")
            b1.pack(side="left", padx=(2, 8))
            b1.bind("<Button-1>", lambda e: app.open_ip_record(rec, deep=True))
        ts = rec.get("saved_at", "")
        tk.Label(foot, text=ts, bg=THEME["panel2"], fg=THEME["dim"],
                 font=(app.f_mono, 7)).pack(side="right")
        self._bind_drag(header)
        self._bind_drag(self.title)
        header.bind("<Double-Button-1>", lambda e: app.open_ip_record(rec))

    # -- drag mechanics (header = titlebar) -------------------
    def _bind_drag(self, widget):
        widget.bind("<Button-1>", self._press, add="+")
        widget.bind("<B1-Motion>", self._motion, add="+")
        widget.bind("<ButtonRelease-1>", self._release, add="+")

    def _press(self, event):
        if self.wid is None:
            return
        x, y = self.desk.coords(self.wid)
        self._drag = {"px": event.x_root, "py": event.y_root,
                      "cx": x, "cy": y, "moved": False}

    def _motion(self, event):
        d = getattr(self, "_drag", None)
        if not d:
            return
        dx, dy = event.x_root - d["px"], event.y_root - d["py"]
        if abs(dx) + abs(dy) > 4:
            d["moved"] = True
        self.desk.coords(self.wid, d["cx"] + dx, d["cy"] + dy)

    def _release(self, event):
        d = getattr(self, "_drag", None)
        if d and not d["moved"]:
            self.app.open_ip_record(self.rec)
        self._drag = None


class Desk(tk.Canvas):
    """Workspace canvas where result cards float and drag."""

    def __init__(self, master, app):
        super().__init__(master, bg=THEME["bg"], highlightthickness=0, bd=0)
        self.app = app
        self.cards = {}
        self.bind("<Configure>", lambda e: self._draw_grid())

    def _draw_grid(self):
        self.delete("grid")
        w = max(self.winfo_width(), 400)
        h = max(self.winfo_height(), 300)
        for x in range(0, w, 46):
            self.create_line(x, 0, x, h, fill=THEME["accent_dim"],
                             dash=(1, 7), tags="grid")
        for y in range(0, h, 46):
            self.create_line(0, y, w, y, fill=THEME["accent_dim"],
                             dash=(1, 7), tags="grid")
        self.tag_lower("grid")

    def add_card(self, rec, x=24, y=24, cascade=True):
        rid = rec.get("id")
        if rid:
            for wid, c in self.cards.items():
                if c.rec.get("id") == rid:
                    self.coords(wid, 24, 24)
                    self.tag_raise(wid)
                    return c
        n = len(self.cards)
        if cascade:
            x = 24 + (n % 7) * 36
            y = 24 + (n // 7) * 46
        card = ResultCard(self, self.app, rec)
        card.wid = self.create_window(x, y, window=card, anchor="nw")
        self.cards[card.wid] = card
        self.tag_raise(card.wid)
        return card

    def remove_card(self, card):
        for wid, c in list(self.cards.items()):
            if c is card:
                del self.cards[wid]
                self.delete(wid)
                card.destroy()
                return

    def clear(self):
        for wid, c in list(self.cards.items()):
            self.delete(wid)
            c.destroy()
        self.cards = {}


# ============================================================
#  SPLASH  (boot sequence: logo, vault decryption, sound)
# ============================================================

class Splash(tk.Toplevel):

    def __init__(self, app, on_done):
        super().__init__(app, bg="#05030a")
        self.overrideredirect(True)
        self.on_done = on_done
        W, H = 560, 690
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry("{}x{}+{}+{}".format(W, H, (sw - W) // 2, (sh - H) // 2))
        self.attributes("-topmost", True)

        c = tk.Canvas(self, width=W, height=H, bg="#05030a",
                      highlightthickness=0)
        c.pack(fill="both", expand=True)

        # outer frame
        c.create_polygon(cut_pts(W - 24, H - 24, 16), fill="",
                         outline=THEME["accent_dim"], width=1)

        # logo (square, dead center top)
        c.create_image(W // 2, 150, image=app.assets.logo_splash)

        # glowing brand text (layered)
        ty = 300
        for ox, oy, col in ((3, 0, THEME["accent2"]), (-3, 0, THEME["accent2"]),
                            (0, 3, THEME["accent2"]), (0, -3, THEME["accent2"])):
            c.create_text(W // 2 + ox, ty + oy, text=APP_NAME,
                          fill=col, font=(app.f_ui, 40, "bold"))
        self._brand_glow = c.create_text(W // 2, ty, text=APP_NAME,
                                         fill=THEME["glow"],
                                         font=(app.f_ui, 40, "bold"))
        c.create_text(W // 2, ty + 38, text="DARKPIPE EDITION // v" + APP_VERSION,
                      fill=THEME["dim"], font=(app.f_mono, 10))

        # anonymous image under the brand name
        c.create_image(W // 2, 452, image=app.assets.mask_splash)
        c.create_text(W // 2, 530, text="ANONYMOUS ACCESS MODULE",
                      fill=THEME["accent"], font=(app.f_mono, 9, "bold"))

        # progress bar (cut-corner frame, fill grows from left)
        bx, by, bw, bh = 110, 588, 340, 14
        _bp = cut_pts(bw, bh, 5)
        c.create_polygon([(bx + _bp[i], by + _bp[i + 1])
                          for i in range(0, len(_bp), 2)],
                         fill=THEME["panel2"], outline=THEME["accent_dim"])
        self._bar_cv = c
        self._bar_x, self._bar_y = bx, by
        self._bar_w, self._bar_h = bw, bh

        self._status = c.create_text(W // 2, 634, text="DECRYPTING VAULT...",
                                     fill=THEME["accent"],
                                     font=(app.f_mono, 10, "bold"))
        c.create_text(W // 2, 660, text="AUTHORIZED USE ONLY",
                      fill=THEME["dim"], font=(app.f_mono, 8))

        # boot timeline (times scale to the number of lines)
        lines = CORE["boot_lines"]
        t0, t1 = 300, 2900
        for i, line in enumerate(lines):
            frac = (i + 1) / len(lines)
            when = t0 + int((t1 - t0) * i / max(1, len(lines) - 1))
            self.after(when, lambda f=frac, s=line:
                       self._step(f, s))
        self._pulse_state = 0
        self._pulse()
        self.after(150, play_boot_sound)
        self.after(3450, self._finish)

    def _pulse(self):
        self._pulse_state = 1 - self._pulse_state
        col = THEME["glow"] if self._pulse_state else THEME["accent"]
        try:
            self._bar_cv.itemconfig(self._brand_glow, fill=col)
        except Exception:
            return
        self.after(420, self._pulse)

    def _step(self, frac, status):
        self._bar_cv.delete("barfill")
        self._bar_cv.create_rectangle(
            self._bar_x + 2, self._bar_y + 2,
            self._bar_x + 2 + int((self._bar_w - 4) * frac),
            self._bar_y + self._bar_h - 2,
            fill=THEME["accent"], width=0, tags="barfill")
        self._bar_cv.itemconfig(self._status, text=status + " ...")

    def _finish(self):
        try:
            self.on_done()
        finally:
            self.destroy()


# ============================================================
#  APPLICATION SHELL
# ============================================================

MENU = [
    ("ip",   "01", "IP SCANNER",     "IP SCANNER",       "SINGLE / FILE BATCH / DEEP INFO"),
    ("nmap", "02", "NMAP SCAN",      "NMAP SCAN",        "PORTS / SERVICES / LATENCY / ISP"),
    ("fuzz", "03", "FUZZER",         "PATH FUZZER",      "DIRECTORY GUESS // site.com/admin"),
    ("dns",  "04", "DNS / WHOIS",    "DNS / WHOIS",      "RECORDS + REGISTRY DATA"),
    ("subd", "05", "SUBDOMAINS",     "SUBDOMAIN FINDER", "DNS BRUTE RESOLUTION"),
    ("head", "06", "HEADERS",        "HEADER ANALYZER",  "RESPONSE + SECURITY AUDIT"),
    ("bann", "07", "BANNER GRAB",    "BANNER GRABBER",   "RAW SERVICE IDENTIFICATION"),
    ("hash", "08", "HASH TOOLS",     "HASH TOOLS",       "GENERATE / IDENTIFY"),
    ("enc",  "09", "ENCODER",        "ENCODER / DECODER","BASE64 / HEX / URL / ROT13"),
    ("mac",  "10", "MAC VENDOR",     "MAC VENDOR",       "OUI VENDOR LOOKUP"),
    ("ping", "11", "PING MONITOR",   "PING MONITOR",     "LIVE LATENCY TRACKING"),
    ("pgen", "12", "PASS GEN",       "PASSWORD GENERATOR", "CRYPTO-STRENGTH"),
    ("log",  "13", "SESSION LOG",    "SESSION LOG",      "FULL OPERATION HISTORY"),
    ("apk",  "14", "APK SENTINEL",   "APK SENTINEL",     "LOCAL AI // DEX VULN SCAN"),
    ("coms", "15", "SECURE COMMS",   "SECURE COMMS",     "AES-256 ENCRYPTED CHANNEL"),
    ("tls",  "16", "TLS AUDIT",      "TLS AUDITOR",      "CERT / PROTOCOL / CIPHER"),
    ("vuln", "17", "VULN MATCH",     "VULN MATCHER",     "BANNER -> CVE MINI-DB"),
    ("steg", "18", "STEGA HIDE",     "STEGA HIDE",       "PNG LSB STEGANOGRAPHY"),
]


class Assets:
    """Every image is decoded from the encrypted vault, memory only."""

    def __init__(self, root):
        def img(name):
            # GIF payload loads on every Tk build (8.6 / 9.x)
            raw, _ = vault_read(name)
            return tk.PhotoImage(
                data=base64.b64encode(raw).decode("ascii"))

        self.logo_full = img("logo.nxp")                    # 1024x1024
        self.logo_splash = self.logo_full.subsample(5)      # ~205px
        self.logo_side = self.logo_full.subsample(16)       # 64px
        self.mask_full = img("mask.nxp")
        self.mask_splash = self.mask_full.subsample(8)      # 128px
        self.bg_full = img("bg.nxp")                        # 1344x768


class App(tk.Tk):

    def __init__(self):
        super().__init__()
        self.withdraw()
        self.title(APP_NAME + " // " + APP_CODENAME + " v" + APP_VERSION)
        self.configure(bg=THEME["bg"])
        self.f_mono = pick_font(
            ["Cascadia Mono", "Consolas", "JetBrains Mono",
             "DejaVu Sans Mono", "Menlo"], "Courier")
        self.f_ui = pick_font(
            ["Segoe UI", "Helvetica Neue", "Arial"], "Helvetica")
        self.assets = Assets(self)
        self.store = DataStore()
        self.q = queue.Queue()
        self.pages = {}
        self.menu_buttons = {}
        self.current = None
        self.online = None
        self._setup_styles()
        self.after(90, self._poll)

    # ---- thread -> UI bridge --------------------------------
    def run_async(self, fn, on_done, on_error=None):
        def worker():
            try:
                res = fn()
                self.q.put(("ok", on_done, res))
            except Exception as e:
                self.q.put(("err", on_error, e))
        threading.Thread(target=worker, daemon=True).start()

    def _poll(self):
        try:
            while True:
                kind, cb, val = self.q.get_nowait()
                if kind == "ok" and cb:
                    cb(val)
                elif kind == "err":
                    if cb:
                        cb(val)
                    else:
                        self.default_error(val)
        except queue.Empty:
            pass
        self.after(90, self._poll)

    def default_error(self, e):
        self.hstatus.config(text="ERR: " + str(e)[:64], fg=THEME["bad"])
        self.after(6000, lambda: self._reset_hstatus())

    def _reset_hstatus(self):
        try:
            self.hstatus.config(text="STANDBY", fg=THEME["dim"])
        except Exception:
            pass

    # ---- boot -----------------------------------------------
    def start_splash(self):
        Splash(self, self._enter_main)

    def _enter_main(self):
        self.build_main()
        self.deiconify()
        self._check_online()

    def _check_online(self):
        def fn():
            r = http_request("http://ip-api.com/json/?fields=status", timeout=6)
            return r["status"] == 200
        self.run_async(fn, self._set_online)

    def _set_online(self, ok):
        self.online = bool(ok)
        col = THEME["ok"] if ok else THEME["warn"]
        try:
            self.dot.itemconfig(self._dot_item, fill=col)
        except Exception:
            pass
        self.netlbl.config(text="ONLINE" if ok else "OFFLINE", fg=col)
        self.hstatus.config(text="LINK " + ("ACTIVE" if ok else "DEGRADED"),
                            fg=col)
        self.after(6000, self._reset_hstatus)

    # ---- styles ---------------------------------------------
    def _setup_styles(self):
        st = ttk.Style(self)
        try:
            st.theme_use("clam")
        except Exception:
            pass
        st.configure("Treeview",
                     background=THEME["panel2"],
                     fieldbackground=THEME["panel2"],
                     foreground=THEME["text"],
                     rowheight=24,
                     bordercolor=THEME["accent_dim"],
                     borderwidth=1,
                     font=(self.f_mono, 9))
        st.configure("Treeview.Heading",
                     background=THEME["panel3"],
                     foreground=THEME["accent"],
                     font=(self.f_mono, 9, "bold"),
                     borderwidth=0)
        st.map("Treeview",
               background=[("selected", THEME["accent_dim"])],
               foreground=[("selected", THEME["glow"])])
        st.configure("TScrollbar",
                     background=THEME["panel3"],
                     troughcolor=THEME["bg"],
                     bordercolor=THEME["accent_dim"],
                     arrowcolor=THEME["accent"])
        st.configure("TCombobox",
                     fieldbackground=THEME["panel2"],
                     background=THEME["panel3"],
                     foreground=THEME["text"],
                     arrowcolor=THEME["accent"],
                     bordercolor=THEME["accent_dim"],
                     lightcolor=THEME["panel2"],
                     darkcolor=THEME["panel2"])
        st.map("TCombobox",
               fieldbackground=[("readonly", THEME["panel2"])],
               foreground=[("readonly", THEME["text"])])
        st.configure("Horizontal.TProgressbar",
                     background=THEME["accent"],
                     troughcolor=THEME["panel2"],
                     bordercolor=THEME["accent_dim"],
                     thickness=10)
        self.option_add("*TCombobox*Listbox.background", THEME["panel2"])
        self.option_add("*TCombobox*Listbox.foreground", THEME["text"])
        self.option_add("*TCombobox*Listbox.selectBackground",
                        THEME["accent_dim"])
        self.option_add("*TCombobox*Listbox.selectForeground", THEME["glow"])

    # ---- main window ----------------------------------------
    def build_main(self):
        W, H = 1280, 800
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry("{}x{}+{}+{}".format(W, H, (sw - W) // 2, (sh - H) // 2))
        self.minsize(1120, 700)

        bg = tk.Label(self, image=self.assets.bg_full, bd=0)
        bg.place(relx=0.5, rely=0.5, anchor="center")

        # --- sidebar ---
        self.sidebar = tk.Frame(self, bg=THEME["panel"], width=232,
                                highlightthickness=1,
                                highlightbackground=THEME["accent_dim"])
        self.sidebar.place(x=10, y=10, width=232, relheight=1.0, height=-20)
        self.sidebar.pack_propagate(False)

        top = tk.Frame(self.sidebar, bg=THEME["panel"])
        top.pack(fill="x", pady=(16, 10), padx=14)
        tk.Label(top, image=self.assets.logo_side,
                 bg=THEME["panel"]).pack(side="left")
        tbox = tk.Frame(top, bg=THEME["panel"])
        tbox.pack(side="left", padx=10)
        tk.Label(tbox, text=APP_NAME, bg=THEME["panel"], fg=THEME["glow"],
                 font=(self.f_ui, 16, "bold")).pack(anchor="w")
        tk.Label(tbox, text=APP_CODENAME + " v" + APP_VERSION,
                 bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.f_mono, 8)).pack(anchor="w")

        menu = tk.Frame(self.sidebar, bg=THEME["panel"])
        menu.pack(fill="both", expand=True, pady=(4, 0))
        for key, num, label, _t, _s in MENU:
            btn = NeonButton(menu, num + "   " + label, width=206, height=32,
                             font=(self.f_mono, 9, "bold"),
                             command=lambda k=key: self.show_tool(k))
            btn.pack(pady=2, padx=13, anchor="w")
            self.menu_buttons[key] = btn

        foot = tk.Frame(self.sidebar, bg=THEME["panel"])
        foot.pack(fill="x", pady=10, padx=16)
        tk.Label(foot, text="VAULT : LOCKED", bg=THEME["panel"],
                 fg=THEME["ok"], font=(self.f_mono, 8, "bold")).pack(anchor="w")
        tk.Label(foot, text="PIPELINE : ENCRYPTED", bg=THEME["panel"],
                 fg=THEME["dim"], font=(self.f_mono, 8)).pack(anchor="w")
        tk.Label(foot, text="AUTHORIZED USE ONLY", bg=THEME["panel"],
                 fg=THEME["accent_dim"], font=(self.f_mono, 7)).pack(anchor="w")

        # --- main column ---
        mc = tk.Frame(self, bg=THEME["bg"])
        mc.place(x=252, y=10, relwidth=1.0, width=-262, relheight=1.0,
                 height=-20)
        header = tk.Frame(mc, bg=THEME["panel"], height=58,
                          highlightthickness=1,
                          highlightbackground=THEME["accent_dim"])
        header.pack(fill="x")
        header.pack_propagate(False)
        hleft = tk.Frame(header, bg=THEME["panel"])
        hleft.pack(side="left", padx=16)
        self.h_title = tk.Label(hleft, text=APP_NAME, bg=THEME["panel"],
                                fg=THEME["glow"], font=(self.f_ui, 15, "bold"))
        self.h_title.pack(anchor="w")
        self.h_sub = tk.Label(hleft, text="INITIALIZING...",
                              bg=THEME["panel"], fg=THEME["dim"],
                              font=(self.f_mono, 8))
        self.h_sub.pack(anchor="w")
        hright = tk.Frame(header, bg=THEME["panel"])
        hright.pack(side="right", padx=16)
        self.dot = tk.Canvas(hright, width=10, height=10, bg=THEME["panel"],
                             highlightthickness=0)
        self._dot_item = self.dot.create_oval(1, 1, 9, 9, fill=THEME["warn"],
                                              outline="")
        self.dot.pack(side="left", pady=(0, 0))
        self.netlbl = tk.Label(hright, text="SCANNING", bg=THEME["panel"],
                               fg=THEME["warn"], font=(self.f_mono, 8, "bold"))
        self.netlbl.pack(side="left", padx=(6, 14))
        self.clock = tk.Label(hright, text="--:--:--", bg=THEME["panel"],
                              fg=THEME["accent"],
                              font=(self.f_mono, 11, "bold"))
        self.clock.pack(side="left")
        self.hstatus = tk.Label(header, text="STANDBY", bg=THEME["panel"],
                                fg=THEME["dim"], font=(self.f_mono, 9))
        self.hstatus.place(relx=0.52, rely=0.5, anchor="center")

        self.container = tk.Frame(mc, bg=THEME["bg"])
        self.container.pack(fill="both", expand=True, pady=(8, 0))
        self._tick_clock()
        self.show_tool("ip")

    def show_tool(self, key):
        if key not in self.pages:
            cls = PAGE_CLASSES[key]
            page = cls(self.container, self)
            page.place(x=0, y=0, relwidth=1.0, relheight=1.0)
            self.pages[key] = page
        page = self.pages[key]
        page.tkraise()
        self.current = key
        for k, btn in self.menu_buttons.items():
            btn.itemconfig(btn._poly,
                           outline=THEME["accent"] if k == key else THEME["dim"],
                           width=2 if k == key else 1)
        entry = next(m for m in MENU if m[0] == key)
        self.h_title.config(text=entry[3])
        self.h_sub.config(text=entry[4])
        if hasattr(page, "on_show"):
            page.on_show()

    def _tick_clock(self):
        self.clock.config(text=datetime.now().strftime("%H:%M:%S"))
        self.after(1000, self._tick_clock)

    # ---- record flow ----------------------------------------
    def open_ip_record(self, rec, deep=False):
        self.show_tool("ip")
        page = self.pages["ip"]
        if deep:
            page.run(lambda: ip_info(rec["ip"], deep=True),
                     lambda data: page.add_deep(rec, data),
                     busy="DEEP INFO: " + str(rec["ip"]))
        else:
            page.show_record(rec)


# ============================================================
#  PAGE BASE
# ============================================================

class BasePage(tk.Frame):

    TITLE = "TOOL"
    SUB = ""

    def __init__(self, master, app):
        super().__init__(master, bg=THEME["bg"])
        self.app = app
        self._stop = threading.Event()
        self._build_header()
        self.build()

    def _build_header(self):
        bar = tk.Frame(self, bg=THEME["bg"])
        bar.pack(fill="x", padx=14, pady=(6, 10))
        left = tk.Frame(bar, bg=THEME["bg"])
        left.pack(side="left")
        tk.Label(left, text=self.TITLE, bg=THEME["bg"], fg=THEME["glow"],
                 font=(self.app.f_ui, 18, "bold")).pack(anchor="w")
        tk.Label(left, text=self.SUB, bg=THEME["bg"], fg=THEME["dim"],
                 font=(self.app.f_mono, 8)).pack(anchor="w")
        self._status = tk.Label(bar, text="STANDBY", bg=THEME["bg"],
                                fg=THEME["dim"], font=(self.app.f_mono, 9, "bold"))
        self._status.pack(side="right")

    def status(self, text, color=None):
        self._status.config(text=text, fg=color or THEME["dim"])

    def run(self, fn, on_done, on_error=None, busy="RUNNING..."):
        self.status(busy, THEME["warn"])

        def ok(res):
            self.status("DONE", THEME["ok"])
            on_done(res)

        def err(e):
            self.status("ERROR", THEME["bad"])
            if on_error:
                on_error(e)
            else:
                self.app.default_error(e)

        self.app.run_async(fn, ok, err)

    def build(self):
        raise NotImplementedError

    def on_show(self):
        pass

    def entry(self, parent, width=28, placeholder=""):
        e = tk.Entry(parent, bg=THEME["panel2"], fg=THEME["text"],
                     insertbackground=THEME["accent"], relief="flat",
                     font=(self.app.f_mono, 10), width=width,
                     highlightthickness=1,
                     highlightbackground=THEME["accent_dim"],
                     highlightcolor=THEME["accent"])
        if placeholder:
            e.insert(0, placeholder)
        return e

    def label_pair(self, parent, key):
        row = tk.Frame(parent, bg=THEME["panel"])
        row.pack(fill="x", pady=1)
        tk.Label(row, text=key, bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.app.f_mono, 8, "bold"), width=12,
                 anchor="w").pack(side="left")
        val = tk.Label(row, text="--", bg=THEME["panel"], fg=THEME["text"],
                       font=(self.app.f_mono, 9), anchor="w")
        val.pack(side="left", padx=4)
        return val


# ============================================================
#  TOOL 01 -- IP SCANNER
# ============================================================

def ip_rows(data, deep=False):
    rows = [
        ("COUNTRY", "{} ({})".format(data.get("country", "?"),
                                     data.get("countryCode", "--"))),
        ("CITY", "{}, {}".format(data.get("city", "--"),
                                 data.get("regionName", "--"))),
        ("ISP", data.get("isp", "--")),
        ("ORG", data.get("org", "--")),
        ("AS", data.get("as", "--")),
        ("TIMEZONE", data.get("timezone", "--")),
        ("LAT/LON", "{}, {}".format(data.get("lat", "--"),
                                    data.get("lon", "--"))),
    ]
    if deep:
        rows += [
            ("DISTRICT", data.get("district", "--") or "--"),
            ("ZIP", data.get("zip", "--") or "--"),
            ("CURRENCY", data.get("currency", "--") or "--"),
            ("REVERSE DNS", data.get("reverse", "--") or "--"),
            ("MOBILE", "YES" if data.get("mobile") else "NO"),
            ("PROXY/VPN", "YES" if data.get("proxy") else "NO"),
            ("HOSTING/DC", "YES" if data.get("hosting") else "NO"),
            ("GMT OFFSET", str(data.get("offset", "--"))),
        ]
    return rows


class SavedBox(tk.Frame):
    """Box in the left rail: every scan lands here, headed by the IP."""

    def __init__(self, master, app, rec):
        super().__init__(master, bg=THEME["panel2"], highlightthickness=1,
                         highlightbackground=THEME["accent_dim"], cursor="hand2")
        head = tk.Frame(self, bg=THEME["panel3"], height=24)
        head.pack(fill="x")
        head.pack_propagate(False)
        tk.Label(head, text=str(rec.get("ip", "?")), bg=THEME["panel3"],
                 fg=THEME["glow"], font=(app.f_mono, 9, "bold")).pack(
            side="left", padx=8)
        tk.Label(head, text=rec.get("mode", ""), bg=THEME["panel3"],
                 fg=THEME["accent"], font=(app.f_mono, 7, "bold")).pack(
            side="right", padx=8)
        tk.Label(self, text=rec.get("saved_at", ""), bg=THEME["panel2"],
                 fg=THEME["dim"], font=(app.f_mono, 7)).pack(
            anchor="w", padx=8, pady=2)
        for w in (self, head):
            w.bind("<Button-1>", lambda e, r=rec: app.open_ip_record(r))
            w.bind("<Enter>",
                   lambda e, s=self: s.config(
                       highlightbackground=THEME["accent"]))
            w.bind("<Leave>",
                   lambda e, s=self: s.config(
                       highlightbackground=THEME["accent_dim"]))


class IpPage(BasePage):

    TITLE = "IP SCANNER"
    SUB = "SINGLE TARGET / FILE BATCH / DEEP INTELLIGENCE"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="TARGET", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.target = self.entry(inner, width=30, placeholder="8.8.8.8 or example.com")
        self.target.pack(side="left", padx=(10, 10))
        self.target.bind("<Return>", lambda e: self.scan_single(False))
        NeonButton(inner, "SCAN", width=110, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=lambda: self.scan_single(False)).pack(side="left",
                                                                 padx=2)
        NeonButton(inner, "SCAN + DEEP", width=150, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=lambda: self.scan_single(True)).pack(side="left",
                                                                padx=2)
        NeonButton(inner, "LOAD FILE", width=120, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.load_file).pack(side="left", padx=2)
        NeonButton(inner, "STOP", width=70, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.stop_batch).pack(side="left", padx=2)
        tk.Label(inner, text="AUTO-DETECT: IP / DOMAIN", bg=THEME["panel"],
                 fg=THEME["dim"], font=(self.app.f_mono, 8)).pack(
            side="right", padx=4)

        body = tk.Frame(self, bg=THEME["bg"])
        body.pack(fill="both", expand=True, padx=14)

        # left rail: saved target boxes
        rail = tk.Frame(body, bg=THEME["panel"], width=270,
                        highlightthickness=1,
                        highlightbackground=THEME["accent_dim"])
        rail.pack(side="left", fill="y")
        rail.pack_propagate(False)
        rail_head = tk.Frame(rail, bg=THEME["panel"])
        rail_head.pack(fill="x", padx=10, pady=(10, 4))
        tk.Label(rail_head, text="SAVED TARGETS", bg=THEME["panel"],
                 fg=THEME["accent"], font=(self.app.f_mono, 10, "bold")).pack(
            side="left")
        clr = tk.Label(rail_head, text="[CLEAR]", bg=THEME["panel"],
                       fg=THEME["bad"], font=(self.app.f_mono, 8, "bold"),
                       cursor="hand2")
        clr.pack(side="right")
        clr.bind("<Button-1>", self._clear_saved)
        self.rail_list = ScrollFrame(rail, bg=THEME["panel"], width=262,
                                     height=420)
        self.rail_list.pack(fill="both", expand=True, padx=6, pady=(0, 10))

        # desk: draggable cards
        desk_wrap = tk.Frame(body, bg=THEME["bg"])
        desk_wrap.pack(side="left", fill="both", expand=True, padx=(10, 0))
        self.desk = Desk(desk_wrap, self.app)
        self.desk.pack(fill="both", expand=True)

    # ---- actions --------------------------------------------
    def _scan_one(self, target, deep):
        target = target.strip()
        if not target:
            raise ValueError("enter a target first")
        query = target
        if not ip_regex().match(target):
            try:
                query = socket.gethostbyname(target)
            except Exception:
                raise RuntimeError("cannot resolve: " + target)
        data = ip_info(query, deep=deep)
        if data.get("status") != "success":
            raise RuntimeError(data.get("message", "lookup failed"))
        rec = {
            "ip": query,
            "mode": "DEEP" if deep else "SINGLE",
            "rows": ip_rows(data, deep),
            "info": data,
            "saved_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        }
        return rec

    def scan_single(self, deep):
        t = self.target.get().strip()
        if not t:
            self.status("ENTER A TARGET FIRST", THEME["warn"])
            return
        self.run(lambda: self._scan_one(t, deep),
                 self._after_scan, busy="SCANNING " + t)

    def _after_scan(self, rec):
        self.app.store.add_ip_record(rec)
        self.app.store.log("IP-SCANNER", "scan", rec["ip"], rec["mode"])
        self._refresh_saved()
        self.desk.add_card(rec)

    def load_file(self):
        path = filedialog.askopenfilename(
            title="LOAD IP LIST",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if not path:
            return
        self._stop.clear()
        self.run(lambda: self._scan_file(path), self._after_file_batch,
                 busy="READING FILE")

    def stop_batch(self):
        self._stop.set()
        self.status("STOPPING BATCH...", THEME["warn"])

    def _scan_file(self, path):
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
        ips = []
        for m in ip_regex().finditer(content):
            ip = m.group(0)
            if ip not in ips and all(int(o) <= 255 for o in ip.split(".")):
                ips.append(ip)
        if not ips:
            raise ValueError("no IPv4 addresses found in file")
        recs = []
        n = len(ips)
        for i, ip in enumerate(ips):
            if self._stop.is_set():
                break
            self.app.q.put(("ok",
                            lambda _r, i=i, n=n: self.status(
                                "BATCH {}/{} -- {}".format(i + 1, n, ip),
                                THEME["warn"]), None))
            try:
                data = ip_info(ip, deep=False)
            except Exception:
                continue
            if data.get("status") != "success":
                continue
            recs.append({
                "ip": ip, "mode": "FILE", "rows": ip_rows(data, False),
                "info": data,
                "saved_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            })
            time.sleep(0.85)  # public API rate limit
        return recs

    def _after_file_batch(self, recs):
        for rec in recs:
            self.app.store.add_ip_record(rec)
            self.desk.add_card(rec)
        self.app.store.log("IP-SCANNER", "file batch", "{} targets".format(len(recs)))
        self._refresh_saved()
        self.status("BATCH COMPLETE: {} TARGETS".format(len(recs)), THEME["ok"])

    def add_deep(self, rec, data):
        if data.get("status") != "success":
            self.app.default_error(RuntimeError(data.get("message", "deep lookup failed")))
            return
        deep_rec = {
            "ip": rec["ip"], "mode": "DEEP", "rows": ip_rows(data, True),
            "info": data,
            "saved_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        }
        self.app.store.add_ip_record(deep_rec)
        self.app.store.log("IP-SCANNER", "deep info", rec["ip"])
        self._refresh_saved()
        self.desk.add_card(deep_rec)

    def show_record(self, rec):
        self.desk.add_card(rec)

    def _refresh_saved(self):
        for w in self.rail_list.inner.winfo_children():
            w.destroy()
        for rec in self.app.store.ip_records()[:80]:
            SavedBox(self.rail_list.inner, self.app, rec).pack(
                fill="x", padx=4, pady=3)

    def _clear_saved(self, _e=None):
        self.app.store.clear_ip_records()
        self._refresh_saved()
        self.status("SAVED LIST CLEARED", THEME["warn"])

    def on_show(self):
        self._refresh_saved()


# ============================================================
#  TOOL 02 -- NMAP SCAN
# ============================================================

class NmapPage(BasePage):

    TITLE = "NMAP SCAN"
    SUB = "TCP PORTS / SERVICES / LATENCY / ISP INTEL"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="TARGET", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.host_e = self.entry(inner, width=24, placeholder="scanme.nmap.org")
        self.host_e.pack(side="left", padx=(10, 10))
        self.host_e.bind("<Return>", lambda e: self.start_scan())
        tk.Label(inner, text="PORTS", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.preset = ttk.Combobox(inner, state="readonly", width=18,
                                   values=["QUICK (32 PORTS)",
                                           "STANDARD (80 PORTS)",
                                           "FULL (1-1024)", "CUSTOM"],
                                   font=(self.app.f_mono, 9))
        self.preset.current(0)
        self.preset.pack(side="left", padx=(8, 8))
        self.custom_e = self.entry(inner, width=16, placeholder="80,443,1000-2000")
        self.custom_e.pack(side="left", padx=(0, 10))
        NeonButton(inner, "SCAN", width=100, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.start_scan).pack(side="left", padx=2)
        NeonButton(inner, "STOP", width=70, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.stop_scan).pack(side="left", padx=2)

        body = tk.Frame(self, bg=THEME["bg"])
        body.pack(fill="both", expand=True, padx=14)

        tree_wrap = tk.Frame(body, bg=THEME["bg"])
        tree_wrap.pack(side="left", fill="both", expand=True)
        cols = ("port", "service", "state", "latency", "banner")
        self.tree = ttk.Treeview(tree_wrap, columns=cols, show="headings")
        for cid, txt, w in (("port", "PORT", 70), ("service", "SERVICE", 130),
                            ("state", "STATE", 70), ("latency", "LATENCY", 90),
                            ("banner", "BANNER", 380)):
            self.tree.heading(cid, text=txt)
            self.tree.column(cid, width=w, anchor="w")
        vsb = ttk.Scrollbar(tree_wrap, orient="vertical",
                            command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)
        self.tree.tag_configure("open", foreground=THEME["text"])

        info = tk.Frame(body, bg=THEME["panel"], width=260,
                        highlightthickness=1,
                        highlightbackground=THEME["accent_dim"])
        info.pack(side="left", fill="y", padx=(10, 0))
        info.pack_propagate(False)
        tk.Label(info, text="TARGET INTEL", bg=THEME["panel"],
                 fg=THEME["accent"], font=(self.app.f_mono, 10, "bold")).pack(
            anchor="w", padx=12, pady=(12, 6))
        self.i_target = self.label_pair(info, "TARGET")
        self.i_isp = self.label_pair(info, "ISP")
        self.i_org = self.label_pair(info, "ORG")
        self.i_as = self.label_pair(info, "AS")
        self.i_country = self.label_pair(info, "COUNTRY")
        self.i_city = self.label_pair(info, "CITY")
        self.i_open = self.label_pair(info, "OPEN PORTS")
        self.i_time = self.label_pair(info, "SCAN TIME")

    def stop_scan(self):
        self._stop.set()
        self.status("STOPPING...", THEME["warn"])

    def _prog_cb(self, done, total):
        self.app.q.put(("ok", lambda _r, d=done, t=total:
                        self.status("SCANNING... {}/{}".format(d, t),
                                    THEME["warn"]), None))

    def start_scan(self):
        host = self.host_e.get().strip()
        if not host:
            self.status("ENTER A TARGET FIRST", THEME["warn"])
            return
        try:
            ports = port_list(self.preset.get(), self.custom_e.get())
        except Exception:
            self.status("BAD CUSTOM PORT LIST", THEME["bad"])
            return
        if not ports:
            self.status("EMPTY PORT LIST", THEME["warn"])
            return
        for w in self.tree.get_children():
            self.tree.delete(w)
        self._stop.clear()

        def work():
            t0 = time.perf_counter()
            res = scan_ports(host, ports,
                             timeout=float(CFG["scan_timeout"]),
                             stop=self._stop, progress=self._prog_cb)
            intel = None
            try:
                intel = ip_info(host, deep=False)
            except Exception:
                pass
            return res, intel, round(time.perf_counter() - t0, 2)

        self.run(work, self._done,
                 busy="SCANNING {} [{} PORTS]".format(host, len(ports)))

    def _done(self, payload):
        results, intel, elapsed = payload
        for r in results:
            self.tree.insert("", "end", values=(
                r["port"], r["service"], "OPEN",
                "{} ms".format(r["latency_ms"]), r["banner"] or "--"))
        self.i_open.config(text=str(len(results)))
        self.i_time.config(text="{}s".format(elapsed))
        if intel and intel.get("status") == "success":
            self.i_target.config(text=str(intel.get("query", "--")))
            self.i_isp.config(text=str(intel.get("isp", "--"))[:30])
            self.i_org.config(text=str(intel.get("org", "--"))[:30])
            self.i_as.config(text=str(intel.get("as", "--"))[:30])
            self.i_country.config(text=str(intel.get("country", "--")))
            self.i_city.config(text=str(intel.get("city", "--")))
        self.app.store.log("NMAP-SCAN", "port scan", self.host_e.get(),
                           "{} open".format(len(results)))
        if self._stop.is_set():
            self.status("STOPPED -- {} OPEN".format(len(results)), THEME["warn"])
        else:
            self.status("SCAN COMPLETE -- {} OPEN".format(len(results)),
                        THEME["ok"])

    def on_show(self):
        pass


# ============================================================
#  TOOL 03 -- PATH FUZZER
# ============================================================

class FuzzPage(BasePage):

    TITLE = "PATH FUZZER"
    SUB = "DIRECTORY GUESSING // example.com/admin"

    def build(self):
        self.wl = json.loads(vault_read("wordlists.nxt")[0].decode("utf-8"))

        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 6))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="TARGET URL", bg=THEME["panel"],
                 fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.url_e = self.entry(inner, width=34, placeholder="http://example.com/")
        self.url_e.pack(side="left", padx=(10, 10))
        self.url_e.bind("<Return>", lambda e: self.start())
        NeonButton(inner, "START FUZZ", width=130, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.start).pack(side="left", padx=2)
        NeonButton(inner, "STOP", width=70, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.stop).pack(side="left", padx=2)

        opt = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        opt.pack(fill="x", padx=14, pady=(0, 8))
        oi = tk.Frame(opt, bg=THEME["panel"])
        oi.pack(fill="x", padx=10, pady=8)
        tk.Label(oi, text="WORDLIST", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        n_paths = len(self.wl.get("paths", []))
        n_users = len(self.wl.get("users", []))
        n_passes = len(self.wl.get("passes", []))
        self.wl_sel = ttk.Combobox(
            oi, state="readonly", width=20,
            values=["PATHS ({})".format(n_paths),
                    "USERS ({})".format(n_users),
                    "PASSES ({})".format(n_passes)],
            font=(self.app.f_mono, 9))
        self.wl_sel.current(0)
        self.wl_sel.pack(side="left", padx=(8, 14))
        tk.Label(oi, text="EXT", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.ext_e = self.entry(oi, width=16, placeholder="php,html,bak")
        self.ext_e.pack(side="left", padx=(8, 14))
        tk.Label(oi, text="THREADS", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.th_sel = ttk.Combobox(oi, state="readonly", width=6,
                                   values=["10", "20", "30", "50"],
                                   font=(self.app.f_mono, 9))
        self.th_sel.current(0)
        self.th_sel.pack(side="left", padx=(8, 14))
        self.hide404 = tk.BooleanVar(value=False)
        ttk.Checkbutton(oi, text="HIDE 404", variable=self.hide404).pack(
            side="left", padx=8)

        prog = tk.Frame(self, bg=THEME["bg"])
        prog.pack(fill="x", padx=14, pady=(0, 6))
        self.pb = ttk.Progressbar(prog, style="Horizontal.TProgressbar",
                                  maximum=100, value=0)
        self.pb.pack(fill="x")
        row = tk.Frame(prog, bg=THEME["bg"])
        row.pack(fill="x", pady=4)
        self.c_tried = tk.Label(row, text="TRIED: 0", bg=THEME["bg"],
                                fg=THEME["dim"], font=(self.app.f_mono, 9, "bold"))
        self.c_tried.pack(side="left", padx=(0, 16))
        self.c_found = tk.Label(row, text="RESPONDED: 0", bg=THEME["bg"],
                                fg=THEME["ok"], font=(self.app.f_mono, 9, "bold"))
        self.c_found.pack(side="left", padx=(0, 16))
        self.c_total = tk.Label(row, text="TASKS: 0", bg=THEME["bg"],
                                fg=THEME["dim"], font=(self.app.f_mono, 9, "bold"))
        self.c_total.pack(side="left", padx=(0, 16))
        self.c_time = tk.Label(row, text="ELAPSED: 0s", bg=THEME["bg"],
                               fg=THEME["accent"],
                               font=(self.app.f_mono, 9, "bold"))
        self.c_time.pack(side="left")

        wrap = tk.Frame(self, bg=THEME["bg"])
        wrap.pack(fill="both", expand=True, padx=14)
        cols = ("path", "status", "size", "note")
        self.tree = ttk.Treeview(wrap, columns=cols, show="headings")
        for cid, txt, w in (("path", "PATH", 300), ("status", "STATUS", 80),
                            ("size", "SIZE", 100), ("note", "NOTE", 330)):
            self.tree.heading(cid, text=txt)
            self.tree.column(cid, width=w, anchor="w")
        vsb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)
        self.tree.tag_configure("s200", foreground=THEME["ok"])
        self.tree.tag_configure("s3xx", foreground=THEME["warn"])
        self.tree.tag_configure("s4xx", foreground=THEME["dim"])
        self.tree.tag_configure("s5xx", foreground=THEME["bad"])

    def stop(self):
        self._stop.set()
        self.status("STOPPING...", THEME["warn"])

    def _live_row(self, item):
        path, status, size, note, _ms = item
        if status == "ERR":
            tag = "s5xx"
        elif status == 200:
            tag = "s200"
        elif isinstance(status, int) and 300 <= status < 400:
            tag = "s3xx"
        elif isinstance(status, int) and 400 <= status < 500:
            tag = "s4xx"
        else:
            tag = "s5xx"
        if not (self.hide404.get() and status == 404):
            self.tree.insert("", "end", values=(
                path, status, "{} B".format(size) if size else "0 B",
                note or "--"), tags=(tag,))
        c = self._counters
        self.c_tried.config(text="TRIED: {}".format(c["tried"]))
        self.c_found.config(text="RESPONDED: {}".format(c["found"]))
        self.c_time.config(text="ELAPSED: {}s".format(int(time.time() - c["t0"])))
        self.pb.config(value=c["tried"])

    def start(self):
        base = self.url_e.get().strip()
        if not base:
            self.status("ENTER A TARGET URL", THEME["warn"])
            return
        if not base.startswith(("http://", "https://")):
            base = "http://" + base
        if not base.endswith("/"):
            base = base.rstrip("/") + "/"
        wl_key = {"PATHS": "paths", "USERS": "users",
                  "PASSES": "passes"}[self.wl_sel.get().split(" ")[0]]
        words = self.wl.get(wl_key, [])
        exts = [e.strip().lstrip(".") for e in self.ext_e.get().split(",")
                if e.strip()]
        tasks, seen = [], set()
        for w in words:
            p = "/" + str(w).strip().lstrip("/")
            if p == "/":
                continue
            if p not in seen:
                seen.add(p)
                tasks.append(p)
            if not p.endswith("/") and "." not in p.split("/")[-1]:
                for ext in exts:
                    q = p + "." + ext
                    if q not in seen:
                        seen.add(q)
                        tasks.append(q)
        if not tasks:
            self.status("EMPTY WORDLIST", THEME["bad"])
            return
        for w in self.tree.get_children():
            self.tree.delete(w)
        self._stop.clear()
        threads = int(self.th_sel.get())
        self.pb.config(maximum=len(tasks), value=0)
        self._counters = {"tried": 0, "found": 0, "t0": time.time()}
        lock = threading.Lock()
        self.c_total.config(text="TASKS: {}".format(len(tasks)))

        def probe(path):
            if self._stop.is_set():
                return None
            url = base.rstrip("/") + path
            r = http_request(url, timeout=float(CFG["fuzz_timeout"]),
                             max_body=60000)
            with lock:
                self._counters["tried"] += 1
                if r["status"] is not None:
                    self._counters["found"] += 1
            note = ""
            if r["status"] in (301, 302, 303, 307, 308):
                note = "-> " + r["headers"].get("location", "")[:60]
            item = (path, r["status"] if r["status"] is not None else "ERR",
                    len(r["body"]), note, r["elapsed_ms"])
            self.app.q.put(("ok", lambda _r, it=item: self._live_row(it), None))
            return None  # rows are added live

        def work():
            with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as pool:
                futs = [pool.submit(probe, t) for t in tasks]
                for f in concurrent.futures.as_completed(futs):
                    if self._stop.is_set():
                        break
                    f.result()
            return len(tasks)

        self.run(work, self._done,
                 busy="FUZZING {} [{}]".format(base, wl_key.upper()))

    def _done(self, total):
        c = self._counters
        self.pb.config(value=c["tried"])
        self.app.store.log("FUZZER", "path fuzz", self.url_e.get(),
                           "{} tasks".format(total))
        if self._stop.is_set():
            self.status("STOPPED", THEME["warn"])
        else:
            self.status("FUZZ COMPLETE", THEME["ok"])


# ============================================================
#  TOOL 04 -- DNS / WHOIS
# ============================================================

class DnsPage(BasePage):

    TITLE = "DNS / WHOIS"
    SUB = "FULL RECORD ENUMERATION + REGISTRY DATA"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="DOMAIN", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.dom_e = self.entry(inner, width=30, placeholder="example.com")
        self.dom_e.pack(side="left", padx=(10, 10))
        self.dom_e.bind("<Return>", lambda e: self.resolve_all())
        NeonButton(inner, "RESOLVE ALL", width=130, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.resolve_all).pack(side="left", padx=2)
        NeonButton(inner, "WHOIS", width=90, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.do_whois).pack(side="left", padx=2)

        body = tk.Frame(self, bg=THEME["bg"])
        body.pack(fill="both", expand=True, padx=14)
        left = tk.Frame(body, bg=THEME["bg"])
        left.pack(side="left", fill="both", expand=True)
        cols = ("type", "value")
        self.tree = ttk.Treeview(left, columns=cols, show="headings")
        for cid, txt, w in (("type", "TYPE", 90), ("value", "VALUE", 620)):
            self.tree.heading(cid, text=txt)
            self.tree.column(cid, width=w, anchor="w")
        vsb = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)

        right = tk.Frame(body, bg=THEME["panel"], width=380,
                         highlightthickness=1,
                         highlightbackground=THEME["accent_dim"])
        right.pack(side="left", fill="y", padx=(10, 0))
        right.pack_propagate(False)
        tk.Label(right, text="WHOIS RAW", bg=THEME["panel"],
                 fg=THEME["accent"], font=(self.app.f_mono, 10, "bold")).pack(
            anchor="w", padx=12, pady=(12, 6))
        self.whois_txt = tk.Text(right, bg=THEME["panel2"], fg=THEME["text"],
                                 insertbackground=THEME["accent"], bd=0,
                                 font=(self.app.f_mono, 8), wrap="word",
                                 width=44)
        self.whois_txt.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    def resolve_all(self):
        dom = self.dom_e.get().strip()
        if not dom:
            self.status("ENTER A DOMAIN", THEME["warn"])
            return
        for w in self.tree.get_children():
            self.tree.delete(w)

        def work():
            rows = []
            for rtype in ("A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA"):
                try:
                    vals = dns_lookup(dom, rtype)
                    if vals == ["NXDOMAIN"]:
                        rows.append((rtype, "NXDOMAIN -- domain not found"))
                        break
                    for v in vals:
                        rows.append((rtype, v))
                    if not vals:
                        rows.append((rtype, "(none)"))
                except Exception as e:
                    rows.append((rtype, "ERROR: " + str(e)[:40]))
            return rows

        def done(rows):
            for rtype, val in rows:
                color = "ok" if rtype == "A" else None
                tag = ("recA",) if color else ()
                self.tree.insert("", "end", values=(rtype, val), tags=tag)
            self.tree.tag_configure("recA", foreground=THEME["ok"])
            self.app.store.log("DNS", "resolve", dom,
                               "{} records".format(len(rows)))
            self.status("RESOLVED -- {} RECORDS".format(len(rows)), THEME["ok"])

        self.run(work, done, busy="RESOLVING " + dom)

    def do_whois(self):
        dom = self.dom_e.get().strip()
        if not dom:
            self.status("ENTER A DOMAIN", THEME["warn"])
            return
        self.whois_txt.delete("1.0", "end")

        def work():
            text, server = whois(dom)
            return text, server

        def done(payload):
            text, server = payload
            lines = [l for l in text.splitlines()
                     if l.strip() and not l.startswith("%")][:60]
            self.whois_txt.insert("1.0", "\n".join(lines))
            self.whois_txt.insert("1.0", "// SERVER: {}\n\n".format(server))
            self.app.store.log("WHOIS", "lookup", dom)
            self.status("WHOIS DONE", THEME["ok"])

        self.run(work, done, busy="WHOIS " + dom)


# ============================================================
#  TOOL 05 -- SUBDOMAIN FINDER
# ============================================================

class SubdPage(BasePage):

    TITLE = "SUBDOMAIN FINDER"
    SUB = "DNS BRUTE RESOLUTION FROM VAULT PREFIXES"

    def build(self):
        self.prefixes = json.loads(
            vault_read("wordlists.nxt")[0].decode("utf-8")).get("subs", [])

        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="DOMAIN", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.dom_e = self.entry(inner, width=30, placeholder="example.com")
        self.dom_e.pack(side="left", padx=(10, 10))
        self.dom_e.bind("<Return>", lambda e: self.start())
        NeonButton(inner, "FIND", width=100, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.start).pack(side="left", padx=2)
        NeonButton(inner, "STOP", width=70, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.stop).pack(side="left", padx=2)
        tk.Label(inner, text="{} PREFIXES IN VAULT".format(len(self.prefixes)),
                 bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.app.f_mono, 8)).pack(side="right", padx=4)

        self.c_found = tk.Label(self, text="FOUND: 0", bg=THEME["bg"],
                                fg=THEME["ok"],
                                font=(self.app.f_mono, 10, "bold"))
        self.c_found.pack(anchor="w", padx=14, pady=(0, 4))

        wrap = tk.Frame(self, bg=THEME["bg"])
        wrap.pack(fill="both", expand=True, padx=14)
        cols = ("sub", "ip")
        self.tree = ttk.Treeview(wrap, columns=cols, show="headings")
        for cid, txt, w in (("sub", "SUBDOMAIN", 420), ("ip", "RESOLVED IP", 300)):
            self.tree.heading(cid, text=txt)
            self.tree.column(cid, width=w, anchor="w")
        vsb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)

    def stop(self):
        self._stop.set()
        self.status("STOPPING...", THEME["warn"])

    def start(self):
        dom = self.dom_e.get().strip().lower()
        if not dom or "." not in dom:
            self.status("ENTER A VALID DOMAIN", THEME["warn"])
            return
        if not self.prefixes:
            self.status("NO PREFIXES IN VAULT", THEME["bad"])
            return
        for w in self.tree.get_children():
            self.tree.delete(w)
        self._stop.clear()
        self.c_found.config(text="FOUND: 0")
        self._n = 0

        def work():
            return subdomain_scan(dom, self.prefixes, workers=24,
                                  stop=self._stop)

        def done(rows):
            for sub, ip in rows:
                self.tree.insert("", "end", values=(sub, ip))
            self._n = len(rows)
            self.c_found.config(text="FOUND: {}".format(self._n))
            self.app.store.log("SUBDOMAINS", "scan", dom,
                               "{} found".format(self._n))
            if self._stop.is_set():
                self.status("STOPPED", THEME["warn"])
            else:
                self.status("SCAN COMPLETE", THEME["ok"])

        self.run(work, done,
                 busy="RESOLVING {} SUBDOMAINS...".format(len(self.prefixes)))


# ============================================================
#  TOOL 06 -- HEADER ANALYZER
# ============================================================

SEC_CHECKS = [
    ("strict-transport-security", "HSTS"),
    ("content-security-policy", "CSP"),
    ("x-content-type-options", "X-CONTENT-TYPE"),
    ("x-frame-options", "X-FRAME-OPTIONS"),
    ("referrer-policy", "REFERRER-POLICY"),
    ("permissions-policy", "PERMISSIONS-POLICY"),
]


class HeadersPage(BasePage):

    TITLE = "HEADER ANALYZER"
    SUB = "RESPONSE HEADERS + SECURITY AUDIT"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="URL", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.url_e = self.entry(inner, width=36, placeholder="http://example.com")
        self.url_e.pack(side="left", padx=(10, 10))
        self.url_e.bind("<Return>", lambda e: self.analyze())
        NeonButton(inner, "ANALYZE", width=110, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.analyze).pack(side="left", padx=2)

        body = tk.Frame(self, bg=THEME["bg"])
        body.pack(fill="both", expand=True, padx=14)
        left = tk.Frame(body, bg=THEME["bg"])
        left.pack(side="left", fill="both", expand=True)
        tk.Label(left, text="RESPONSE HEADERS", bg=THEME["bg"],
                 fg=THEME["accent"],
                 font=(self.app.f_mono, 10, "bold")).pack(anchor="w",
                                                          pady=(0, 4))
        cols = ("header", "value")
        self.tree = ttk.Treeview(left, columns=cols, show="headings")
        for cid, txt, w in (("header", "HEADER", 220), ("value", "VALUE", 560)):
            self.tree.heading(cid, text=txt)
            self.tree.column(cid, width=w, anchor="w")
        vsb = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)

        right = tk.Frame(body, bg=THEME["panel"], width=290,
                         highlightthickness=1,
                         highlightbackground=THEME["accent_dim"])
        right.pack(side="left", fill="y", padx=(10, 0))
        right.pack_propagate(False)
        tk.Label(right, text="SECURITY AUDIT", bg=THEME["panel"],
                 fg=THEME["accent"], font=(self.app.f_mono, 10, "bold")).pack(
            anchor="w", padx=12, pady=(12, 4))
        self.audit_rows = {}
        for _hdr, name in SEC_CHECKS:
            row = tk.Frame(right, bg=THEME["panel"])
            row.pack(fill="x", padx=12, pady=2)
            tk.Label(row, text=name, bg=THEME["panel"], fg=THEME["text"],
                     font=(self.app.f_mono, 8, "bold"), width=18,
                     anchor="w").pack(side="left")
            badge = tk.Label(row, text="--", bg=THEME["panel"], fg=THEME["dim"],
                             font=(self.app.f_mono, 8, "bold"))
            badge.pack(side="right")
            self.audit_rows[name] = badge
        tk.Label(right, text="EXPOSURE", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 10, "bold")).pack(
            anchor="w", padx=12, pady=(12, 4))
        self.x_server = self.label_pair(right, "SERVER")
        self.x_powered = self.label_pair(right, "X-POWERED-BY")
        self.x_cookie = self.label_pair(right, "COOKIE FLAGS")

    def analyze(self):
        url = self.url_e.get().strip()
        if not url:
            self.status("ENTER A URL", THEME["warn"])
            return
        if not url.startswith(("http://", "https://")):
            url = "http://" + url
        for w in self.tree.get_children():
            self.tree.delete(w)

        def work():
            return http_request(url)

        def done(r):
            if r["status"] is None:
                raise RuntimeError(r["error"] or "request failed")
            self.tree.insert("", "end", values=(
                "STATUS", str(r["status"]) + "  ({} ms)".format(r["elapsed_ms"])),
                tags=("st",))
            self.tree.tag_configure("st", foreground=THEME["ok"])
            found = set()
            for k, v in r["headers"].items():
                self.tree.insert("", "end", values=(k, str(v)[:200]))
                if k.lower() in [h for h, _n in SEC_CHECKS]:
                    found.add(k.lower())
            for hdr, name in SEC_CHECKS:
                if hdr in found:
                    self.audit_rows[name].config(text="OK", fg=THEME["ok"])
                else:
                    self.audit_rows[name].config(text="MISSING", fg=THEME["bad"])
            self.x_server.config(text=str(r["headers"].get("server", "--"))[:26])
            self.x_powered.config(
                text=str(r["headers"].get("x-powered-by", "--"))[:26])
            cookie = r["headers"].get("set-cookie", "")
            if cookie:
                flags = []
                if "httponly" in cookie.lower():
                    flags.append("HTTPONLY")
                if "secure" in cookie.lower():
                    flags.append("SECURE")
                self.x_cookie.config(text=", ".join(flags) or "NONE", fg=THEME["warn"])
            else:
                self.x_cookie.config(text="NO COOKIES", fg=THEME["dim"])
            self.app.store.log("HEADERS", "analyze", url, str(r["status"]))
            self.status("ANALYZED -- {} HEADERS, {} CONTROLS".format(
                len(r["headers"]), len(found)), THEME["ok"])

        self.run(work, done, busy="FETCHING HEADERS")


# ============================================================
#  TOOL 07 -- BANNER GRABBER
# ============================================================

class BannerPage(BasePage):

    TITLE = "BANNER GRABBER"
    SUB = "RAW SERVICE IDENTIFICATION"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="HOST", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.host_e = self.entry(inner, width=24, placeholder="target.com")
        self.host_e.pack(side="left", padx=(10, 10))
        tk.Label(inner, text="PORT", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.port_e = self.entry(inner, width=8, placeholder="21")
        self.port_e.pack(side="left", padx=(8, 10))
        NeonButton(inner, "GRAB", width=90, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.grab(False)).pack(side="left", padx=2)
        NeonButton(inner, "HTTP PROBE", width=130, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.grab(True)).pack(side="left", padx=2)

        wrap = tk.Frame(self, bg=THEME["bg"])
        wrap.pack(fill="both", expand=True, padx=14)
        self.out = tk.Text(wrap, bg=THEME["panel2"], fg=THEME["text"],
                           insertbackground=THEME["accent"], bd=0,
                           font=(self.app.f_mono, 10), wrap="none")
        ssb = ttk.Scrollbar(wrap, orient="vertical", command=self.out.yview)
        self.out.configure(yscrollcommand=ssb.set)
        ssb.pack(side="right", fill="y")
        self.out.pack(fill="both", expand=True)
        self.out.insert("1.0", "// connect to a port and read the raw service banner\n"
                               "// HTTP PROBE sends a minimal GET for silent HTTP services\n")

    def grab(self, http_probe):
        def cmd():
            host = self.host_e.get().strip()
            try:
                port = int(self.port_e.get().strip() or "0")
            except ValueError:
                self.status("BAD PORT", THEME["bad"])
                return
            if not host or not (0 < port < 65536):
                self.status("ENTER HOST + PORT", THEME["warn"])
                return
            self.out.delete("1.0", "end")

            def work():
                return tcp_probe(host, port, timeout=6, banner_wait=1.5,
                                 http_probe=http_probe)

            def done(p):
                if not p["ok"]:
                    self.out.insert("1.0", "// connection refused / filtered: {}:{}\n".format(host, port))
                    self.status("CLOSED OR FILTERED", THEME["bad"])
                    return
                self.out.insert("1.0",
                                "// {}:{} OPEN  ({} ms)  service: {}\n".format(
                                    host, port, p["latency_ms"],
                                    PORTS.get(str(port), "unknown")))
                self.out.insert("end", p["banner"] or "(no banner -- empty response)")
                self.app.store.log("BANNER", "grab", "{}:{}".format(host, port))
                self.status("BANNER CAPTURED ({} ms)".format(p["latency_ms"]),
                            THEME["ok"])

            self.run(work, done, busy="CONNECTING {}:{}".format(host, port))
        return cmd


# ============================================================
#  TOOL 08 -- HASH TOOLS
# ============================================================

class HashPage(BasePage):

    TITLE = "HASH TOOLS"
    SUB = "GENERATE / IDENTIFY"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="TEXT", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.in_e = self.entry(inner, width=40, placeholder="input string")
        self.in_e.pack(side="left", padx=(10, 10))
        for algo in ("MD5", "SHA1", "SHA256", "SHA512"):
            NeonButton(inner, algo, width=90, height=30,
                       font=(self.app.f_mono, 9, "bold"),
                       command=lambda a=algo: self.gen(a)).pack(side="left",
                                                                padx=2)

        wrap = tk.Frame(self, bg=THEME["bg"])
        wrap.pack(fill="both", expand=True, padx=14)
        self.results = {}
        for algo in ("MD5", "SHA1", "SHA256", "SHA512"):
            box = tk.Frame(wrap, bg=THEME["panel"], highlightthickness=1,
                           highlightbackground=THEME["accent_dim"])
            box.pack(fill="x", pady=4)
            head = tk.Frame(box, bg=THEME["panel3"], height=26)
            head.pack(fill="x")
            head.pack_propagate(False)
            tk.Label(head, text=algo, bg=THEME["panel3"], fg=THEME["accent"],
                     font=(self.app.f_mono, 9, "bold")).pack(side="left",
                                                             padx=10)
            cp = tk.Label(head, text="[COPY]", bg=THEME["panel3"],
                          fg=THEME["dim"], font=(self.app.f_mono, 8, "bold"),
                          cursor="hand2")
            cp.pack(side="right", padx=10)
            lbl = tk.Label(box, text="--", bg=THEME["panel"], fg=THEME["text"],
                           font=(self.app.f_mono, 10), anchor="w")
            lbl.pack(fill="x", padx=10, pady=6)
            self.results[algo] = lbl
            cp.bind("<Button-1>", lambda e, a=algo: self.copy(a))

        idbar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                         highlightbackground=THEME["accent_dim"])
        idbar.pack(fill="x", padx=14, pady=8)
        iid = tk.Frame(idbar, bg=THEME["panel"])
        iid.pack(fill="x", padx=10, pady=10)
        tk.Label(iid, text="IDENTIFY", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.id_e = self.entry(iid, width=52, placeholder="paste a hash")
        self.id_e.pack(side="left", padx=(10, 10))
        NeonButton(iid, "IDENTIFY", width=100, height=30,
                   font=(self.app.f_mono, 9, "bold"),
                   command=self.identify).pack(side="left", padx=2)
        self.id_out = tk.Label(iid, text="--", bg=THEME["panel"],
                               fg=THEME["warn"], font=(self.app.f_mono, 9, "bold"))
        self.id_out.pack(side="left", padx=10)

    def gen(self, algo):
        text = self.in_e.get()
        if text == "":
            self.status("ENTER TEXT FIRST", THEME["warn"])
            return
        algo_map = {"MD5": "md5", "SHA1": "sha1", "SHA256": "sha256",
                    "SHA512": "sha512"}
        h = hash_compute(text, algo_map[algo])
        self.results[algo].config(text=h, fg=THEME["glow"])
        self.app.store.log("HASH", "generate " + algo, "(input)")
        self.status(algo + " GENERATED", THEME["ok"])

    def copy(self, algo):
        val = self.results[algo].cget("text")
        if val == "--":
            return
        self.clipboard_clear()
        self.clipboard_append(val)
        self.status("COPIED " + algo, THEME["ok"])

    def identify(self):
        v = self.id_e.get().strip()
        guesses = hash_identify(v)
        self.id_out.config(text=" / ".join(guesses) if guesses else "NOT A HASH",
                           fg=THEME["ok"] if guesses else THEME["bad"])
        self.status("IDENTIFY DONE", THEME["ok"])


# ============================================================
#  TOOL 09 -- ENCODER / DECODER
# ============================================================

class EncodePage(BasePage):

    TITLE = "ENCODER / DECODER"
    SUB = "BASE64 / HEX / URL / ROT13"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="METHOD", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.method = ttk.Combobox(inner, state="readonly", width=10,
                                   values=["BASE64", "HEX", "URL", "ROT13"],
                                   font=(self.app.f_mono, 9))
        self.method.current(0)
        self.method.pack(side="left", padx=(8, 14))
        NeonButton(inner, "ENCODE", width=100, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=lambda: self.do("ENCODE")).pack(side="left", padx=2)
        NeonButton(inner, "DECODE", width=100, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=lambda: self.do("DECODE")).pack(side="left", padx=2)
        NeonButton(inner, "COPY", width=80, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.copy).pack(side="left", padx=2)

        wrap = tk.Frame(self, bg=THEME["bg"])
        wrap.pack(fill="both", expand=True, padx=14)
        tk.Label(wrap, text="INPUT", bg=THEME["bg"], fg=THEME["dim"],
                 font=(self.app.f_mono, 9, "bold")).pack(anchor="w")
        self.in_txt = tk.Text(wrap, height=6, bg=THEME["panel2"],
                              fg=THEME["text"],
                              insertbackground=THEME["accent"], bd=0,
                              font=(self.app.f_mono, 10), wrap="word")
        self.in_txt.pack(fill="both", expand=True, pady=(2, 8))
        tk.Label(wrap, text="OUTPUT", bg=THEME["bg"], fg=THEME["dim"],
                 font=(self.app.f_mono, 9, "bold")).pack(anchor="w")
        self.out_txt = tk.Text(wrap, height=6, bg=THEME["panel2"],
                               fg=THEME["glow"],
                               insertbackground=THEME["accent"], bd=0,
                               font=(self.app.f_mono, 10), wrap="word")
        self.out_txt.pack(fill="both", expand=True, pady=(2, 0))

    def do(self, mode):
        text = self.in_txt.get("1.0", "end").rstrip("\n")
        if not text:
            self.status("INPUT IS EMPTY", THEME["warn"])
            return
        try:
            out = enc_transform(text, self.method.get(), mode)
        except Exception as e:
            self.status("FAILED: " + str(e)[:40], THEME["bad"])
            return
        self.out_txt.delete("1.0", "end")
        self.out_txt.insert("1.0", out)
        self.app.store.log("ENCODER", mode, self.method.get())
        self.status(mode + " OK [" + self.method.get() + "]", THEME["ok"])

    def copy(self):
        out = self.out_txt.get("1.0", "end").rstrip("\n")
        if not out:
            return
        self.clipboard_clear()
        self.clipboard_append(out)
        self.status("COPIED", THEME["ok"])


# ============================================================
#  TOOL 10 -- MAC VENDOR
# ============================================================

class MacPage(BasePage):

    TITLE = "MAC VENDOR"
    SUB = "OUI VENDOR LOOKUP"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="MAC", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.mac_e = self.entry(inner, width=26,
                                placeholder="AA:BB:CC:DD:EE:FF")
        self.mac_e.pack(side="left", padx=(10, 10))
        self.mac_e.bind("<Return>", lambda e: self.lookup())
        NeonButton(inner, "LOOKUP", width=100, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.lookup).pack(side="left", padx=2)

        box = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        box.pack(fill="x", padx=14)
        ib = tk.Frame(box, bg=THEME["panel"])
        ib.pack(fill="x", padx=12, pady=14)
        tk.Label(ib, text="VENDOR", bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.app.f_mono, 9, "bold")).pack(anchor="w")
        self.out = tk.Label(ib, text="--", bg=THEME["panel"], fg=THEME["glow"],
                            font=(self.app.f_mono, 16, "bold"), anchor="w")
        self.out.pack(anchor="w")
        tk.Label(box, text="NOTE: upstream lookup allows ~1 request/second",
                 bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.app.f_mono, 7)).pack(anchor="w", padx=12,
                                                 pady=(0, 10))

    def lookup(self):
        mac = self.mac_e.get().strip()

        def work():
            return mac_vendor(mac)

        def done(vendor):
            self.out.config(text=vendor)
            self.app.store.log("MAC", "lookup", mac, vendor)
            self.status("LOOKUP OK", THEME["ok"])

        self.run(work, done, busy="LOOKING UP " + mac)


# ============================================================
#  TOOL 11 -- PING MONITOR
# ============================================================

class PingPage(BasePage):

    TITLE = "PING MONITOR"
    SUB = "LIVE TCP LATENCY TRACKING"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="HOST", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.host_e = self.entry(inner, width=22, placeholder="1.1.1.1")
        self.host_e.pack(side="left", padx=(10, 10))
        tk.Label(inner, text="PORT", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.port_e = self.entry(inner, width=7, placeholder="443")
        self.port_e.pack(side="left", padx=(8, 10))
        tk.Label(inner, text="EVERY", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.int_e = self.entry(inner, width=6, placeholder="1.0")
        self.int_e.pack(side="left", padx=(8, 4))
        tk.Label(inner, text="s", bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.app.f_mono, 9)).pack(side="left", padx=(0, 10))
        self.start_b = NeonButton(inner, "START", width=90, height=32,
                                  font=(self.app.f_mono, 10, "bold"),
                                  command=self.start)
        self.start_b.pack(side="left", padx=2)
        NeonButton(inner, "STOP", width=70, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.stop).pack(side="left", padx=2)

        self.chart = tk.Canvas(self, height=170, bg=THEME["panel2"],
                               highlightthickness=1,
                               highlightbackground=THEME["accent_dim"])
        self.chart.pack(fill="x", padx=14, pady=(0, 8))

        stats = tk.Frame(self, bg=THEME["bg"])
        stats.pack(fill="x", padx=14, pady=(0, 6))
        self.s_min = tk.Label(stats, text="MIN: --", bg=THEME["bg"],
                              fg=THEME["ok"], font=(self.app.f_mono, 9, "bold"))
        self.s_min.pack(side="left", padx=(0, 18))
        self.s_avg = tk.Label(stats, text="AVG: --", bg=THEME["bg"],
                              fg=THEME["accent"],
                              font=(self.app.f_mono, 9, "bold"))
        self.s_avg.pack(side="left", padx=(0, 18))
        self.s_max = tk.Label(stats, text="MAX: --", bg=THEME["bg"],
                              fg=THEME["warn"],
                              font=(self.app.f_mono, 9, "bold"))
        self.s_max.pack(side="left", padx=(0, 18))
        self.s_loss = tk.Label(stats, text="LOSS: --", bg=THEME["bg"],
                               fg=THEME["bad"],
                               font=(self.app.f_mono, 9, "bold"))
        self.s_loss.pack(side="left", padx=(0, 18))
        self.s_state = tk.Label(stats, text="STATE: IDLE", bg=THEME["bg"],
                                fg=THEME["dim"],
                                font=(self.app.f_mono, 9, "bold"))
        self.s_state.pack(side="left")

        self._lats = []
        self._fails = 0
        self._tries = 0
        self._running = False
        self.chart.bind("<Configure>", lambda e: self._redraw())

    def start(self):
        host = self.host_e.get().strip()
        try:
            port = int(self.port_e.get().strip() or "443")
            interval = max(0.5, float(self.int_e.get().strip() or "1.0"))
        except ValueError:
            self.status("BAD PORT / INTERVAL", THEME["bad"])
            return
        if not host:
            self.status("ENTER A HOST", THEME["warn"])
            return
        if self._running:
            return
        self._running = True
        self._stop.clear()
        self._lats = []
        self._fails = 0
        self._tries = 0
        self.s_state.config(text="STATE: RUNNING", fg=THEME["ok"])
        self.app.store.log("PING", "monitor start", "{}:{}".format(host, port))

        def loop():
            while not self._stop.is_set():
                p = tcp_probe(host, port, timeout=2.5)
                self._tries += 1
                if p["ok"]:
                    self._lats.append(p["latency_ms"])
                    if len(self._lats) > 120:
                        self._lats.pop(0)
                else:
                    self._fails += 1
                line = "{}  {}:{}  {} ms".format(
                    datetime.now().strftime("%H:%M:%S"), host, port,
                    p["latency_ms"] if p["ok"] else "TIMEOUT")
                self.app.q.put(("ok",
                                lambda _r, s=line: self._log_line(s), None))
                self._update_stats()
                self.app.q.put(("ok", lambda _r: self._redraw(), None))
                for _ in range(int(interval * 10)):
                    if self._stop.is_set():
                        break
                    time.sleep(0.1)
            self.app.q.put(("ok", lambda _r: self._on_end(), None))

        threading.Thread(target=loop, daemon=True).start()
        self.status("MONITORING {}:{}".format(host, port), THEME["ok"])

    def stop(self):
        self._stop.set()
        self.status("STOPPING...", THEME["warn"])

    def _on_end(self):
        self._running = False
        self.s_state.config(text="STATE: IDLE", fg=THEME["dim"])
        self.status("MONITOR STOPPED", THEME["warn"])

    def _log_line(self, s):
        self.status(s[:70], THEME["dim"])

    def _update_stats(self):
        if self._lats:
            mn = min(self._lats)
            mx = max(self._lats)
            avg = sum(self._lats) / len(self._lats)
            jit = (max(self._lats[-10:]) - min(self._lats[-10:])
                   if len(self._lats) >= 2 else 0)
        else:
            mn = mx = avg = jit = 0
        loss = (self._fails / self._tries * 100) if self._tries else 0

        def upd(_r=None):
            self.s_min.config(text="MIN: {} ms".format(mn or "--"))
            self.s_avg.config(text="AVG: {:.1f} ms".format(avg))
            self.s_max.config(text="MAX: {} ms".format(mx or "--"))
            self.s_loss.config(text="LOSS: {:.0f}%".format(loss))
            self.s_state.config(text="STATE: RUNNING ({} PINGS)".format(self._tries),
                                fg=THEME["ok"])

        self.app.q.put(("ok", upd, None))

    def _redraw(self):
        c = self.chart
        c.delete("all")
        w = max(c.winfo_width(), 300)
        h = max(c.winfo_height(), 100)
        for x in range(0, w, 44):
            c.create_line(x, 0, x, h, fill=THEME["accent_dim"], dash=(1, 7))
        if not self._lats:
            c.create_text(w // 2, h // 2, text="NO DATA -- START A MONITOR",
                          fill=THEME["dim"], font=(self.app.f_mono, 10, "bold"))
            return
        mx = max(self._lats) or 1
        pts = []
        n = len(self._lats)
        for i, v in enumerate(self._lats):
            x = 14 + (w - 28) * i / max(n - 1, 1)
            y = h - 14 - (h - 28) * (v / mx)
            pts += [x, y]
        if len(pts) >= 4:
            c.create_line(pts, fill=THEME["accent"], width=2)
        c.create_text(w - 10, 12, text="{} ms max".format(mx),
                      fill=THEME["dim"], font=(self.app.f_mono, 8),
                      anchor="e")

    def on_show(self):
        self._redraw()


# ============================================================
#  TOOL 12 -- PASSWORD GENERATOR
# ============================================================

class PassGenPage(BasePage):

    TITLE = "PASSWORD GENERATOR"
    SUB = "CRYPTO-STRENGTH RANDOM KEYS"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="LENGTH", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.len_v = tk.IntVar(value=20)
        self.len_lbl = tk.Label(inner, text="20", bg=THEME["panel"],
                                fg=THEME["glow"],
                                font=(self.app.f_mono, 11, "bold"), width=3)
        self.len_lbl.pack(side="left", padx=(6, 6))
        tk.Scale(inner, from_=8, to=64, orient="horizontal", length=180,
                 variable=self.len_v, bg=THEME["panel"], fg=THEME["text"],
                 highlightthickness=0, troughcolor=THEME["panel2"],
                 command=lambda v: self.len_lbl.config(text=v),
                 showvalue=False).pack(side="left", padx=(0, 16))
        self.vars = {}
        for name, label in (("lowercase", "a-z"), ("uppercase", "A-Z"),
                            ("digits", "0-9"), ("symbols", "SYMBOLS")):
            v = tk.BooleanVar(value=True)
            self.vars[name] = v
            ttk.Checkbutton(inner, text=label, variable=v).pack(
                side="left", padx=6)
        NeonButton(inner, "GENERATE", width=120, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.generate).pack(side="left", padx=2)
        NeonButton(inner, "COPY", width=80, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.copy).pack(side="left", padx=2)

        box = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        box.pack(fill="x", padx=14)
        bb = tk.Frame(box, bg=THEME["panel"])
        bb.pack(fill="x", padx=14, pady=16)
        self.out = tk.Label(bb, text="--", bg=THEME["panel"], fg=THEME["glow"],
                            font=(self.app.f_mono, 16, "bold"), anchor="w")
        self.out.pack(anchor="w")
        self.strength = tk.Label(bb, text="STRENGTH: --", bg=THEME["panel"],
                                 fg=THEME["dim"],
                                 font=(self.app.f_mono, 9, "bold"))
        self.strength.pack(anchor="w", pady=(6, 0))

        tip = tk.Label(self, text="generated with the secrets module (OS entropy)",
                       bg=THEME["bg"], fg=THEME["dim"],
                       font=(self.app.f_mono, 8))
        tip.pack(anchor="w", padx=14, pady=6)

    def generate(self):
        sets = tuple(k for k, v in self.vars.items() if v.get())
        try:
            pwd, pool = password_generate(int(self.len_v.get()), sets)
        except Exception as e:
            self.status(str(e), THEME["bad"])
            return
        self.out.config(text=pwd)
        bits = entropy_bits(int(self.len_v.get()), pool)
        if bits < 50:
            label, col = "WEAK", THEME["bad"]
        elif bits < 70:
            label, col = "GOOD", THEME["warn"]
        elif bits < 100:
            label, col = "STRONG", THEME["ok"]
        else:
            label, col = "EXTREME", THEME["accent"]
        self.strength.config(text="STRENGTH: {}  ({:.0f} bits entropy)".format(
            label, bits), fg=col)
        self.app.store.log("PASS-GEN", "generate",
                           "{} chars".format(self.len_v.get()))
        self.status("GENERATED [{}]".format(label), THEME["ok"])

    def copy(self):
        val = self.out.cget("text")
        if val == "--":
            return
        self.clipboard_clear()
        self.clipboard_append(val)
        self.status("COPIED", THEME["ok"])


# ============================================================
#  TOOL 13 -- SESSION LOG
# ============================================================

class LogPage(BasePage):

    TITLE = "SESSION LOG"
    SUB = "FULL OPERATION HISTORY (PERSISTED IN VAULT)"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        NeonButton(inner, "REFRESH", width=100, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.refresh).pack(side="left", padx=2)
        NeonButton(inner, "EXPORT .NXT", width=140, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.export).pack(side="left", padx=2)
        NeonButton(inner, "CLEAR", width=90, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.clear).pack(side="left", padx=2)
        tk.Label(inner, text="logs persist encrypted inside vault/db.nxt",
                 bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.app.f_mono, 8)).pack(side="right", padx=4)

        wrap = tk.Frame(self, bg=THEME["bg"])
        wrap.pack(fill="both", expand=True, padx=14)
        cols = ("time", "tool", "action", "target", "note")
        self.tree = ttk.Treeview(wrap, columns=cols, show="headings")
        for cid, txt, w in (("time", "TIME", 150), ("tool", "TOOL", 120),
                            ("action", "ACTION", 140),
                            ("target", "TARGET", 240),
                            ("note", "NOTE", 180)):
            self.tree.heading(cid, text=txt)
            self.tree.column(cid, width=w, anchor="w")
        vsb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)

    def refresh(self):
        for w in self.tree.get_children():
            self.tree.delete(w)
        for e in self.app.store.logs()[:300]:
            self.tree.insert("", "end", values=(
                e.get("ts", ""), e.get("tool", ""), e.get("action", ""),
                e.get("target", ""), e.get("note", "")))
        self.status("{} ENTRIES".format(len(self.app.store.logs())),
                    THEME["ok"])

    def export(self):
        path = filedialog.asksaveasfilename(
            title="EXPORT SESSION LOG",
            defaultextension=".nxt",
            filetypes=[("XXNETRO Vault", "*.nxt"), ("All files", "*.*")])
        if not path:
            return
        data = json.dumps({"exported": datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"), "logs": self.app.store.logs()},
            indent=1).encode("utf-8")
        with open(path, "wb") as f:
            f.write(vault_encode(data, b"T"))
        self.app.store.log("LOG", "export", os.path.basename(path))
        self.refresh()
        self.status("EXPORTED: " + os.path.basename(path), THEME["ok"])

    def clear(self):
        self.app.store.data["logs"] = []
        self.app.store.save()
        self.refresh()
        self.status("LOG CLEARED", THEME["warn"])

    def on_show(self):
        self.refresh()




# ============================================================
#  CRYPTO CORE  --  AES-256 + NXSEC SEALED CONTAINERS
# ============================================================
#  Pure-stdlib AES-256 (FIPS-197) used by SECURE COMMS and the
#  FILE VAULT. Tables are generated at import from GF(2^8)
#  arithmetic, no constant blobs. Key material is derived with
#  PBKDF2-HMAC-SHA256; every sealed message carries a random
#  salt + IV + HMAC-SHA256 tag (encrypt-then-MAC).
# ============================================================

import re as _re
import hmac as _hmac
import io as _io
import math as _math
import zipfile as _zipfile
from tkinter import messagebox

_NXSEC_MAGIC = b"NXSEC1"
_NXSEC_HDR = 6 + 16 + 16          # magic + salt + iv
_NXSEC_MAC = 32
_NXSEC_ITERS = 120_000


# ---- GF(2^8) helpers -------------------------------------

def _gf_mul(a, b):
    p = 0
    for _ in range(8):
        if b & 1:
            p ^= a
        hi = a & 0x80
        a = (a << 1) & 0xFF
        if hi:
            a ^= 0x1B
        b >>= 1
    return p


def _gf_inv(x):
    """Multiplicative inverse via a^254."""
    if x == 0:
        return 0
    y, base, e = 1, x, 254
    while e:
        if e & 1:
            y = _gf_mul(y, base)
        base = _gf_mul(base, base)
        e >>= 1
    return y


def _rotl8(b, n):
    return ((b << n) | (b >> (8 - n))) & 0xFF


def _build_tables():
    sbox = [0] * 256
    inv_sbox = [0] * 256
    for i in range(256):
        b = _gf_inv(i)
        s = b ^ _rotl8(b, 1) ^ _rotl8(b, 2) ^ _rotl8(b, 3) ^ _rotl8(b, 4) ^ 0x63
        sbox[i] = s
        inv_sbox[s] = i
    m2 = [_gf_mul(i, 2) for i in range(256)]
    m3 = [_gf_mul(i, 3) for i in range(256)]
    m9 = [_gf_mul(i, 9) for i in range(256)]
    m11 = [_gf_mul(i, 11) for i in range(256)]
    m13 = [_gf_mul(i, 13) for i in range(256)]
    m14 = [_gf_mul(i, 14) for i in range(256)]
    return sbox, inv_sbox, m2, m3, m9, m11, m13, m14


_SBOX, _ISBOX, _M2, _M3, _M9, _M11, _M13, _M14 = _build_tables()


# ---- AES-256 block cipher --------------------------------

class AES256:
    """AES-256 (Nk=8, Nr=14). Standard implementation, pure python."""

    def __init__(self, key):
        if not isinstance(key, (bytes, bytearray)) or len(key) != 32:
            raise ValueError("AES-256 key must be exactly 32 bytes")
        self._rk = self._expand(key)

    # -- key schedule --------------------------------------
    @staticmethod
    def _expand(key):
        words = [list(key[4 * i:4 * i + 4]) for i in range(8)]
        rcon = 1
        for i in range(8, 60):
            t = list(words[i - 1])
            if i % 8 == 0:
                t = t[1:] + t[:1]                       # RotWord
                t = [_SBOX[b] for b in t]                # SubWord
                t[0] ^= rcon
                rcon = _gf_mul(rcon, 2)
            elif i % 8 == 4:
                t = [_SBOX[b] for b in t]                # extra AES-256 step
            words.append([a ^ b for a, b in zip(words[i - 8], t)])
        # 15 round keys, each 16 bytes (words 4r .. 4r+3)
        return [bytes(words[4 * r] + words[4 * r + 1] +
                      words[4 * r + 2] + words[4 * r + 3])
                for r in range(15)]

    # -- round primitives ----------------------------------
    def _ark(self, s, rnd):
        rk = self._rk[rnd]
        for i in range(16):
            s[i] ^= rk[i]

    @staticmethod
    def _shift_rows(s):
        out = [0] * 16
        for r in range(4):
            for c in range(4):
                out[r + 4 * c] = s[r + 4 * ((c + r) % 4)]
        return out

    @staticmethod
    def _inv_shift_rows(s):
        out = [0] * 16
        for r in range(4):
            for c in range(4):
                out[r + 4 * ((c + r) % 4)] = s[r + 4 * c]
        return out

    @staticmethod
    def _mix_columns(s):
        for c in range(4):
            i = 4 * c
            a0, a1, a2, a3 = s[i], s[i + 1], s[i + 2], s[i + 3]
            s[i] = _M2[a0] ^ _M3[a1] ^ a2 ^ a3
            s[i + 1] = a0 ^ _M2[a1] ^ _M3[a2] ^ a3
            s[i + 2] = a0 ^ a1 ^ _M2[a2] ^ _M3[a3]
            s[i + 3] = _M3[a0] ^ a1 ^ a2 ^ _M2[a3]

    @staticmethod
    def _inv_mix_columns(s):
        for c in range(4):
            i = 4 * c
            a0, a1, a2, a3 = s[i], s[i + 1], s[i + 2], s[i + 3]
            s[i] = _M14[a0] ^ _M11[a1] ^ _M13[a2] ^ _M9[a3]
            s[i + 1] = _M9[a0] ^ _M14[a1] ^ _M11[a2] ^ _M13[a3]
            s[i + 2] = _M13[a0] ^ _M9[a1] ^ _M14[a2] ^ _M11[a3]
            s[i + 3] = _M11[a0] ^ _M13[a1] ^ _M9[a2] ^ _M14[a3]

    # -- public block api -----------------------------------
    def encrypt_block(self, block):
        s = list(block)
        self._ark(s, 0)
        for rnd in range(1, 14):
            s = [_SBOX[b] for b in s]
            s = self._shift_rows(s)
            self._mix_columns(s)
            self._ark(s, rnd)
        s = [_SBOX[b] for b in s]
        s = self._shift_rows(s)
        self._ark(s, 14)
        return bytes(s)

    def decrypt_block(self, block):
        s = list(block)
        self._ark(s, 14)
        for rnd in range(13, 0, -1):
            s = self._inv_shift_rows(s)
            s = [_ISBOX[b] for b in s]
            self._ark(s, rnd)
            self._inv_mix_columns(s)
        s = self._inv_shift_rows(s)
        s = [_ISBOX[b] for b in s]
        self._ark(s, 0)
        return bytes(s)

    # -- CBC mode ------------------------------------------
    def cbc_encrypt_raw(self, data, iv):
        if len(data) % 16 or len(iv) != 16:
            raise ValueError("CBC input must be 16-byte aligned")
        out, prev = bytearray(), bytes(iv)
        for i in range(0, len(data), 16):
            blk = bytes(a ^ b for a, b in zip(data[i:i + 16], prev))
            prev = self.encrypt_block(blk)
            out += prev
        return bytes(out)

    def cbc_decrypt_raw(self, data, iv):
        if len(data) % 16 or len(iv) != 16:
            raise ValueError("CBC input must be 16-byte aligned")
        out, prev = bytearray(), bytes(iv)
        for i in range(0, len(data), 16):
            c = data[i:i + 16]
            out += bytes(a ^ b for a, b in zip(self.decrypt_block(c), prev))
            prev = c
        return bytes(out)


# ---- padding ---------------------------------------------

def pkcs7_pad(data):
    n = 16 - (len(data) % 16)
    return bytes(data) + bytes([n]) * n


def pkcs7_unpad(data):
    if not data or len(data) % 16:
        raise ValueError("AES: bad block length")
    n = data[-1]
    if n < 1 or n > 16 or data[-n:] != bytes([n]) * n:
        raise ValueError("AES: bad padding")
    return bytes(data[:-n])


# ---- key derivation + keystreams --------------------------

def derive_key(passphrase, salt, size=32, iters=_NXSEC_ITERS):
    """PBKDF2-HMAC-SHA256 (stdlib, C speed)."""
    return hashlib.pbkdf2_hmac("sha256",
                               passphrase.encode("utf-8"), salt, iters,
                               dklen=size)


def xor_keystream(seed, n):
    """Deterministic SHA-256 chained keystream (obfuscation layer)."""
    out = bytearray()
    block = bytes(seed)
    while len(out) < n:
        block = hashlib.sha256(block).digest()
        out += block
    return bytes(out[:n])


# ---- NXSEC sealed containers ------------------------------

def nxsec_seal(data, passphrase, iters=_NXSEC_ITERS):
    """Seal bytes -> magic|salt|iv|ct|mac. Encrypt-then-MAC."""
    salt = secrets.token_bytes(16)
    iv = secrets.token_bytes(16)
    enc_key = derive_key(passphrase, salt, 32, iters)
    mac_key = derive_key(passphrase, salt + b"|mac", 32, iters)
    cipher = AES256(enc_key)
    ct = cipher.cbc_encrypt_raw(pkcs7_pad(data), iv)
    mac = _hmac.new(mac_key, salt + iv + ct, hashlib.sha256).digest()
    return _NXSEC_MAGIC + salt + iv + ct + mac


def nxsec_open(blob, passphrase, iters=_NXSEC_ITERS):
    """Open an NXSEC container. Raises on tamper / wrong passphrase."""
    blob = bytes(blob)
    if len(blob) < _NXSEC_HDR + _NXSEC_MAC + 16:
        raise ValueError("NXSEC: container too small")
    if blob[:6] != _NXSEC_MAGIC:
        raise ValueError("NXSEC: bad magic (not a sealed container)")
    salt = blob[6:22]
    iv = blob[22:38]
    ct = blob[38:-_NXSEC_MAC]
    mac = blob[-_NXSEC_MAC:]
    mac_key = derive_key(passphrase, salt + b"|mac", 32, iters)
    calc = _hmac.new(mac_key, salt + iv + ct, hashlib.sha256).digest()
    if not _hmac.compare_digest(calc, mac):
        raise ValueError("NXSEC: integrity check failed "
                          "(wrong passphrase or tampered data)")
    enc_key = derive_key(passphrase, salt, 32, iters)
    cipher = AES256(enc_key)
    return pkcs7_unpad(cipher.cbc_decrypt_raw(ct, iv))


# ---- text / file helpers ----------------------------------

def nxsec_seal_b64(text, passphrase):
    """UTF-8 text -> paste-safe sealed token (base64)."""
    return base64.b64encode(
        nxsec_seal(text.encode("utf-8"), passphrase)).decode("ascii")


def nxsec_open_b64(token, passphrase):
    """Sealed token -> UTF-8 text."""
    token = token.strip().replace("\n", "").replace("\r", "")
    return nxsec_open(base64.b64decode(token.encode("ascii")),
                      passphrase).decode("utf-8", "replace")


def nxsec_seal_file(src_path, dst_path, passphrase, iters=_NXSEC_ITERS):
    with open(src_path, "rb") as f:
        data = f.read()
    sealed = nxsec_seal(data, passphrase, iters)
    with open(dst_path, "wb") as f:
        f.write(sealed)
    return len(sealed)


def nxsec_open_file(src_path, dst_path, passphrase, iters=_NXSEC_ITERS):
    with open(src_path, "rb") as f:
        blob = f.read()
    data = nxsec_open(blob, passphrase, iters)
    with open(dst_path, "wb") as f:
        f.write(data)
    return len(data)


def crypto_selfcheck():
    """One-block encrypt/decrypt round trip. Runs in ~1 ms."""
    key = bytes(range(32))
    plain = bytes(range(16))
    c = AES256(key)
    out = c.decrypt_block(c.encrypt_block(plain))
    if out != plain:
        raise RuntimeError("AES-256 self test failed")
    iv = bytes(16)
    blob = b"xxnetro-crypto-core-check-1234"
    sealed = nxsec_seal(blob, "check-pass", iters=2_000)
    back = nxsec_open(sealed, "check-pass", iters=2_000)
    if back != blob:
        raise RuntimeError("NXSEC self test failed")
    return True


# ============================================================
#  LOCAL AI CORE  --  APK SENTINEL MODEL  (vault/model.nxm)
# ============================================================
#  A local heuristic intelligence model. It is NOT a cloud
#  service: every weight and rule ships inside the encrypted
#  vault (model.nxm) and runs entirely offline inside this
#  launcher. The engine scores an APK the way a trained
#  analyst would: weighted indicators -> severity -> a
#  0-100 protection score + crack-vector list.
# ============================================================

MODEL_FILE = "model.nxm"

CATS = {
    "LIC": {"name": "LICENSE / VIP INTEGRITY", "factor": 1.25,
            "desc": "How hard it is to flip the app into unlocked state"},
    "SEC": {"name": "SECRETS EXPOSURE", "factor": 1.0,
            "desc": "Hardcoded keys, tokens and endpoints"},
    "CRP": {"name": "CRYPTOGRAPHY", "factor": 1.0,
            "desc": "Weak primitives and hardcoded key material"},
    "DBG": {"name": "DEBUG / TAMPER RESISTANCE", "factor": 1.15,
            "desc": "Debuggable builds, backup, anti-debug guards"},
    "RDT": {"name": "ROOT / HOOK DEFENSE", "factor": 1.0,
            "desc": "Root, Frida and Xposed detection layers"},
    "SRF": {"name": "ATTACK SURFACE", "factor": 1.0,
            "desc": "Exported surface, WebView, insecure storage"},
    "OBF": {"name": "OBFUSCATION / PACKING", "factor": 1.15,
            "desc": "Reverse-engineering difficulty of the DEX"},
    "SIG": {"name": "SIGNING INTEGRITY", "factor": 1.1,
            "desc": "Signature presence and self-verification"},
    "PRV": {"name": "PRIVACY / TRACKING", "factor": 0.6,
            "desc": "Identifiers and sensitive permission usage"},
}

# kind:
#   dex_any   -- regex matched against any DEX string-pool entry
#   manifest  -- token present in the binary AndroidManifest pool
#   absence   -- none of the protective markers present (a finding)
#   metric    -- computed metric threshold (op: < > <= >=)
#   struct    -- zip-level structure condition
RULES = [
    # ---------------- LICENSE / VIP INTEGRITY ----------------
    {"id": "LIC-01", "cat": "LIC", "sev": "CRITICAL", "w": 10,
     "kind": "dex_any",
     "pat": r"(?i)\b(ispremium|is_premium|isvip|is_vip|premiumstatus|"
            r"premium_status|vip_status|vipstatus|premium_flag)\b",
     "title": "Premium / VIP state kept as boolean flags",
     "detail": "Premium entitlement looks like client-side booleans "
               "(isPremium / isVip style). A single patched conditional "
               "in a recompiled DEX flips the app to unlocked.",
     "fix": "Move entitlement to a signed server response; cache it in "
            "Android Keystore-protected storage; never trust a local flag."},
    {"id": "LIC-02", "cat": "LIC", "sev": "CRITICAL", "w": 10,
     "kind": "dex_any",
     "pat": r"(?i)\b(licensekey|lic_key|license_secret|premium_key|"
            r"unlock_key|activations?[_-]?key)\b",
     "title": "Hardcoded license / activation key strings",
     "detail": "Key-like literals named licenseKey / activationKey appear "
               "in the string pool. Static keys are extracted with one "
               "strings pass over the DEX.",
     "fix": "Remove embedded keys. Validate receipts server-side; store "
            "secrets in Android Keystore, derived per-install."},
    {"id": "LIC-03", "cat": "LIC", "sev": "HIGH", "w": 8,
     "kind": "dex_any",
     "pat": r"(?i)\b(unlockall|unlock_all|premiumunlock|premium_unlock|"
            r"skiplicen[cs]e|crackcheck|piracycheck)\b",
     "title": "Local unlock / crack-check code paths",
     "detail": "Code contains unlockAll / skipLicense style identifiers, "
               "meaning unlock logic ships inside the client.",
     "fix": "Delete local unlock branches; the server must be the only "
            "place that knows what is unlocked."},
    {"id": "LIC-04", "cat": "LIC", "sev": "MEDIUM", "w": 6,
     "kind": "dex_any",
     "pat": r"(?i)(googleplaylicen[cs]e|licensed|not_?licensed|"
            r"lvl|licensechecker)",
     "title": "Google Play Licensing (LVL) used client-side",
     "detail": "Play Licensing Library responses are verified inside the "
               "app. LVL alone is bypassable by patching the verdict.",
     "fix": "Combine LVL with server validation and tamper detection; "
            "never gate VIP only on LVL."},
    {"id": "LIC-05", "cat": "LIC", "sev": "HIGH", "w": 8,
     "kind": "absence",
     "pat": ["verifypurchase", "playintegrity", "attestation",
             "serververify", "receiptvalidation", "billingclient",
             "acknowledgepurchase", "consumepurchase"],
     "title": "No server-side purchase validation markers",
     "detail": "None of the usual receipt/server validation identifiers "
               "were found. Unlocks likely trust client state only.",
     "fix": "Verify purchases through your billing server; bind receipts "
            "to the account and refresh them on launch."},

    # ---------------- SECRETS -------------------------------
    {"id": "SEC-01", "cat": "SEC", "sev": "CRITICAL", "w": 10,
     "kind": "dex_any", "pat": r"AIza[0-9A-Za-z_\-]{35}",
     "title": "Google API key hardcoded",
     "detail": "A Google-API key pattern (AIza...) is embedded in the "
               "DEX string pool.",
     "fix": "Restrict the key (package + SHA-1 fingerprint) in the "
            "console, or serve calls through a backend."},
    {"id": "SEC-02", "cat": "SEC", "sev": "CRITICAL", "w": 10,
     "kind": "dex_any", "pat": r"AKIA[0-9A-Z]{16}",
     "title": "AWS access key id hardcoded",
     "detail": "An AWS access key id pattern (AKIA...) is embedded.",
     "fix": "Rotate the key immediately and never ship cloud "
            "credentials in an APK."},
    {"id": "SEC-03", "cat": "SEC", "sev": "CRITICAL", "w": 10,
     "kind": "dex_any", "pat": r"(?i)(sk_live_|pk_live_|rk_live_)[0-9a-z]{16,}",
     "title": "Stripe live key hardcoded",
     "detail": "A Stripe live-mode key pattern is embedded.",
     "fix": "Rotate the key; charge server-side only."},
    {"id": "SEC-04", "cat": "SEC", "sev": "CRITICAL", "w": 10,
     "kind": "dex_any",
     "pat": r"(?i)-----{0,2}\s*BEGIN [A-Z ]*PRIVATE KEY",
     "title": "Private key material embedded",
     "detail": "A PEM private key header appears in the string pool.",
     "fix": "Remove embedded keys; generate per-device keys in the "
            "Android Keystore instead."},
    {"id": "SEC-05", "cat": "SEC", "sev": "HIGH", "w": 9,
     "kind": "dex_any",
     "pat": r"(?i)\b(jdbc:[a-z]+://|mysql://|postgres://|mongodb(\+srv)?://|"
            r"redis://|amqp://|ftp://[a-z0-9._-]*:[^@/]+@)",
     "title": "Database / service connection string embedded",
     "detail": "Connection URIs (jdbc/mysql/postgres/mongo/redis/amqp) "
               "are shipped in the DEX.",
     "fix": "Remove direct backend endpoints; proxy through an API "
            "gateway with per-user auth."},
    {"id": "SEC-06", "cat": "SEC", "sev": "MEDIUM", "w": 5,
     "kind": "dex_any",
     "pat": r"(?i)(password|passwd|secret|api_key|apikey|access_token)"
            r"[\s\"':=]{1,3}[A-Za-z0-9_\-]{8,}",
     "title": "Secret-like literal assignments",
     "detail": "Strings look like key=value secret pairs. Verify manually "
               "-- may be template or log text.",
     "fix": "Move real secrets to server or Keystore; strip debug "
            "strings from release builds."},

    # ---------------- CRYPTO --------------------------------
    {"id": "CRP-01", "cat": "CRP", "sev": "HIGH", "w": 8,
     "kind": "dex_any",
     "pat": r"(?i)\b(AES/ECB|DES/|DESede|DESede/|RC4|AES/.*NOPADDING|"
            r"Blowfish)\b",
     "title": "Weak cipher / ECB mode in use",
     "detail": "Crypto transformation strings indicate ECB or legacy "
               "ciphers. ECB leaks structure; DES/RC4 are broken.",
     "fix": "Use AES/GCM (or ChaCha20-Poly1305) with a random nonce; "
            "never ECB."},
    {"id": "CRP-02", "cat": "CRP", "sev": "HIGH", "w": 7,
     "kind": "dex_any", "pat": r"PBEWith(MD5|SHA1ANDDES|SHA1ANDRC)",
     "title": "Legacy key derivation (PBE + MD5/DES)",
     "detail": "PBEWithMD5/SHA1AndDES style KDFs are considered broken.",
     "fix": "Derive keys with PBKDF2-with-SHA256 (210k+ iterations) or "
            "Argon2."},
    {"id": "CRP-03", "cat": "CRP", "sev": "MEDIUM", "w": 5,
     "kind": "dex_any", "pat": r"(?i)\b(SecretKeySpec|IvParameterSpec)\b",
     "title": "Raw symmetric key construction",
     "detail": "SecretKeySpec / IvParameterSpec usage implies keys and "
               "IVs built from byte arrays -- often hardcoded constants.",
     "fix": "Keep keys in Android Keystore (AndroidKeyStore provider) and "
            "generate IVs randomly."},
    {"id": "CRP-04", "cat": "CRP", "sev": "MEDIUM", "w": 4,
     "kind": "dex_any", "pat": r"(?i)\b(MD5|SHA-?1)\b",
     "title": "MD5 / SHA-1 digest strings present",
     "detail": "Weak digests referenced in code. Fine for cache keys; "
               "fatal for signatures or integrity checks.",
     "fix": "Use SHA-256+ for anything security-relevant."},
    {"id": "CRP-05", "cat": "CRP", "sev": "HIGH", "w": 7,
     "kind": "absence",
     "pat": ["androidx.security.crypto", "encryptedsharedpreferences",
             "masterkey", "androidkeystore", "keystore"],
     "title": "No Android Keystore / EncryptedStorage markers",
     "detail": "No use of Android Keystore or EncryptedSharedPreferences "
               "-- secrets and tokens likely sit in plain prefs/SQLite.",
     "fix": "Store tokens in EncryptedSharedPreferences and keys inside "
            "AndroidKeyStore, hardware-backed when available."},

    # ---------------- DEBUG / TAMPER ------------------------
    {"id": "DBG-01", "cat": "DBG", "sev": "CRITICAL", "w": 10,
     "kind": "manifest", "pat": "debuggable",
     "title": "Manifest references debuggable flag",
     "detail": "The binary manifest string pool contains 'debuggable'. "
               "If enabled, adb can attach, read app data and inject "
               " Frida -- the classic first step of every crack.",
     "fix": "Keep debuggable=false (or absent) in release; assert it in "
            "CI with a manifest linter."},
    {"id": "DBG-02", "cat": "DBG", "sev": "MEDIUM", "w": 6,
     "kind": "manifest", "pat": "allowBackup",
     "title": "allowBackup referenced in manifest",
     "detail": "Backup flag appears in the manifest pool. If true, app "
               "data (including entitlement caches) is extractable via "
               "adb backup.",
     "fix": "Set allowBackup=false or exclude sensitive data with "
            "fullBackupContent rules."},
    {"id": "DBG-03", "cat": "DBG", "sev": "MEDIUM", "w": 6,
     "kind": "manifest", "pat": "usesCleartextTraffic",
     "title": "Cleartext traffic flag in manifest",
     "detail": "usesCleartextTraffic referenced -- HTTP allowed. MITM "
               "can rewrite API answers (fake entitlements).",
     "fix": "Block cleartext via networkSecurityConfig and enforce "
            "HTTPS everywhere."},
    {"id": "DBG-04", "cat": "DBG", "sev": "HIGH", "w": 7,
     "kind": "absence",
     "pat": ["isdebuggerconnected", "waitfordebugger", "tracerpid",
              "ptrace", "debug.waitfordebugger"],
     "title": "No anti-debug markers",
     "detail": "No isDebuggerConnected / TracerPid style checks. "
               "Debuggers attach freely to the release build.",
     "fix": "Check Debug.isDebuggerConnected + parse /proc/self/status "
            "TracerPid on sensitive paths; abort on hit."},
    {"id": "DBG-05", "cat": "DBG", "sev": "HIGH", "w": 8,
     "kind": "absence",
     "pat": ["emulator", "goldfish", "ranchu", "qemu", "genymotion",
              "isemulator"],
     "title": "No emulator detection markers",
     "detail": "No emulator fingerprints. Crackers replay purchases and "
               "bots on emulators.",
     "fix": "Check Build fingerprints / sensors on account actions; "
            "challenge emulator traffic server-side."},

    # ---------------- ROOT / HOOK DEFENSE -------------------
    {"id": "RDT-01", "cat": "RDT", "sev": "HIGH", "w": 8,
     "kind": "absence",
     "pat": ["/system/bin/su", "/system/xbin/su", "/su/bin/su",
             "magisk", "rootbeer", "com.scottyab.rootbeer",
             "libsuperuser", "supersu", "topjohnwu", "busybox",
             "which su"],
     "title": "No root detection markers",
     "detail": "No su-path / Magisk / RootBeer strings. Rooted devices "
               "hook and modify the app at will.",
     "fix": "Run layered root checks (paths, props, binaries) and "
            "refuse sensitive operations when rooted."},
    {"id": "RDT-02", "cat": "RDT", "sev": "HIGH", "w": 7,
     "kind": "absence",
     "pat": ["frida", "gum-js-loop", "xposedbridge", "xposed",
             "substrate", "lsposed", "edxposed", "sandhook",
             "epic hook"],
     "title": "No hooking-framework detection (Frida / Xposed)",
     "detail": "No anti-hook strings. Frida injects JS that flips any "
               "isPremium() return value in memory.",
     "fix": "Scan maps for frida/gadget/agent, detect native hooks on "
            "critical functions; degrade features on hit."},
    {"id": "RDT-03", "cat": "RDT", "sev": "MEDIUM", "w": 5,
     "kind": "absence",
     "pat": ["safetynet", "attestation", "playintegrity",
             "integrityverdict", "meetsbasicintegrity"],
     "title": "No remote attestation markers",
     "detail": "No Play Integrity / SafetyNet strings. Nothing proves "
               "the device+binary are genuine.",
     "fix": "Request a Play Integrity verdict server-side on sensitive "
            "actions; bind it to the session."},
    {"id": "RDT-04", "cat": "RDT", "sev": "MEDIUM", "w": 5,
     "kind": "dex_any", "pat": r"(?i)\b(packer|secneo|jiagu|bangcle|"
                               r"ijiami|nqshield|tencent[\w.]*protect)\b",
     "title": "Third-party packer markers present (good)",
     "detail": "Protective packing strings found -- raises reverse "
               "difficulty (listed for completeness).",
     "fix": "Keep the packer updated; test on every new Android "
            "release.", "good": True},

    # ---------------- ATTACK SURFACE -------------------------
    {"id": "SRF-01", "cat": "SRF", "sev": "HIGH", "w": 9,
     "kind": "dex_any", "pat": r"addJavascriptInterface",
     "title": "addJavascriptInterface bridge",
     "detail": "JS bridge exposed to WebView content. With file access "
               "or mixed content this becomes remote code execution.",
     "fix": "Restrict @JavascriptInterface to a minimal object; disable "
            "file access; run untrusted content in a separate process."},
    {"id": "SRF-02", "cat": "SRF", "sev": "MEDIUM", "w": 6,
     "kind": "dex_any",
     "pat": r"(?i)setAllow(UniversalAccess|FileAccess|FileRead|"
            r"FileWrite)FromFileURLs\(true\)?|setAllowFileAccess",
     "title": "WebView file access enabled",
     "detail": "File-access flags appear in code; file:// pages can read "
               "app-private storage.",
     "fix": "Disable file access; serve content over https://app-"
            "origin instead."},
    {"id": "SRF-03", "cat": "SRF", "sev": "MEDIUM", "w": 5,
     "kind": "dex_any", "pat": r"(?i)setJavaScriptEnabled\(true\)?",
     "title": "JavaScript enabled in WebView",
     "detail": "JS enabled is common, listed so it is reviewed together "
               "with the bridge rules.",
     "fix": "Fine on its own -- audit SRF-01/02 in the same build."},
    {"id": "SRF-04", "cat": "SRF", "sev": "HIGH", "w": 8,
     "kind": "dex_any",
     "pat": r"(?i)(MODE_WORLD_(READABLE|WRITABLE)|world_readable|"
            r"world_writable)",
     "title": "World-readable/writable storage",
     "detail": "Files created world-visible: any app (or file manager) "
               "reads tokens and entitlement caches.",
     "fix": "Use MODE_PRIVATE; never expose private storage."},
    {"id": "SRF-05", "cat": "SRF", "sev": "HIGH", "w": 7,
     "kind": "manifest", "pat": "exported",
     "title": "exported attribute referenced in manifest",
     "detail": "The manifest pool contains 'exported'. Any exported "
               "activity/receiver without permission is a public entry "
               "point (verify values in the merged manifest).",
     "fix": "Export only the deep-link entry points; guard them with "
            "permissions and input validation."},
    {"id": "SRF-06", "cat": "SRF", "sev": "MEDIUM", "w": 5,
     "kind": "absence",
     "pat": ["certificatepinner", "sslpinning", "certificatepinning",
             "pin_certificate", "okhttp3/certificatepinner"],
     "title": "No TLS certificate pinning markers",
     "detail": "No pinning strings. MITM with a user CA can read and "
               "edit API traffic.",
     "fix": "Pin leaf/intermediate keys per-connection; ship a backup "
            "pin."},

    # ---------------- OBFUSCATION / PACKING -----------------
    {"id": "OBF-01", "cat": "OBF", "sev": "HIGH", "w": 8,
     "kind": "metric", "op": "<", "thr": 0.15, "mkey": "obf_ratio",
     "title": "Code obfuscation minimal (class names readable)",
     "detail": "Only {val:.0%} of top-level classes look obfuscated. "
               "Plain names = trivial decompilation and patching.",
     "fix": "Enable R8/ProGuard with aggressive mapping rules + resource "
            "obfuscation; consider DexGuard for premium builds."},
    {"id": "OBF-02", "cat": "OBF", "sev": "INFO", "w": 3,
     "kind": "metric", "op": ">", "thr": 8, "mkey": "dex_mb",
     "title": "Very large DEX payload",
     "detail": "Total DEX size is {val:.1f} MB -- a wide attack "
               "surface to review before release.",
     "fix": "Strip dead code and debug symbols from release builds."},
    {"id": "OBF-03", "cat": "OBF", "sev": "INFO", "w": 2,
     "kind": "metric", "op": ">", "thr": 60000, "mkey": "strings_total",
     "title": "Huge string pool",
     "detail": "{val} pooled strings -- audit for leaks with a strings "
               "pass before shipping.",
     "fix": "Prune debug strings and unused resources from release."},

    # ---------------- SIGNING -------------------------------
    {"id": "SIG-01", "cat": "SIG", "sev": "HIGH", "w": 7,
     "kind": "struct", "cond": "no_meta_signature",
     "title": "No v1 signature file under META-INF",
     "detail": "No META-INF/*.RSA|DSA|EC entry found. The build may be "
               "unsigned or only v2/v3-signed (which live in the zip "
               "block) -- verify with apksigner verify.",
     "fix": "Sign release builds with v1+v2(+v3); add apksigner "
            "verification to CI."},
    {"id": "SIG-02", "cat": "SIG", "sev": "HIGH", "w": 8,
     "kind": "absence",
     "pat": ["get_signatures", "get_signing_certificates", "checksignature",
             "signaturecheck", "packagemanager.getsignatures"],
     "title": "No signature self-verification in code",
     "detail": "Nothing checks the APK signing certificate at runtime. "
               "A re-signed cracked copy runs undetected.",
     "fix": "Compare your signing cert hash at startup (and in the "
            "callback of license checks); fail closed on mismatch."},

    # ---------------- PRIVACY -------------------------------
    {"id": "PRV-01", "cat": "PRV", "sev": "MEDIUM", "w": 4,
     "kind": "dex_any",
     "pat": r"(?i)\b(imei|deviceid|advertisingid|adid|udid|"
            r"android_id)\b",
     "title": "Device identifier usage",
     "detail": "Device identifiers (IMEI / Ad-ID / Android ID) are "
               "referenced. Trackers and privacy reviews care.",
     "fix": "Use scoped tokens (ASDID) instead of hardware ids; declare "
            "data safety honestly."},
    {"id": "PRV-02", "cat": "PRV", "sev": "INFO", "w": 3,
     "kind": "dex_any",
     "pat": r"android\.permission\.(READ_CONTACTS|READ_SMS|"
            r"RECORD_AUDIO|ACCESS_FINE_LOCATION|READ_CALL_LOG|"
            r"READ_EXTERNAL_STORAGE)",
     "title": "Sensitive permissions referenced",
     "detail": "Dangerous permission constants appear in the pool -- "
               "justify each at review time.",
     "fix": "Request at runtime, minimum scope, clear purpose in "
            "Play listing."},
]

DEFAULT_MODEL = {
    "model": "APK-SENTINEL",
    "version": "2.0.0",
    "engine": "weighted-heuristic-v2",
    "created": "2026-11-24",
    "weights": {r["id"]: r["w"] for r in RULES},
    "category_factors": {c: CATS[c]["factor"] for c in CATS},
    "grade_bands": {"A+": 92, "A": 82, "B": 72, "C": 58, "D": 42},
    "notes": "Local offline scoring model. Rule weights can be tuned in "
             "the encrypted model.nxm container.",
}


def load_model():
    """Merge vault/model.nxm over the built-in defaults (file wins)."""
    model = json.loads(json.dumps(DEFAULT_MODEL))   # deep copy
    try:
        plain, _ = vault_read(MODEL_FILE)
        over = json.loads(plain.decode("utf-8"))
        for k in ("model", "version", "engine", "notes"):
            if k in over:
                model[k] = over[k]
        if isinstance(over.get("weights"), dict):
            model["weights"].update(over["weights"])
        if isinstance(over.get("grade_bands"), dict):
            model["grade_bands"].update(over["grade_bands"])
    except Exception:
        pass    # vault model absent -> built-in defaults
    return model


def model_stats():
    """Human readable summary of the loaded model (for the UI)."""
    m = load_model()
    return {
        "name": m["model"] + " / " + m["engine"],
        "version": m["version"],
        "rules": len(RULES),
        "categories": len(CATS),
        "weights": len(m["weights"]),
        "file": MODEL_FILE,
    }


# ============================================================
#  APK SENTINEL ENGINE  --  ZIP/DEX STATIC ANALYSIS
# ============================================================
#  Parses an APK with the stdlib zipfile, walks every classes
#  *. dex file (header + string pool + type / method ids),
#  scans the binary AndroidManifest string pool, then runs the
#  local AI model over the extracted surface. The output is a
#  protection score (0-100), a grade and a crack-vector list --
#  everything an attacker would need to unlock / crack the
#  release build BEFORE it ships.
# ============================================================

_RE_DEX_NAME = _re.compile(r"^classes\d*\.dex$")
_RE_SIG_FILE = _re.compile(r"^META-INF/.*\.(RSA|DSA|EC)$", _re.IGNORECASE)
_RE_LIB_ABI = _re.compile(r"^lib/([a-z0-9_-]+)/.+\.so$")


def _uleb128(buf, off):
    """Read a uleb128 value. -> (value, new_offset)"""
    result, shift = 0, 0
    for _ in range(5):
        b = buf[off]
        off += 1
        result |= (b & 0x7F) << shift
        if not (b & 0x80):
            break
        shift += 7
    return result & 0xFFFFFFFF, off


def _mutf8(b):
    """Lenient MUTF-8 (CESU-8 style) decode of a DEX string body."""
    out, i, n = [], 0, len(b)
    while i < n:
        c = b[i]
        if c < 0x80:
            out.append(chr(c))
            i += 1
        elif (c & 0xE0) == 0xC0 and i + 1 < n:
            cp = ((c & 0x1F) << 6) | (b[i + 1] & 0x3F)
            out.append(chr(cp) if 0 < cp < 0xD800 or cp > 0xDFFF else "?")
            i += 2
        elif (c & 0xF0) == 0xE0 and i + 2 < n:
            cp = ((c & 0x0F) << 12) | ((b[i + 1] & 0x3F) << 6) | (b[i + 2] & 0x3F)
            i += 3
            if 0xD800 <= cp <= 0xDBFF and i + 2 < n and (b[i] & 0xF0) == 0xE0:
                lo = ((b[i] & 0x0F) << 12) | ((b[i + 1] & 0x3F) << 6) | (b[i + 2] & 0x3F)
                if 0xDC00 <= lo <= 0xDFFF:
                    cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00)
                    i += 3
            out.append(chr(cp) if cp else "?")
        else:
            out.append("?")
            i += 1
    return "".join(out)


def dex_parse(blob, max_strings=120_000):
    """Parse a classes.dex -> {strings, classes, methods, sizes}.

    Only the parts needed for static analysis are decoded: the
    string pool, type descriptors and method ids. Malformed or
    truncated pools degrade gracefully instead of raising.
    """
    if len(blob) < 112 or blob[:4] != b"dex\n":
        raise ValueError("not a DEX file (bad magic)")
    (s_ids_size, s_ids_off, t_ids_size, t_ids_off, m_ids_size,
     m_ids_off, c_defs_size) = struct.unpack_from(
        "<7I", blob, 56)                      # string_ids_size .. class_defs_size
    s_ids_size = min(s_ids_size, max_strings)

    strings = []
    try:
        offs = struct.unpack_from("<{}I".format(s_ids_size), blob, s_ids_off)
        for so in offs:
            if so <= 0 or so + 4 > len(blob):
                continue
            _, p = _uleb128(blob, so)
            end = blob.find(b"\x00", p, p + 512)
            if end < 0:
                continue
            strings.append(_mutf8(blob[p:end]))
    except struct.error:
        pass

    classes = []
    try:
        t_offs = struct.unpack_from("<{}I".format(t_ids_size), blob, t_ids_off)
        for to in t_offs:
            if to + 4 > len(blob):
                break
            idx = struct.unpack_from("<I", blob, to)[0]
            if 0 <= idx < len(strings):
                classes.append(strings[idx])
    except struct.error:
        pass

    methods = []
    try:
        for i in range(m_ids_size):
            off = m_ids_off + i * 8
            if off + 8 > len(blob):
                break
            _cls, _proto, name_idx = struct.unpack_from("<HHI", blob, off)
            if 0 <= name_idx < len(strings):
                methods.append(strings[name_idx])
    except struct.error:
        pass

    return {
        "strings": strings,
        "classes": classes,
        "methods": methods,
        "strings_count": s_ids_size,
        "classes_count": c_defs_size,
    }


def _manifest_tokens(raw, tokens):
    """Heuristic scan of the binary manifest string pool.

    AXML pools are UTF-16LE (sometimes UTF-8); both encodings of
    each token are probed directly in the raw blob.
    """
    found = set()
    if not raw:
        return found
    for t in tokens:
        tlow = t.lower().encode("utf-8", "ignore")
        if tlow and (tlow in raw or t.encode("utf-16-le") in raw):
            found.add(t)
    return found


def _top_class_names(type_descriptors):
    """'Lcom/foo/bar/Baz;' -> 'Baz' (last path segment)."""
    out = []
    for d in type_descriptors:
        if d.startswith("L") and d.endswith(";"):
            out.append(d[1:-1].rsplit("/", 1)[-1])
    return out


def _obf_ratio(class_names):
    """Share of names that look R8/ProGuard-obfuscated."""
    if len(class_names) < 40:
        return 0.0          # too small to judge
    obf = 0
    for name in class_names:
        if len(name) <= 2:
            obf += 1
        elif _re.fullmatch(r"[a-zA-Z][0-9]{1,3}", name):
            obf += 1
        elif _re.fullmatch(r"[a-oA-O][a-zA-Z0-9]?", name):
            obf += 1
    return obf / len(class_names)


def analyze_apk(path, model=None, progress=None):
    """Full static analysis of an APK. -> report dict.

    progress(stage:str, pct:int) may be called from this thread;
    the page forwards it to the Tk queue.
    """
    model = model or load_model()
    path = os.path.abspath(path)
    size = os.path.getsize(path)

    def stage(text, pct):
        if progress:
            progress(text, pct)

    stage("OPENING CONTAINER", 5)
    with open(path, "rb") as f:
        head = f.read(4)
    if head[:2] != b"PK":
        raise ValueError("not an APK (zip magic missing)")
    with _zipfile.ZipFile(path) as zf:
        names = zf.namelist()
        stage("MAPPING ZIP SURFACE", 12)
        manifest_raw = b""
        try:
            if "AndroidManifest.xml" in names:
                manifest_raw = zf.read("AndroidManifest.xml")
        except Exception:
            manifest_raw = b""
        dex_blobs, dex_total = [], 0
        dex_names = [n for n in names if _RE_DEX_NAME.match(n)]
        dex_names.sort(key=lambda n: (len(n), n))
        for i, n in enumerate(dex_names):
            stage("PARSING " + n.upper(), 20 + int(40 * (i + 1) / max(1, len(dex_names))))
            try:
                blob = zf.read(n)
            except Exception:
                continue
            dex_total += len(blob)
            try:
                dex_blobs.append(dex_parse(blob))
            except ValueError:
                continue
        stage("EXTRACTING SIGNATURE + NATIVE INFO", 66)
        sig_files = [n for n in names if _RE_SIG_FILE.match(n)]
        native_abis = set()
        for n in names:
            m = _RE_LIB_ABI.match(n)
            if m:
                native_abis.add(m.group(1))
        has_arsc = "resources.arsc" in names

    if not dex_blobs and not manifest_raw:
        raise ValueError("no DEX and no manifest inside this package")

    # ---- pooled surface -------------------------------------
    stage("INDEXING DEX SURFACE", 72)
    all_strings, all_classes = [], []
    for d in dex_blobs:
        all_strings.extend(d["strings"])
        all_classes.extend(d["classes"])
    strings_total = len(all_strings)
    top_classes = _top_class_names(all_classes)
    obf_ratio = _obf_ratio(top_classes)
    # joined lowercase pool -- absence markers are substring probes
    pool = "\n".join(all_strings).lower()
    if len(pool) > 12_000_000:
        pool = pool[:12_000_000]

    manifest_flags = _manifest_tokens(manifest_raw, [
        "debuggable", "allowBackup", "usesCleartextTraffic",
        "exported", "networkSecurityConfig", "versionName",
    ])
    no_meta_sig = not sig_files

    metrics = {
        "obf_ratio": obf_ratio,
        "dex_mb": dex_total / (1024 * 1024),
        "strings_total": strings_total,
        "classes_total": len(all_classes),
        "dex_count": len(dex_blobs),
    }

    # ---- rule engine ----------------------------------------
    stage("RUNNING LOCAL AI MODEL", 80)
    findings = []
    weights = model.get("weights", {})
    cat_factor = model.get("category_factors", {})
    regex_cache = {}

    for rule in RULES:
        rid = rule["id"]
        w = float(weights.get(rid, rule.get("w", 5)))
        kind = rule["kind"]
        hit, sample = False, None
        if kind == "dex_any" and all_strings:
            pat = rule["pat"]
            rx = regex_cache.get(pat)
            if rx is None:
                rx = _re.compile(pat)
                regex_cache[pat] = rx
            for s in all_strings:
                if len(s) < 4 or len(s) > 512:
                    continue
                m = rx.search(s)
                if m:
                    hit = True
                    sample = s[:96]
                    break
        elif kind == "manifest":
            hit = rule["pat"] in manifest_flags
        elif kind == "absence":
            markers = [x.lower() for x in rule["pat"]]
            if any(mk in pool for mk in markers) or \
                    any(m in manifest_flags for m in markers):
                hit = False
            else:
                hit = True          # none of the protective markers
        elif kind == "metric":
            val = metrics.get(rule["mkey"], 0)
            op, thr = rule["op"], rule["thr"]
            hit = (val < thr if op == "<" else val > thr)
            sample = val
            try:
                rule_detail = rule["detail"].format(val=val)
            except Exception:
                rule_detail = rule["detail"]
        elif kind == "struct":
            hit = bool(rule.get("cond") == "no_meta_signature" and no_meta_sig)
        if not hit:
            continue
        cat = rule["cat"]
        factor = float(cat_factor.get(cat, 1.0))
        findings.append({
            "id": rid, "cat": cat, "cat_name": CATS[cat]["name"],
            "sev": rule["sev"], "title": rule["title"],
            "detail": rule_detail if kind == "metric" else rule["detail"],
            "fix": rule["fix"],
            "w": w, "sample": sample,
            "good": bool(rule.get("good", False)),
        })

    # ---- scoring --------------------------------------------
    stage("SCORING PROTECTION LEVEL", 92)
    penalty, bonus = 0.0, 0.0
    cats_pen = {}
    for f in findings:
        if f["good"]:
            bonus += 3.0
            continue
        p = f["w"] * float(cat_factor.get(f["cat"], 1.0))
        penalty += p
        cats_pen[f["cat"]] = cats_pen.get(f["cat"], 0.0) + p
    score = int(round(max(4, min(100, 100.0 - penalty + bonus))))
    bands = model.get("grade_bands", DEFAULT_MODEL["grade_bands"])
    if score >= bands["A+"]:
        grade = "A+"
    elif score >= bands["A"]:
        grade = "A"
    elif score >= bands["B"]:
        grade = "B"
    elif score >= bands["C"]:
        grade = "C"
    elif score >= bands["D"]:
        grade = "D"
    else:
        grade = "F"

    crack = [f for f in findings
             if f["cat"] in ("LIC", "DBG", "SIG", "OBF")
             and f["sev"] in ("CRITICAL", "HIGH") and not f["good"]]

    stage("BUILDING REPORT", 98)
    with open(path, "rb") as f:
        sha256 = hashlib.sha256(f.read()).hexdigest()
    report = {
        "path": path,
        "file": os.path.basename(path),
        "size": size,
        "sha256": sha256,
        "scanned_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "zip_entries": len(names),
        "dex_count": len(dex_blobs),
        "dex_mb": round(dex_total / (1024 * 1024), 2),
        "strings_total": strings_total,
        "classes_total": len(all_classes),
        "methods_total": len(dex_blobs) and sum(len(d["methods"]) for d in dex_blobs) or 0,
        "native_abi": sorted(native_abis),
        "signed_v1": bool(sig_files),
        "sig_files": sig_files[:4],
        "has_arsc": has_arsc,
        "manifest_flags": sorted(manifest_flags),
        "obf_ratio": round(obf_ratio, 3),
        "findings": findings,
        "crack": [{"id": c["id"], "title": c["title"], "sev": c["sev"]}
                  for c in crack],
        "score": score,
        "grade": grade,
        "penalty": round(penalty, 1),
        "cats": {CATS[c]["name"]: round(v, 1) for c, v in cats_pen.items()},
        "metrics": metrics,
        "model": {"name": model["model"], "version": model["version"],
                  "engine": model["engine"], "rules": len(RULES)},
    }
    stage("DONE", 100)
    return report


_SEV_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "INFO": 3}


def apk_report_text(report):
    """Render a full human-readable report for export."""
    L = []
    L.append("=" * 64)
    L.append("XXNETRO APK SENTINEL REPORT")
    L.append("=" * 64)
    L.append("FILE        : " + report["file"])
    L.append("SIZE        : {:,} bytes".format(report["size"]))
    L.append("SHA-256     : " + report["sha256"])
    L.append("SCANNED     : " + report["scanned_at"])
    L.append("MODEL       : {} v{} ({})".format(
        report["model"]["name"], report["model"]["version"],
        report["model"]["engine"]))
    L.append("")
    L.append("PROTECTION SCORE : {}/100   GRADE : {}".format(
        report["score"], report["grade"]))
    L.append("ZIP ENTRIES : {}   DEX FILES : {}   DEX SIZE : {} MB".format(
        report["zip_entries"], report["dex_count"], report["dex_mb"]))
    L.append("STRINGS     : {:,}   CLASSES : {:,}   METHODS : {:,}".format(
        report["strings_total"], report["classes_total"],
        report["methods_total"]))
    L.append("NATIVE ABI  : " + (", ".join(report["native_abi"]) or "none"))
    L.append("V1 SIGNATURE: " + ("META-INF entries found" if
                                  report["signed_v1"] else "not found (verify with apksigner)"))
    L.append("OBFUSCATION : {:.0%} of class names look obfuscated".format(
        report.get("obf_ratio", 0)))
    L.append("MANIFEST FLAGS: " + (", ".join(report["manifest_flags"]) or "-"))
    L.append("")
    L.append("-" * 64)
    L.append("CRACK VECTORS (paths an attacker uses to unlock / crack)")
    L.append("-" * 64)
    if report["crack"]:
        for c in report["crack"]:
            L.append("  [{}] {}: {}".format(c["sev"], c["id"], c["title"]))
    else:
        L.append("  none detected at CRITICAL/HIGH level")
    L.append("")
    L.append("-" * 64)
    L.append("FINDINGS ({} total)".format(len(report["findings"])))
    L.append("-" * 64)
    for f in sorted(report["findings"],
                    key=lambda x: _SEV_ORDER.get(x["sev"], 9)):
        L.append("")
        L.append("[{}] {} / {}  ({})".format(
            f["sev"], f["id"], f["cat"], f["cat_name"]))
        L.append("  TITLE   : " + f["title"])
        if f.get("sample") is not None and f["sample"] != "":
            L.append("  SAMPLE  : " + str(f["sample"])[:96])
        L.append("  DETAIL  : " + " ".join(f["detail"].split()))
        L.append("  FIX     : " + " ".join(f["fix"].split()))
    L.append("")
    L.append("-" * 64)
    L.append("CATEGORY PENALTIES")
    L.append("-" * 64)
    for name, val in report.get("cats", {}).items():
        L.append("  {:<32} -{:>5}".format(name, val))
    L.append("")
    L.append("AUTHORIZED SECURITY TESTING USE ONLY.")
    return "\n".join(L) + "\n"


# ============================================================
#  TOOL 16 -- TLS AUDITOR  (cert / protocol / cipher review)
# ============================================================
#  Pure stdlib TLS inspection: wraps a socket with ssl, reads
#  the peer certificate in DER form and parses it with a mini
#  ASN.1 reader -- no cryptography package required.
# ============================================================

_CN_OID = b"\x55\x04\x03"                    # OID 2.5.4.3 (CN)
_OID_SHA1RSA = b"\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x01\x05"
_OID_MD5RSA = b"\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x01\x04"
_WEAK_CIPHER_TOKENS = ("rc4", "des", "null", "export", "md5", "anon",
                       "des-cbc3", "3des", "idea")


def _der_tlv(data, off):
    """-> (tag, content_start, content_len)"""
    tag = data[off]
    off += 1
    l = data[off]
    off += 1
    if l & 0x80:
        n = l & 0x7F
        l = int.from_bytes(data[off:off + n], "big")
        off += n
    return tag, off, l


def _der_children(data, off=0, end=None):
    """Split a TLV buffer into (tag, content_bytes) nodes."""
    if end is None:
        end = len(data)
    nodes = []
    while off < end:
        try:
            tag, s, l = _der_tlv(data, off)
        except Exception:
            break
        if s + l > end:
            break
        nodes.append((tag, data[s:s + l]))
        off = s + l
    return nodes


def _parse_asn1_time(value_bytes):
    """YYMMDDHHMMSSZ / YYYYMMDDHHMMSSZ -> datetime or None."""
    try:
        s = value_bytes.decode("ascii", "replace").strip()
        s = s.rstrip("Z")
        if len(s) == 12:
            dt = datetime.strptime(s, "%y%m%d%H%M%S")
        elif len(s) == 14:
            dt = datetime.strptime(s, "%Y%m%d%H%M%S")
        else:
            return None
        return dt
    except Exception:
        return None


def _rdn_cn(rdn_seq_content):
    """Extract CN from an RDN SEQUENCE content. -> str or ''"""
    best = ""
    for _tag, rdn_set in _der_children(rdn_seq_content):
        for _t2, atv in _der_children(rdn_set):
            parts = _der_children(atv)
            if len(parts) < 2:
                continue
            oid, val = parts[0], parts[1]
            if oid[0] == 0x06 and oid[1] == _CN_OID:
                try:
                    text = val[1].decode("utf-8", "replace").strip()
                except Exception:
                    text = ""
                if text:
                    best = text
    return best


def cert_parse(der):
    """Minimal X.509 parse -> dict (or None when unparsable).

    Certificate ::= SEQUENCE{ tbsCertificate, sigAlgo, signature }
    tbsCertificate ::= SEQ{ [0]version?, serial, sigAlgo, issuer,
                            validity{notBefore,notAfter}, subject, ... }
    """
    if not der:
        return None
    try:
        top = _der_children(der)
        if not top or top[0][0] != 0x30:
            return None
        cert_nodes = _der_children(top[0][1])          # Certificate body
        seq_nodes = [n for n in cert_nodes if n[0] == 0x30]
        if not seq_nodes:
            return None
        tbs = _der_children(seq_nodes[0][1])            # tbsCertificate body
        cert = {"sha1_sig": _OID_SHA1RSA in der,
                "md5_sig": _OID_MD5RSA in der}
        if tbs and tbs[0][0] == 0xA0:                  # [0] version wrapper
            tbs = tbs[1:]
        if tbs and tbs[0][0] == 0x02:                  # serial number
            cert["serial"] = tbs[0][1].hex()
            tbs = tbs[1:]
        issuer_cn = subject_cn = ""
        not_before = not_after = None
        for tag, content in tbs:
            if tag != 0x30:
                continue
            kids = _der_children(content)
            times = [v for t, v in kids if t in (0x17, 0x18)]
            if len(times) == 2 and not_before is None:  # validity
                not_before = _parse_asn1_time(times[0])
                not_after = _parse_asn1_time(times[1])
                continue
            cn = _rdn_cn(content)                       # RDN names
            if cn:
                if not issuer_cn:
                    issuer_cn = cn
                elif not subject_cn:
                    subject_cn = cn
        cert.update({
            "subject_cn": subject_cn or "?",
            "issuer_cn": issuer_cn or "?",
            "self_signed": bool(subject_cn and subject_cn == issuer_cn),
            "not_before": not_before,
            "not_after": not_after,
        })
        return cert
    except Exception:
        return None


def _cn_matches_host(cn, host):
    cn, host = cn.lower().strip(), host.lower().strip()
    if cn.startswith("*."):
        base = cn[1:]
        return host.endswith(base) and host != base
    return host == cn or host.endswith("." + cn)


def tls_audit(host, port=443, timeout=None):
    """-> dict(protocol, cipher, bits, cert, findings[], ok, error)"""
    import ssl
    timeout = timeout or CFG["api_timeout"]
    host = host.strip().replace("https://", "").replace("http://", "").split("/")[0]
    out = {"host": host, "port": port, "findings": [], "ok": False,
           "protocol": None, "cipher": None, "bits": None, "cert": None,
           "error": None}
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with socket.create_connection((host, port), timeout=timeout) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as tls:
                out["protocol"] = tls.version()
                c = tls.cipher()
                if c:
                    out["cipher"] = c[0]
                    out["bits"] = c[2]
                der = tls.getpeercert(True)
        out["cert"] = cert_parse(der)
        out["ok"] = True
    except Exception as e:
        out["error"] = str(e) or e.__class__.__name__
        return out

    # ---- protocol / cipher findings --------------------------
    proto = out.get("protocol") or ""
    if proto in ("SSLv3", "SSLv2", "TLSv1", "TLSv1.0", "TLSv1.1"):
        out["findings"].append(
            ("HIGH", "Legacy protocol negotiated",
             "Session uses {} -- broken against POODLE / BEAST style "
             "attacks. Server must require TLS 1.2+.".format(proto)))
    elif proto == "TLSv1.2":
        out["findings"].append(
            ("OK", "TLS 1.2 in use",
             "Acceptable. Prefer offering TLS 1.3 for forward-secret "
             "one-round-trip handshakes."))
    elif proto == "TLSv1.3":
        out["findings"].append(
            ("OK", "TLS 1.3 in use", "Modern protocol with forward secrecy."))
    cipher = (out.get("cipher") or "").lower()
    weak = [t for t in _WEAK_CIPHER_TOKENS if t in cipher]
    if weak:
        out["findings"].append(
            ("HIGH", "Weak cipher suite",
             "Suite {} contains weak primitive(s): {}. Replace with "
             "ECDHE+AES-GCM / CHACHA20-POLY1305.".format(
                 out.get("cipher"), ", ".join(weak))))
    bits = out.get("bits") or 0
    if bits and bits < 112:
        out["findings"].append(
            ("HIGH", "Short key length",
             "Effective key bits {} < 112 -- export-grade or legacy "
             "key exchange.".format(bits)))

    # ---- certificate findings -------------------------------
    cert = out.get("cert") or {}
    if not cert:
        out["findings"].append(
            ("MEDIUM", "Certificate not parsable",
             "Could not read the peer certificate DER."))
        return out
    now = datetime.now()
    if cert.get("not_after"):
        try:
            left = (cert["not_after"] - now).days
            out["days_left"] = left
            if left < 0:
                out["findings"].append(
                    ("CRITICAL", "Certificate EXPIRED",
                     "notAfter was {} -- browsers will hard-fail.".format(
                         cert["not_after"].strftime("%Y-%m-%d"))))
            elif left < 14:
                out["findings"].append(
                    ("MEDIUM", "Certificate expires in {} days".format(left),
                     "Renew now to avoid an outage."))
            else:
                out["findings"].append(
                    ("OK", "Certificate valid for {} days".format(left), ""))
        except Exception:
            pass
    if cert.get("self_signed"):
        out["findings"].append(
            ("MEDIUM", "Self-signed certificate",
             "Issuer == Subject. Clients will reject it unless the "
             "certificate is pinned."))
    if cert.get("sha1_sig"):
        out["findings"].append(
            ("HIGH", "SHA-1 signed certificate",
             "Signature algorithm is sha1WithRSAEncryption -- collision "
             "attacks are practical. Reissue with SHA-256+."))
    if cert.get("md5_sig"):
        out["findings"].append(
            ("CRITICAL", "MD5 signed certificate",
             "MD5 signatures are forgeable. Reissue immediately."))
    cn = cert.get("subject_cn", "")
    if cn and not _cn_matches_host(cn, host):
        out["findings"].append(
            ("MEDIUM", "Certificate CN mismatch",
             "CN '{}' does not cover host '{}'. Check SNI / SAN "
             "entries.".format(cn, host)))
    return out


class TlsPage(BasePage):

    TITLE = "TLS AUDITOR"
    SUB = "CERTIFICATE / PROTOCOL / CIPHER REVIEW"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="HOST", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.host_e = self.entry(inner, width=30, placeholder="example.com")
        self.host_e.pack(side="left", padx=(10, 10))
        tk.Label(inner, text="PORT", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(side="left")
        self.port_e = self.entry(inner, width=7, placeholder="443")
        self.port_e.pack(side="left", padx=(10, 10))
        self.port_e.delete(0, "end")
        self.port_e.insert(0, "443")
        NeonButton(inner, "AUDIT", width=100, height=32,
                   font=(self.app.f_mono, 10, "bold"),
                   command=self.start).pack(side="left", padx=2)

        body = tk.Frame(self, bg=THEME["bg"])
        body.pack(fill="both", expand=True, padx=14)
        left = tk.Frame(body, bg=THEME["bg"])
        left.pack(side="left", fill="both", expand=True)
        right = tk.Frame(body, bg=THEME["bg"])
        right.pack(side="left", fill="both", expand=True)

        sbox = tk.Frame(left, bg=THEME["panel"], highlightthickness=1,
                        highlightbackground=THEME["accent_dim"])
        sbox.pack(fill="x", pady=(0, 8))
        sb = tk.Frame(sbox, bg=THEME["panel"])
        sb.pack(fill="x", padx=12, pady=12)
        tk.Label(sb, text="SESSION", bg=THEME["panel"], fg=THEME["glow"],
                 font=(self.app.f_mono, 10, "bold")).pack(anchor="w")
        self.r_proto = self.label_pair(sb, "PROTOCOL")
        self.r_cipher = self.label_pair(sb, "CIPHER")
        self.r_bits = self.label_pair(sb, "KEY BITS")

        cbox = tk.Frame(left, bg=THEME["panel"], highlightthickness=1,
                        highlightbackground=THEME["accent_dim"])
        cbox.pack(fill="both", expand=True)
        cb = tk.Frame(cbox, bg=THEME["panel"])
        cb.pack(fill="x", padx=12, pady=12)
        tk.Label(cb, text="CERTIFICATE", bg=THEME["panel"], fg=THEME["glow"],
                 font=(self.app.f_mono, 10, "bold")).pack(anchor="w")
        self.r_cn = self.label_pair(cb, "SUBJECT CN")
        self.r_issuer = self.label_pair(cb, "ISSUER")
        self.r_serial = self.label_pair(cb, "SERIAL")
        self.r_nb = self.label_pair(cb, "VALID FROM")
        self.r_na = self.label_pair(cb, "VALID TO")
        self.r_days = self.label_pair(cb, "DAYS LEFT")

        fbox = tk.Frame(right, bg=THEME["panel"], highlightthickness=1,
                         highlightbackground=THEME["accent_dim"])
        fbox.pack(fill="both", expand=True)
        tk.Label(fbox, text="FINDINGS", bg=THEME["panel"], fg=THEME["glow"],
                 font=(self.app.f_mono, 10, "bold")).pack(anchor="w",
                                                          padx=12, pady=(12, 2))
        wrap = tk.Frame(fbox, bg=THEME["panel"])
        wrap.pack(fill="both", expand=True, padx=12, pady=(4, 6))
        cols = ("sev", "title")
        self.tree = ttk.Treeview(wrap, columns=cols, show="headings", height=9)
        for cid, w in (("sev", 90), ("title", 300)):
            self.tree.heading(cid, text=cid.upper())
            self.tree.column(cid, width=w, anchor="w")
        vsb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(side="left", fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._pick)
        self.detail = tk.Text(fbox, bg=THEME["panel2"], fg=THEME["text"],
                              font=(self.app.f_mono, 8), height=5, bd=0,
                              highlightthickness=1,
                              highlightbackground=THEME["accent_dim"],
                              wrap="word")
        self.detail.pack(fill="x", padx=12, pady=(2, 12))
        self._findings = []

    def _pick(self, _e=None):
        sel = self.tree.selection()
        if not sel:
            return
        f = self._findings[self.tree.index(sel[0])]
        self.detail.delete("1.0", "end")
        self.detail.insert("1.0", "[{}] {}\n{}".format(
            f[0], f[1], f[2] or "-"))

    def start(self):
        host = self.host_e.get().strip()
        if not host:
            self.status("ENTER A HOST", THEME["warn"])
            return
        try:
            port = int(self.port_e.get() or 443)
        except ValueError:
            port = 443

        def work():
            return tls_audit(host, port)

        def done(res):
            if not res.get("ok"):
                self.status("HANDSHAKE FAILED", THEME["bad"])
                self.r_proto.config(text="--")
                messagebox.showerror("TLS AUDIT", res.get("error") or "failed")
                return
            self.r_proto.config(text=res.get("protocol") or "--")
            self.r_cipher.config(text=res.get("cipher") or "--")
            self.r_bits.config(text=str(res.get("bits") or "--"))
            cert = res.get("cert") or {}
            self.r_cn.config(text=cert.get("subject_cn", "--"))
            self.r_issuer.config(text=cert.get("issuer_cn", "--"))
            self.r_serial.config(text=(cert.get("serial") or "--")[:24])
            self.r_nb.config(text=str(cert.get("not_before") or "--")[:19])
            self.r_na.config(text=str(cert.get("not_after") or "--")[:19])
            self.r_days.config(text=str(res.get("days_left", "--")))
            self._findings = res.get("findings", [])
            for w in self.tree.get_children():
                self.tree.delete(w)
            sev_col = {"CRITICAL": THEME["bad"], "HIGH": THEME["bad"],
                       "MEDIUM": THEME["warn"], "OK": THEME["ok"]}
            for f in self._findings:
                self.tree.insert("", "end", values=(f[0], f[1]),
                                 tags=(f[0],))
                self.tree.tag_configure(f[0], foreground=sev_col.get(f[0], THEME["text"]))
            self.detail.delete("1.0", "end")
            crit = sum(1 for f in self._findings if f[0] in ("CRITICAL", "HIGH"))
            self.status("{} FINDINGS ({} CRIT/HIGH)".format(
                len(self._findings), crit),
                THEME["bad"] if crit else THEME["ok"])
            self.app.store.log("TLS", "audit", "{}:{}".format(host, port),
                               "proto={}".format(res.get("protocol")))

        self.run(work, done, busy="AUDIT " + host)


# ============================================================
#  TOOL 17 -- VULN MATCHER  (offline curated CVE mini-DB)
# ============================================================
#  Feed it a service banner (from NMAP SCAN / BANNER GRAB) or
#  a product+version pair; it matches against a curated offline
#  database of famous vulnerabilities. This is a triage aid,
#  not a full CVE feed -- always verify against the linked
#  advisory before acting.
# ============================================================

_V_RE = _re.compile(r"\d+(?:\.\d+)+(?:[a-z]\d+)?|\d+")
_NVD = "https://nvd.nist.gov/vuln/detail/"

VULN_DB = [
    {"id": "CVE-2021-44228", "prod": "Apache Log4j2", "sev": "CRIT",
     "cat": "RCE", "alias": ["log4j", "log4j-core", "log4j 2"],
     "vmin": "2.0", "vmax": "2.14.1", "fix": "2.15.0+",
     "title": "Log4Shell -- JNDI lookup RCE",
     "note": "The log4j-message JNDI injection. Also update related "
             "CVEs 45046 / 45132 (2.15 / 2.16)."},
    {"id": "CVE-2021-45046", "prod": "Apache Log4j2", "sev": "CRIT",
     "cat": "RCE", "alias": ["log4j", "log4j-core", "log4j 2"],
     "vmin": "2.15", "vmax": "2.15", "fix": "2.16.0+",
     "title": "Log4Shell incomplete fix (2.15)",
     "note": "DoS + RCE in certain configs; upgrade straight to 2.17."},
    {"id": "CVE-2014-0160", "prod": "OpenSSL", "sev": "HIGH",
     "cat": "INFO", "alias": ["openssl"],
     "vmin": "1.0.1", "vmax": "1.0.1f", "fix": "1.0.1g+",
     "title": "Heartbleed -- memory disclosure",
     "note": "64KB heartbeat over-read leaks private keys and "
             "session data."},
    {"id": "CVE-2016-2183", "prod": "OpenSSL / TLS stacks", "sev": "MED",
     "cat": "CRYPTO", "alias": ["openssl", "des-cbc3", "3des"],
     "any": True, "fix": "disable 3DES suites",
     "title": "SWEET32 -- 3DES block cipher birthday attack",
     "note": "Legacy 3DES in TLS: birthday attacks recover plaintext "
             "after long sessions. Prefer AES-GCM / ChaCha20."},
    {"id": "CVE-2014-3566", "prod": "SSLv3 (any product)", "sev": "MED",
     "cat": "PROTO", "alias": ["sslv3", "ssl 3"], "any": True,
     "fix": "disable SSLv3", "title": "POODLE -- SSLv3 downgrade attack",
     "note": "Protocol-level; version range does not apply. Switch it "
             "off at the server."},
    {"id": "CVE-2015-0204", "prod": "TLS (export key exchange)",
     "sev": "MED", "cat": "CRYPTO", "alias": ["openssl", "export"],
     "any": True, "fix": "disable export ciphers",
     "title": "FREAK -- export RSA downgrade",
     "note": "Client-usable MITM downgrade to export-grade RSA."},
    {"id": "CVE-2022-3786", "prod": "OpenSSL 3.x", "sev": "HIGH",
     "cat": "BUG", "alias": ["openssl"], "vmin": "3.0.0", "vmax": "3.0.6",
     "fix": "3.0.7+",
     "title": "Punycode buffer overflow (X.509)",
     "note": "Also CVE-2022-3607; long email address punycode "
             "overflows the stack."},
    {"id": "CVE-2011-2523", "prod": "vsFTPD", "sev": "CRIT",
     "cat": "RCE", "alias": ["vsftpd", "vsftpd 2.3.4"],
     "versions": ["2.3.4"], "fix": "2.3.5+ / clean source",
     "title": "Backdoor in 2.3.4 build",
     "note": "The defaced 2.3.4 tarball opens a root shell on port "
             "6200 after a ':)' login."},
    {"id": "CVE-2017-5638", "prod": "Apache Struts 2", "sev": "CRIT",
     "cat": "RCE", "alias": ["struts", "struts2"],
     "vmin": "2.0.0", "vmax": "2.5.12", "fix": "2.5.13 / 2.3.32+",
     "title": "Jakarta Multipart RCE (content-type OGNL)",
     "note": "Affects 2.3.x <= 2.3.31 and 2.5.x <= 2.5.12."},
    {"id": "CVE-2019-10149", "prod": "Exim", "sev": "CRIT", "cat": "RCE",
     "alias": ["exim"], "vmin": "4.87", "vmax": "4.92",
     "fix": "4.92.1+ / 4.93+",
     "title": "RCE in the mail receiver",
     "note": "Remote command execution via crafted recipient address "
             "in vulnerable configs."},
    {"id": "CVE-2017-7494", "prod": "Samba", "sev": "HIGH", "cat": "RCE",
     "alias": ["samba"], "vmin": "3.5.0", "vmax": "4.6.3",
     "fix": "4.6.4 / 4.5.10 / 4.4.13+",
     "title": "SambaCry -- shared library upload RCE",
     "note": "Upload .so to a writable share + username map script "
             "path."},
    {"id": "CVE-2021-41773", "prod": "Apache HTTPD", "sev": "CRIT",
     "cat": "TRAVERSAL", "alias": ["apache httpd", "apache/", "httpd",
                                    "apache2"],
     "versions": ["2.4.49"], "fix": "2.4.50+",
     "title": "Path traversal + CGI info disclosure",
     "note": "Server-status style traversal of files outside the "
             "document root."},
    {"id": "CVE-2021-42013", "prod": "Apache HTTPD", "sev": "CRIT",
     "cat": "RCE", "alias": ["apache httpd", "apache/", "httpd",
                             "apache2"],
     "versions": ["2.4.49", "2.4.50"], "fix": "2.4.51+",
     "title": "Path traversal RCE (41773 bypass)",
     "note": "Double-encoding bypass of the 2.4.50 fix."},
    {"id": "CVE-2019-0211", "prod": "Apache HTTPD", "sev": "HIGH",
     "cat": "LPE", "alias": ["apache httpd", "apache/", "httpd",
                              "apache2"],
     "vmin": "2.4.17", "vmax": "2.4.38", "fix": "2.4.39+",
     "title": "Local privilege escalation (mod_log_config)",
     "note": "Apache worker processes can read arbitrary files as "
             "root."},
    {"id": "CVE-2014-6271", "prod": "GNU Bash", "sev": "CRIT",
     "cat": "RCE", "alias": ["bash", "gnu bash"],
     "vmin": "0", "vmax": "4.3", "fix": "patched 4.3.30+ builds",
     "title": "Shellshock -- function env injection",
     "note": "CGI/SSH-driven env injection; every exposed CGI shell "
             "is code."},
    {"id": "CVE-2012-1823", "prod": "PHP CGI", "sev": "CRIT",
     "cat": "RCE", "alias": ["php"], "vmin": "5.0", "vmax": "5.4.2",
     "fix": "5.4.3 / 5.3.13+",
     "title": "PHP CGI argument injection",
     "note": "Query string passed as php options (-d allow_url_include "
             "...)."},
    {"id": "CVE-2019-11043", "prod": "PHP-FPM", "sev": "HIGH",
     "cat": "RCE", "alias": ["php-fpm", "php"], "vmin": "7.1.0",
     "vmax": "7.3.10", "fix": "7.3.11+",
     "title": "nginx + php-fpm RCE via env manipulation",
     "note": "Exploitable with specific fastcgi configs; verify "
             "fastcgi_split_path_info."},
    {"id": "CVE-2017-0144", "prod": "Windows SMBv1", "sev": "CRIT",
     "cat": "RCE", "alias": ["smb", "microsoft windows smb",
                             "windows 7", "server 2008"],
     "any": True, "fix": "MS17-010 / disable SMBv1",
     "title": "EternalBlue -- SMBv1 pre-auth RCE",
     "note": "WannaCry/NotPetya vector. If SMBv1 is enabled on any "
             "unpatched host, treat as critical."},
    {"id": "CVE-2019-0708", "prod": "RDP", "sev": "CRIT", "cat": "RCE",
     "alias": ["rdp", "remote desktop", "terminal service"],
     "any": True, "fix": "Sept 2019 patch / NLA",
     "title": "BlueKeep -- pre-auth RDP RCE",
     "note": "Older Windows 7 / 2008 R2 without NLA."},
    {"id": "CVE-2016-5195", "prod": "Linux Kernel", "sev": "HIGH",
     "cat": "LPE", "alias": ["linux kernel", "linux"],
     "vmin": "2.6.22", "vmax": "4.8.3", "fix": "4.8.3+ (backports)",
     "title": "Dirty COW -- race condition LPE",
     "note": "Overwrite read-only mappings, own the box."},
    {"id": "CVE-2022-0847", "prod": "Linux Kernel", "sev": "HIGH",
     "cat": "LPE", "alias": ["linux kernel", "linux"],
     "vmin": "5.8", "vmax": "5.16.10", "fix": "5.16.11+",
     "title": "Dirty Pipe -- pipe buffer LPE",
     "note": "Overwrite page-cache-backed read-only files (crontab, "
             "/etc/passwd)."},
    {"id": "CVE-2021-3156", "prod": "sudo", "sev": "HIGH", "cat": "LPE",
     "alias": ["sudo"], "vmin": "1.8.2", "vmax": "1.9.5p1",
     "fix": "1.9.5p2+",
     "title": "Baron Samedit -- heap overflow LPE",
     "note": "Environment variable backslash handling in "
             "sudoedit."},
    {"id": "CVE-2018-15473", "prod": "OpenSSH", "sev": "MED",
     "cat": "ENUM", "alias": ["openssh", "ssh-2.0-openssh"],
     "vmin": "0", "vmax": "7.7", "fix": "7.8+",
     "title": "User enumeration via malformed public key",
     "note": "Timings leak whether an account exists."},
    {"id": "CVE-2023-38408", "prod": "OpenSSH", "sev": "HIGH",
     "cat": "RCE", "alias": ["openssh", "ssh-2.0-openssh"],
     "vmin": "9.2p1", "vmax": "9.3p1", "fix": "9.3p2+",
     "title": "ssh-agent forwarded agent RCE",
     "note": "Only with agent forwarding; verify advisory for your "
             "build."},
    {"id": "CVE-2020-1938", "prod": "Apache Tomcat", "sev": "CRIT",
     "cat": "RCE", "alias": ["tomcat", "apache tomcat"],
     "vmin": "7.0.0", "vmax": "9.0.30",
     "fix": "9.0.31 / 8.5.51 / 7.0.100+",
     "title": "Ghostcat -- AJP LFI/RCE",
     "note": "AJP port 8009 exposed + default apps lead to file read "
             "and often RCE."},
    {"id": "CVE-2017-12615", "prod": "Apache Tomcat", "sev": "HIGH",
     "cat": "RCE", "alias": ["tomcat", "apache tomcat"],
     "vmin": "7.0.0", "vmax": "7.0.79", "fix": "7.0.81+",
     "title": "PUT method JSP upload (Windows)",
     "note": "readonly=false + Windows: upload a JSP webshell."},
    {"id": "CVE-2017-7529", "prod": "nginx", "sev": "MED", "cat": "INFO",
     "alias": ["nginx"], "vmin": "1.9.11", "vmax": "1.13.2",
     "fix": "1.13.3+",
     "title": "Range filter integer overflow",
     "note": "Info leak of upstream response tails."},
    {"id": "CVE-2021-43798", "prod": "Grafana", "sev": "HIGH",
     "cat": "TRAVERSAL", "alias": ["grafana"], "vmin": "8.0.0",
     "vmax": "8.3.0", "fix": "8.3.1+",
     "title": "Unauthenticated plugin path traversal",
     "note": "Read arbitrary files via /plugins/..%2f."},
    {"id": "CVE-2022-26134", "prod": "Atlassian Confluence",
     "sev": "CRIT", "cat": "RCE", "alias": ["confluence"], "any": True,
     "fix": "vendor advisory (June 2022)",
     "title": "OGNL injection in URI",
     "note": "Version depends on branch; apply the vendor advisory "
             "release for your line."},
    {"id": "CVE-2020-14882", "prod": "Oracle WebLogic", "sev": "CRIT",
     "cat": "AUTH", "alias": ["weblogic", "oracle weblogic"],
     "any": True, "fix": "Oct 2020 CPU",
     "title": "Console auth bypass -> RCE",
     "note": "Path traversal + handle exploit pre-auth."},
    {"id": "CVE-2021-26855", "prod": "Microsoft Exchange", "sev": "CRIT",
     "cat": "RCE", "alias": ["microsoft exchange", "owa", "exchange"],
     "any": True, "fix": "Mar 2021 exchange CU + mitigations",
     "title": "ProxyLogon SSRF -> RCE chain",
     "note": "HAFNIUM campaign vector."},
    {"id": "CVE-2020-1472", "prod": "Netlogon (AD DC)", "sev": "CRIT",
     "cat": "AUTH", "alias": ["netlogon", "domain controller"],
     "any": True, "fix": "Aug 2020 patch + enforcement",
     "title": "ZeroLogon domain takeover",
     "note": "Set DC machine account password to blank -> DCSync."},
    {"id": "CVE-2021-34527", "prod": "Windows Print Spooler", "sev": "HIGH",
     "cat": "LPE", "alias": ["spooler", "print spooler"], "any": True,
     "fix": "June 2021 patch / disable spooler",
     "title": "PrintNightmare spooler RCE/LPE",
     "note": "Remote driver install to SYSTEM."},
    {"id": "CVE-2017-7269", "prod": "IIS 6.0", "sev": "HIGH",
     "cat": "RCE", "alias": ["iis", "microsoft-iis"],
     "versions": ["6.0"], "fix": "2003-only: upgrade platform",
     "title": "WebDAV PROPFIND buffer overflow",
     "note": "Ancient but still found on legacy OT networks."},
    {"id": "CVE-2022-42889", "prod": "Apache Commons Text", "sev": "HIGH",
     "cat": "RCE", "alias": ["commons-text", "commons text"],
     "vmin": "1.0", "vmax": "1.9", "fix": "1.10.0+",
     "title": "Text4Shell -- interpolation RCE",
     "note": "Needs script-string interpolation of user input; context "
             "matters."},
    # ---- configuration-level hardening items ------------------
    {"id": "HARDEN-REDIS", "prod": "Redis", "sev": "HIGH", "cat": "CONFIG",
     "alias": ["redis"], "any": True, "fix": "bind 127.0.0.1 + AUTH",
     "title": "Redis visible without authentication",
     "note": "No AUTH banner -> config rewrite attacks (SSH key / "
             "cron injection)."},
    {"id": "HARDEN-MONGO", "prod": "MongoDB", "sev": "HIGH",
     "cat": "CONFIG", "alias": ["mongodb", "mongod"], "any": True,
     "fix": "enable auth + bind localhost",
     "title": "MongoDB appears unauthenticated",
     "note": "Default installs historically exposed every collection."},
    {"id": "HARDEN-ES", "prod": "Elasticsearch", "sev": "HIGH",
     "cat": "CONFIG", "alias": ["elasticsearch", "elastic"], "any": True,
     "fix": "enable security + TLS",
     "title": "Elasticsearch REST API open",
     "note": "9200 open without auth exposes every indexed document."},
    {"id": "HARDEN-TELNET", "prod": "Telnet", "sev": "MED", "cat": "CONFIG",
     "alias": ["telnet"], "any": True, "fix": "replace with SSH",
     "title": "Telnet -- cleartext protocol",
     "note": "Credentials and sessions travel unencrypted."},
    {"id": "HARDEN-FTP", "prod": "FTP", "sev": "MED", "cat": "CONFIG",
     "alias": ["ftp", "vsftpd", "proftpd", "filezilla"], "any": True,
     "fix": "SFTP / FTPS only",
     "title": "FTP service detected",
     "note": "Cleartext + anonymous login worth checking."},
]

_SEV_RANK = {"CRIT": 0, "HIGH": 1, "MED": 2, "LOW": 3}


def _verkey(v):
    nums = _re.findall(r"\d+", str(v))
    return tuple(int(x) for x in nums[:6]) if nums else (0,)


def _in_range(vk, e):
    if "versions" in e:
        return any(vk == _verkey(v) for v in e["versions"])
    lo = _verkey(e.get("vmin", "0"))
    hi = _verkey(e.get("vmax", "999"))
    if e.get("vmin") is None and e.get("vmax") is None:
        return True
    return lo <= vk <= hi


def vuln_match(banner):
    """-> list of {id, prod, sev, cat, title, note, fix, version}"""
    text = str(banner)
    low = text.lower()
    hits = []
    for e in VULN_DB:
        matched_alias = None
        for a in e["alias"]:
            idx = low.find(a)
            if idx < 0:
                continue
            matched_alias = (a, idx)
            break
        if not matched_alias:
            continue
        a, idx = matched_alias
        if e.get("any"):
            hits.append(dict(e, version="n/a"))
            continue
        window = low[idx + len(a): idx + len(a) + 26]
        m = _V_RE.search(window)
        if not m:
            continue
        version = m.group(0)
        if _in_range(_verkey(version), e):
            hits.append(dict(e, version=version))
    hits.sort(key=lambda h: _SEV_RANK.get(h["sev"], 9))
    return hits


def vuln_by_product(product, version):
    """Manual mode: 'openssh 7.4' -> same hit list."""
    text = product.strip().lower() + " " + version.strip()
    return vuln_match(text)


class VulnPage(BasePage):

    TITLE = "VULN MATCHER"
    SUB = "BANNER -> CURATED OFFLINE CVE MINI-DB"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="BANNER", bg=THEME["panel"],
                 fg=THEME["accent"],
                 font=(self.app.f_mono, 9, "bold")).pack(anchor="w")
        self.banner_t = tk.Text(inner, bg=THEME["panel2"],
                               fg=THEME["text"],
                               insertbackground=THEME["accent"],
                               font=(self.app.f_mono, 9), height=4,
                               relief="flat", highlightthickness=1,
                               highlightbackground=THEME["accent_dim"],
                               highlightcolor=THEME["accent"], wrap="char")
        self.banner_t.pack(fill="x")
        self.banner_t.insert("1.0",
                             "Server: Apache/2.4.49 (Unix)\r\n"
                             "X-Powered-By: PHP/7.1.8")
        row = tk.Frame(inner, bg=THEME["panel"])
        row.pack(fill="x", pady=(6, 0))
        NeonButton(row, "MATCH BANNER", width=130, height=32,
                   font=(self.app.f_mono, 9, "bold"),
                   command=self.match_banner).pack(side="left")
        tk.Label(row, text="OR PRODUCT+VERSION:", bg=THEME["panel"],
                 fg=THEME["dim"], font=(self.app.f_mono, 8,
                 "bold")).pack(side="left", padx=(14, 6))
        self.prod_e = self.entry(row, width=16, placeholder="openssh")
        self.prod_e.pack(side="left", padx=2)
        self.ver_e = self.entry(row, width=10, placeholder="7.4")
        self.ver_e.pack(side="left", padx=2)
        NeonButton(row, "MATCH", width=90, height=32,
                   font=(self.app.f_mono, 9, "bold"),
                   command=self.match_product).pack(side="left", padx=2)

        box = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        box.pack(fill="both", expand=True, padx=14)
        tk.Label(box, text="MATCHES (curated mini-DB -- verify on the "
                           "official advisory before acting)",
                 bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.app.f_mono, 7)).pack(anchor="w", padx=12,
                                                 pady=(10, 2))
        wrap = tk.Frame(box, bg=THEME["panel"])
        wrap.pack(fill="both", expand=True, padx=12, pady=(2, 4))
        cols = ("cve", "sev", "product", "version", "fixed", "title")
        self.tree = ttk.Treeview(wrap, columns=cols, show="headings",
                                 height=8)
        for cid, w in (("cve", 150), ("sev", 60), ("product", 130),
                       ("version", 70), ("fixed", 130), ("title", 250)):
            self.tree.heading(cid, text=cid.upper())
            self.tree.column(cid, width=w, anchor="w")
        vsb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(side="left", fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._pick)
        self._hits = []
        self.detail = tk.Text(box, bg=THEME["panel2"], fg=THEME["text"],
                              font=(self.app.f_mono, 8), height=6, bd=0,
                              highlightthickness=1,
                              highlightbackground=THEME["accent_dim"],
                              wrap="word")
        self.detail.pack(fill="x", padx=12, pady=(2, 12))

    def _pick(self, _e=None):
        sel = self.tree.selection()
        if not sel:
            return
        h = self._hits[self.tree.index(sel[0])]
        self.detail.delete("1.0", "end")
        self.detail.insert("1.0", "{}  [{}]  {}\nAFFECTED: {}   FIXED: "
                             "{}\n{}\nADVISORY: {}{}".format(
                                 h["id"], h["sev"], h["title"],
                                 h.get("version", "n/a"), h.get("fix", "-"),
                                 h["note"],
                                 _NVD, h["id"] if h["id"].startswith("CVE")
                                 else ""))

    def match_banner(self):
        banner = self.banner_t.get("1.0", "end").strip()
        if not banner:
            self.status("PASTE A BANNER", THEME["warn"])
            return
        self._show(vuln_match(banner), banner[:80])

    def match_product(self):
        prod = self.prod_e.get().strip()
        ver = self.ver_e.get().strip()
        if not prod:
            self.status("ENTER A PRODUCT", THEME["warn"])
            return
        self._show(vuln_by_product(prod, ver or "0"), prod + " " + ver)

    def _show(self, hits, target):
        self._hits = hits
        for w in self.tree.get_children():
            self.tree.delete(w)
        sev_col = {"CRIT": THEME["bad"], "HIGH": THEME["bad"],
                   "MED": THEME["warn"], "LOW": THEME["dim"]}
        for h in hits:
            self.tree.insert("", "end", values=(
                h["id"], h["sev"], h["prod"], h.get("version", "n/a"),
                h.get("fix", "-"), h["title"]), tags=(h["sev"],))
            self.tree.tag_configure(h["sev"],
                                    foreground=sev_col.get(h["sev"],
                                                           THEME["text"]))
        crit = sum(1 for h in hits if h["sev"] == "CRIT")
        self.detail.delete("1.0", "end")
        if not hits:
            self.status("NO MATCHES IN OFFLINE DB", THEME["ok"])
            self.detail.insert("1.0", "No match in the curated mini-DB. "
                             "That does not mean the version is safe -- "
                             "check the vendor advisory directly.")
        else:
            self.status("{} MATCHES ({} CRIT)".format(len(hits), crit),
                        THEME["bad"] if crit else THEME["warn"])
            self.app.store.log("VULN", "match", target,
                               "{} matches".format(len(hits)))


# ============================================================
#  TOOL 18 -- STEGA HIDE  (PNG LSB steganography)
# ============================================================
#  Hides an encrypted message inside a PNG image by writing
#  the payload into the least-significant bits of the pixel
#  channels. Pure stdlib PNG codec (chunk parsing + full scan
#  line unfiltering incl. Paeth).
# ============================================================

_PNG_SIG = b"\x89PNG\r\n\x1a\n"
_STEGA_MAGIC = b"NXST1"


def png_read(data):
    """-> {w, h, channels, rows[list of bytes]} ; ValueError otherwise."""
    if not data.startswith(_PNG_SIG):
        raise ValueError("not a PNG file")
    off, w, h, depth, ctype, interlace = 8, 0, 0, 0, 0, 0
    idat = bytearray()
    while off < len(data):
        if off + 8 > len(data):
            raise ValueError("truncated PNG chunk header")
        ln = struct.unpack(">I", data[off:off + 4])[0]
        ctype_name = data[off + 4:off + 8]
        body = data[off + 8:off + 8 + ln]
        if len(body) != ln:
            raise ValueError("truncated PNG chunk")
        if zlib.crc32(ctype_name + body) & 0xFFFFFFFF != struct.unpack(
                ">I", data[off + 8 + ln:off + 12 + ln])[0]:
            raise ValueError("PNG chunk CRC failed")
        if ctype_name == b"IHDR":
            w, h, depth, ctype, _comp, _filt, interlace = struct.unpack(
                ">IIBBBBB", body)
        elif ctype_name == b"IDAT":
            idat += body
        off += 12 + ln
    if not w or not h or not idat:
        raise ValueError("missing IHDR/IDAT")
    if depth != 8 or ctype not in (2, 6):
        raise ValueError("only 8-bit RGB / RGBA PNG images are supported")
    if interlace:
        raise ValueError("interlaced PNG is not supported")
    channels = 3 if ctype == 2 else 4
    raw = zlib.decompress(bytes(idat))
    stride = w * channels
    if len(raw) < (stride + 1) * h:
        raise ValueError("corrupt PNG pixel data")
    rows, pos = [], 0
    prev = bytes(stride)
    for _ in range(h):
        ftype = raw[pos]
        pos += 1
        line = bytearray(raw[pos:pos + stride])
        pos += stride
        if ftype == 0:
            pass
        elif ftype == 1:                     # Sub
            for i in range(channels, stride):
                line[i] = (line[i] + line[i - channels]) & 0xFF
        elif ftype == 2:                     # Up
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 0xFF
        elif ftype == 3:                     # Average
            for i in range(stride):
                left = line[i - channels] if i >= channels else 0
                line[i] = (line[i] + ((left + prev[i]) >> 1)) & 0xFF
        elif ftype == 4:                     # Paeth
            for i in range(stride):
                a = line[i - channels] if i >= channels else 0
                b = prev[i]
                c = prev[i - channels] if i >= channels else 0
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                pr = a if (pa <= pb and pa <= pc) else (
                    b if pb <= pc else c)
                line[i] = (line[i] + pr) & 0xFF
        else:
            raise ValueError("bad PNG filter type")
        rows.append(bytes(line))
        prev = line
    return {"w": w, "h": h, "channels": channels, "rows": rows}


def png_write(w, h, channels, rows):
    """rows (list of len w*channels bytes) -> PNG file bytes."""
    out = bytearray(_PNG_SIG)
    ihdr = struct.pack(">IIBBBBB", w, h, 8,
                       2 if channels == 3 else 6, 0, 0, 0)

    def chunk(name, body):
        out = struct.pack(">I", len(body)) + name + body
        return out + struct.pack(">I", zlib.crc32(name + body) & 0xFFFFFFFF)

    out += chunk(b"IHDR", ihdr)
    raw = bytearray()
    for r in rows:
        raw.append(0)                       # filter type 0
        raw += r
    out += chunk(b"IDAT", zlib.compress(bytes(raw), 9))
    out += chunk(b"IEND", b"")
    return bytes(out)


def _bits(data):
    for byte in data:
        for shift in range(7, -1, -1):
            yield (byte >> shift) & 1


def _take_bits(rows, channels, count):
    """LSB channel bits in scan order -> list of bits."""
    out = []
    for row in rows:
        for i in range(0, len(row)):
            out.append(row[i] & 1)
            if len(out) >= count:
                return out
    return out


def _pack_bits(bits):
    out = bytearray()
    for i in range(0, len(bits) - 7, 8):
        v = 0
        for b in bits[i:i + 8]:
            v = (v << 1) | b
        out.append(v)
    return bytes(out)


def stega_embed(png_data, message, passphrase):
    """Hide encrypted message in an image. -> new PNG bytes."""
    img = png_read(png_data)
    w, h, ch, rows = img["w"], img["h"], img["channels"], img["rows"]
    payload = message if isinstance(message, bytes) else \
        message.encode("utf-8")
    key = hashlib.sha256((passphrase or "xxnetro").encode("utf-8") +
                         b"|stega").digest()
    enc = bytes(a ^ b for a, b in zip(payload, xor_keystream(key,
                                                            len(payload))))
    token = _STEGA_MAGIC + struct.pack(">I", len(enc)) + enc + \
        struct.pack(">I", zlib.crc32(payload) & 0xFFFFFFFF)
    capacity = (w * h * ch) // 8
    if len(token) > capacity:
        raise ValueError("message too large for this image "
                         "(capacity {} bytes)".format(capacity))
    rows = [bytearray(r) for r in rows]
    idx = 0
    for bit in _bits(token):
        row, col = idx // len(rows[0]), idx % len(rows[0])
        rows[row][col] = (rows[row][col] & 0xFE) | bit
        idx += 1
    return png_write(w, h, ch, [bytes(r) for r in rows])


def stega_extract(png_data, passphrase):
    """-> hidden bytes. Raises when no payload present."""
    img = png_read(png_data)
    ch, rows = img["channels"], img["rows"]
    stride = len(rows[0])
    total_bits = stride * len(rows)
    # header: 5 magic + 4 len  -> 72 bits
    head = _pack_bits(_take_bits(rows, ch, 72))
    if head[:5] != _STEGA_MAGIC:
        raise ValueError("no hidden payload in this image")
    (ln,) = struct.unpack(">I", head[5:9])
    if ln > (total_bits // 8) - 13:
        raise ValueError("corrupt payload header")
    need = (9 + ln + 4) * 8
    token = _pack_bits(_take_bits(rows, ch, need))
    enc, crc = token[9:9 + ln], token[9 + ln:13 + ln]
    key = hashlib.sha256((passphrase or "xxnetro").encode("utf-8") +
                         b"|stega").digest()
    ks = xor_keystream(key, len(enc))
    dec = bytes(a ^ b for a, b in zip(enc, ks))
    if zlib.crc32(dec) & 0xFFFFFFFF != struct.unpack(">I", crc)[0]:
        raise ValueError("payload CRC failed (wrong passphrase or "
                          "modified image)")
    return dec


class StegPage(BasePage):

    TITLE = "STEGA HIDE"
    SUB = "PNG LSB STEGANOGRAPHY"

    def build(self):
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        self.path_lbl = tk.Label(inner, text="no image selected",
                                bg=THEME["panel"], fg=THEME["dim"],
                                font=(self.app.f_mono, 8), anchor="w")
        self.path_lbl.pack(side="left", fill="x", expand=True)
        NeonButton(inner, "PICK PNG", width=110, height=32,
                   font=(self.app.f_mono, 9, "bold"),
                   command=self.pick).pack(side="left", padx=4)
        self.path = None

        body = tk.Frame(self, bg=THEME["bg"])
        body.pack(fill="both", expand=True, padx=14)
        left = tk.Frame(body, bg=THEME["panel"], highlightthickness=1,
                        highlightbackground=THEME["accent_dim"])
        left.pack(side="left", fill="both", expand=True, padx=(0, 6))
        lb = tk.Frame(left, bg=THEME["panel"])
        lb.pack(fill="both", expand=True, padx=12, pady=12)
        tk.Label(lb, text="SECRET MESSAGE", bg=THEME["panel"],
                 fg=THEME["glow"], font=(self.app.f_mono, 9,
                 "bold")).pack(anchor="w")
        self.msg_t = tk.Text(lb, bg=THEME["panel2"], fg=THEME["text"],
                             insertbackground=THEME["accent"],
                             font=(self.app.f_mono, 10), height=8, bd=0,
                             highlightthickness=1,
                             highlightbackground=THEME["accent_dim"],
                             wrap="word")
        self.msg_t.pack(fill="both", expand=True, pady=(4, 8))
        row = tk.Frame(lb, bg=THEME["panel"])
        row.pack(fill="x")
        tk.Label(row, text="PASSPHRASE", bg=THEME["panel"],
                 fg=THEME["accent"], font=(self.app.f_mono, 8,
                 "bold")).pack(side="left")
        self.pass_e = self.entry(row, width=22, placeholder="stega key")
        self.pass_e.pack(side="left", padx=(8, 10))
        self.pass_e.config(show="*")

        right = tk.Frame(body, bg=THEME["panel"], highlightthickness=1,
                         highlightbackground=THEME["accent_dim"])
        right.pack(side="left", fill="both", expand=True, padx=(6, 0))
        rb = tk.Frame(right, bg=THEME["panel"])
        rb.pack(fill="both", expand=True, padx=12, pady=12)
        self.act_lbl = tk.Label(rb, text="OPERATION", bg=THEME["panel"],
                               fg=THEME["glow"],
                               font=(self.app.f_mono, 9, "bold"))
        self.act_lbl.pack(anchor="w")
        self.out_t = tk.Text(rb, bg=THEME["panel2"], fg=THEME["ok"],
                             font=(self.app.f_mono, 10), height=8, bd=0,
                             state="disabled", highlightthickness=1,
                             highlightbackground=THEME["accent_dim"],
                             wrap="word")
        self.out_t.pack(fill="both", expand=True, pady=(4, 8))
        row2 = tk.Frame(rb, bg=THEME["panel"])
        row2.pack(fill="x")
        NeonButton(row2, "HIDE + SAVE", width=120, height=34,
                   font=(self.app.f_mono, 9, "bold"),
                   command=self.hide).pack(side="left", padx=(0, 6))
        NeonButton(row2, "EXTRACT", width=100, height=34,
                   font=(self.app.f_mono, 9, "bold"),
                   command=self.extract).pack(side="left")
        tk.Label(right, text="output image keeps the original pixel size;"
                            " only LSBs change",
                 bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.app.f_mono, 7)).pack(anchor="w", padx=12,
                                                 pady=(0, 10))

    def _set_out(self, text, color=THEME["ok"]):
        self.out_t.config(state="normal", fg=color)
        self.out_t.delete("1.0", "end")
        self.out_t.insert("1.0", text)
        self.out_t.config(state="disabled")

    def pick(self):
        path = filedialog.askopenfilename(
            title="SELECT PNG CARRIER",
            filetypes=[("PNG images", "*.png"), ("All files", "*.*")])
        if not path:
            return
        try:
            with open(path, "rb") as f:
                png_read(f.read())
        except Exception as e:
            messagebox.showerror("STEGA HIDE", str(e))
            return
        self.path = path
        self.path_lbl.config(text=os.path.basename(path) +
                            "   [carrier loaded]", fg=THEME["glow"])
        self._set_out("carrier ready", THEME["dim"])

    def _load_carrier(self):
        if not self.path:
            messagebox.showwarning("STEGA HIDE", "pick a PNG first")
            return None
        with open(self.path, "rb") as f:
            return f.read()

    def hide(self):
        raw = self._load_carrier()
        if raw is None:
            return
        msg = self.msg_t.get("1.0", "end").rstrip("\n")
        if not msg:
            self.status("EMPTY MESSAGE", THEME["warn"])
            return
        dst = filedialog.asksaveasfilename(
            title="SAVE STEGO IMAGE", defaultextension=".png",
            filetypes=[("PNG images", "*.png")])
        if not dst:
            return

        def work():
            out = stega_embed(raw, msg, self.pass_e.get())
            with open(dst, "wb") as f:
                f.write(out)
            return len(out)

        def done(n):
            self.status("HIDDEN -> " + os.path.basename(dst), THEME["ok"])
            self._set_out("payload hidden in {} ({} bytes out)\n"
                          "share the PNG, never the passphrase.".format(
                              os.path.basename(dst), n))
            self.app.store.log("STEGA", "embed", os.path.basename(dst),
                               "{} chars hidden".format(len(msg)))

        self.run(work, done, busy="EMBEDDING PAYLOAD")

    def extract(self):
        raw = self._load_carrier()
        if raw is None:
            return

        def work():
            return stega_extract(raw, self.pass_e.get()).decode(
                "utf-8", "replace")

        def done(text):
            self.status("PAYLOAD EXTRACTED", THEME["ok"])
            self._set_out(text)
            self.app.store.log("STEGA", "extract", os.path.basename(
                self.path or "?"), "{} chars read".format(len(text)))

        def fail(e):
            self.status("EXTRACTION FAILED", THEME["bad"])
            self._set_out(str(e), THEME["bad"])

        self.run(work, done, on_error=fail, busy="EXTRACTING PAYLOAD")


# ============================================================
#  TOOL 15 -- SECURE COMMS  (encrypted communication line)
# ============================================================
#  Three layers of link protection:
#   * MESSENGER  -- live AES-256-CBC + HMAC channel over TCP
#                   (host mode or client mode, shared passphrase)
#   * CIPHER PAD -- seal any text into a paste-safe token for
#                   any messenger / email / sms
#   * FILE VAULT -- seal whole files into .nxsec containers
#  Pure stdlib crypto core (see CRYPTO CORE section above).
# ============================================================

_HS_MAGIC = b"NXH1"
_MSG_MAGIC = b"NXM1"


def _recv_exact(sock, n):
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise ConnectionError("peer closed the channel")
        buf += chunk
    return bytes(buf)


class _Link:
    """One encrypted session (used by both host and client side)."""

    def __init__(self, sock, passphrase, is_server):
        self.sock = sock
        self.passphrase = (passphrase or "xxnetro").strip()
        self.is_server = is_server
        self.alive = True
        self._lock = threading.Lock()
        self._keys = None

    def handshake(self):
        """Exchange the salt, derive session keys."""
        if self.is_server:
            salt = secrets.token_bytes(16)
            self.sock.sendall(_HS_MAGIC + salt)
        else:
            head = _recv_exact(self.sock, 4 + 16)
            if head[:4] != _HS_MAGIC:
                raise ValueError("peer is not an XXNETRO secure link")
            salt = head[4:20]
        # PBKDF2 twice (enc + mac) -- cost is paid once per session
        self._keys = (
            derive_key(self.passphrase, salt, 32, _NXSEC_ITERS),
            derive_key(self.passphrase, salt + b"|mac", 32, _NXSEC_ITERS),
        )
        if self.is_server:
            _recv_exact(self.sock, 0)      # no-op guard
        return True

    def send(self, text):
        if not self._keys:
            raise ValueError("link not established")
        data = text.encode("utf-8")
        iv = secrets.token_bytes(16)
        cipher = AES256(self._keys[0])
        ct = cipher.cbc_encrypt_raw(pkcs7_pad(data), iv)
        mac = _hmac.new(self._keys[1], iv + ct, hashlib.sha256).digest()
        frame = _MSG_MAGIC + struct.pack(">I", len(iv) + len(ct) +
                                        len(mac)) + iv + ct + mac
        with self._lock:
            self.sock.sendall(frame)

    def recv(self):
        head = _recv_exact(self.sock, 4 + 4)
        if head[:4] != _MSG_MAGIC:
            raise ValueError("protocol error on channel")
        (ln,) = struct.unpack(">I", head[4:8])
        body = _recv_exact(self.sock, ln)
        iv, ct, mac = body[:16], body[16:-32], body[-32:]
        calc = _hmac.new(self._keys[1], iv + ct, hashlib.sha256).digest()
        if not _hmac.compare_digest(calc, mac):
            raise ValueError("integrity check failed on channel")
        cipher = AES256(self._keys[0])
        return pkcs7_unpad(cipher.cbc_decrypt_raw(ct, iv)).decode(
            "utf-8", "replace")

    def close(self):
        self.alive = False
        try:
            self.sock.close()
        except Exception:
            pass


class CommsPage(BasePage):

    TITLE = "SECURE COMMS"
    SUB = "AES-256-CBC + HMAC ENCRYPTED LINK"

    def build(self):
        tabs = tk.Frame(self, bg=THEME["bg"])
        tabs.pack(fill="x", padx=14, pady=(0, 6))
        self._tab_buttons = {}
        for key, label in (("msg", "MESSENGER"), ("pad", "CIPHER PAD"),
                           ("vault", "FILE VAULT")):
            b = NeonButton(tabs, label, width=140, height=30,
                           font=(self.app.f_mono, 9, "bold"),
                           command=lambda k=key: self._tab(k))
            b.pack(side="left", padx=2)
            self._tab_buttons[key] = b
        self.frames = {}
        for key in ("msg", "pad", "vault"):
            f = tk.Frame(self, bg=THEME["bg"])
            self.frames[key] = f
        self._build_messenger(self.frames["msg"])
        self._build_pad(self.frames["pad"])
        self._build_vault(self.frames["vault"])
        self._tab("msg")
        self._set_role("HOST")          # after entries exist
        self.qlink = queue.Queue()
        self.after(60, self._drain)
        self.link = None

    # ---- tab plumbing --------------------------------------
    def _tab(self, key):
        for k, f in self.frames.items():
            f.pack_forget()
        self.frames[key].pack(fill="both", expand=True, padx=14,
                              pady=(2, 0))
        for k, b in self._tab_buttons.items():
            b.itemconfig(b._poly,
                         outline=THEME["accent"] if k == key
                         else THEME["dim"],
                         width=2 if k == key else 1)

    # ==== MESSENGER ==========================================
    def _build_messenger(self, parent):
        bar = tk.Frame(parent, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        self.role_buttons = {}
        for role, lbl in (("HOST", "HOST"), ("CLIENT", "CLIENT")):
            b = NeonButton(inner, lbl, width=90, height=28,
                           font=(self.app.f_mono, 8, "bold"),
                           command=lambda r=role: self._set_role(r))
            b.pack(side="left", padx=(0, 4))
            self.role_buttons[role] = b
        tk.Label(inner, text="ADDRESS", bg=THEME["panel"],
                 fg=THEME["accent"],
                 font=(self.app.f_mono, 8, "bold")).pack(
            side="left", padx=(10, 4))
        self.com_host_e = self.entry(inner, width=16, placeholder="0.0.0.0")
        self.com_host_e.pack(side="left", padx=(0, 6))
        tk.Label(inner, text="PORT", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 8, "bold")).pack(side="left",
                                                         padx=(0, 4))
        self.com_port_e = self.entry(inner, width=7, placeholder="7777")
        self.com_port_e.pack(side="left", padx=(0, 6))
        self.com_port_e.delete(0, "end")
        self.com_port_e.insert(0, "7777")
        tk.Label(inner, text="PASS", bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 8, "bold")).pack(side="left",
                                                        padx=(0, 4))
        self.com_pass_e = self.entry(inner, width=16, placeholder="link key")
        self.com_pass_e.pack(side="left", padx=(0, 8))
        self.com_pass_e.config(show="*")
        self.com_link_btn = NeonButton(inner, "OPEN LINK", width=100,
                                       height=28,
                                       font=(self.app.f_mono, 8, "bold"),
                                       command=self._toggle_link)
        self.com_link_btn.pack(side="left", padx=2)

        chatbox = tk.Frame(parent, bg=THEME["panel"], highlightthickness=1,
                           highlightbackground=THEME["accent_dim"])
        chatbox.pack(fill="both", expand=True)
        tk.Label(chatbox, text="CHANNEL", bg=THEME["panel"],
                 fg=THEME["glow"], font=(self.app.f_mono, 9, "bold")).pack(
            anchor="w", padx=12, pady=(10, 2))
        wrap = tk.Frame(chatbox, bg=THEME["panel"])
        wrap.pack(fill="both", expand=True, padx=12, pady=(2, 4))
        self.chat_t = tk.Text(wrap, bg=THEME["panel2"],
                              fg=THEME["text"],
                              font=(self.app.f_mono, 10), height=12, bd=0,
                              highlightthickness=1,
                              highlightbackground=THEME["accent_dim"],
                              state="disabled", wrap="word")
        vsb = ttk.Scrollbar(wrap, orient="vertical",
                            command=self.chat_t.yview)
        self.chat_t.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.chat_t.pack(side="left", fill="both", expand=True)
        for tag, col in (("sys", THEME["dim"]), ("err", THEME["bad"]),
                         ("me", THEME["glow"]), ("peer", THEME["accent"])):
            self.chat_t.tag_configure(tag, foreground=col)
        row = tk.Frame(chatbox, bg=THEME["panel"])
        row.pack(fill="x", padx=12, pady=(4, 12))
        self.com_input_e = self.entry(row, width=52,
                                     placeholder="encrypted message...")
        self.com_input_e.pack(side="left", padx=(0, 8))
        self.com_input_e.bind("<Return>", lambda e: self._send_text())
        NeonButton(row, "SEND", width=80, height=30,
                   font=(self.app.f_mono, 9, "bold"),
                   command=self._send_text).pack(side="left")

    def _set_role(self, role):
        self.role = role
        for r, b in self.role_buttons.items():
            b.itemconfig(b._poly,
                         outline=THEME["accent"] if r == role
                         else THEME["dim"],
                         width=2 if r == role else 1)
        self.com_host_e.delete(0, "end")
        self.com_host_e.insert(0, "0.0.0.0" if role == "HOST"
                               else "127.0.0.1")

    def _chat(self, tag, text):
        self.chat_t.config(state="normal")
        self.chat_t.insert("end", text + "\n", tag)
        self.chat_t.config(state="disabled")
        self.chat_t.see("end")

    def _toggle_link(self):
        if self.link:
            self._close_link()
            return
        host = self.com_host_e.get().strip() or "0.0.0.0"
        try:
            port = int(self.com_port_e.get() or 7777)
        except ValueError:
            port = 7777
        if not (0 < port < 65536):
            self.status("BAD PORT", THEME["warn"])
            return
        passphrase = self.com_pass_e.get()
        if not passphrase:
            messagebox.showwarning("SECURE COMMS",
                                   "set a link passphrase first")
            return
        self.com_link_btn.itemconfig(self.com_link_btn._txt,
                                     text="CLOSE LINK")
        self._chat("sys", "-- opening encrypted link --")
        if self.role == "HOST":
            threading.Thread(target=self._host_loop,
                             args=(host, port, passphrase),
                             daemon=True).start()
        else:
            threading.Thread(target=self._client_loop,
                            args=(host, port, passphrase),
                             daemon=True).start()

    def _host_loop(self, host, port, passphrase):
        srv = None
        try:
            srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            srv.bind((host, port))
            srv.listen(1)
            self.qlink.put(("sys", "LISTENING ON {}:{} -- waiting for "
                                    "the peer".format(host, port)))
            sock, addr = srv.accept()
            srv.close()
            self.qlink.put(("sys", "PEER {} CONNECTED".format(addr[0])))
            link = _Link(sock, passphrase, True)
            link.handshake()
            link.send("LINK ESTABLISHED // XXNETRO")
            self.link = link
            self._reader(link)
        except Exception as e:
            self.qlink.put(("err", "LINK ERROR: " + str(e)[:80]))
            for s in (srv,) if srv else ():
                try:
                    s.close()
                except Exception:
                    pass

    def _client_loop(self, host, port, passphrase):
        try:
            sock = socket.create_connection((host, port),
                                             timeout=CFG["api_timeout"])
            self.qlink.put(("sys", "CONNECTED TO {}:{}".format(
                host, port)))
            link = _Link(sock, passphrase, False)
            link.handshake()
            link.send("LINK ESTABLISHED // XXNETRO")
            self.link = link
            self._reader(link)
        except Exception as e:
            self.qlink.put(("err", "LINK ERROR: " + str(e)[:80]))

    def _reader(self, link):
        while link.alive:
            try:
                text = link.recv()
            except Exception as e:
                self.qlink.put(("sys", "CHANNEL CLOSED ({})".format(
                    str(e)[:48])))
                self._close_link()
                return
            if text:
                self.qlink.put(("peer", "PEER> " + text))

    def _send_text(self):
        text = self.com_input_e.get().strip()
        self.com_input_e.delete(0, "end")
        if not text:
            return
        if not self.link:
            self._chat("err", "no open link")
            return
        try:
            self.link.send(text)
            self._chat("me", "YOU> " + text)
        except Exception as e:
            self._chat("err", "SEND FAILED: " + str(e)[:60])

    def _close_link(self):
        if self.link:
            try:
                self.link.close()
            finally:
                self.link = None
        self._chat("sys", "-- link closed --")
        try:
            self.com_link_btn.itemconfig(self.com_link_btn._txt,
                                         text="OPEN LINK")
        except Exception:
            pass

    def _drain(self):
        try:
            while True:
                tag, text = self.qlink.get_nowait()
                if tag == "err":
                    self.status("LINK ERROR", THEME["bad"])
                self._chat(tag, text)
        except queue.Empty:
            pass
        self.after(90, self._drain)

    # ==== CIPHER PAD =========================================
    def _build_pad(self, parent):
        body = tk.Frame(parent, bg=THEME["bg"])
        body.pack(fill="both", expand=True)
        left = tk.Frame(body, bg=THEME["panel"], highlightthickness=1,
                        highlightbackground=THEME["accent_dim"])
        left.pack(side="left", fill="both", expand=True, padx=(0, 6))
        lb = tk.Frame(left, bg=THEME["panel"])
        lb.pack(fill="both", expand=True, padx=12, pady=12)
        tk.Label(lb, text="PLAIN MESSAGE", bg=THEME["panel"],
                 fg=THEME["glow"], font=(self.app.f_mono, 9,
                 "bold")).pack(anchor="w")
        self.pad_plain_t = tk.Text(lb, bg=THEME["panel2"],
                                   fg=THEME["text"],
                                   insertbackground=THEME["accent"],
                                   font=(self.app.f_mono, 10), height=9,
                                   bd=0, highlightthickness=1,
                                   highlightbackground=THEME["accent_dim"],
                                   wrap="word")
        self.pad_plain_t.pack(fill="both", expand=True, pady=(4, 8))

        right = tk.Frame(body, bg=THEME["panel"], highlightthickness=1,
                         highlightbackground=THEME["accent_dim"])
        right.pack(side="left", fill="both", expand=True, padx=(6, 0))
        rb = tk.Frame(right, bg=THEME["panel"])
        rb.pack(fill="both", expand=True, padx=12, pady=12)
        tk.Label(rb, text="SEALED TOKEN (BASE64)", bg=THEME["panel"],
                 fg=THEME["glow"], font=(self.app.f_mono, 9,
                 "bold")).pack(anchor="w")
        self.pad_token_t = tk.Text(rb, bg=THEME["panel2"],
                                   fg=THEME["ok"],
                                   insertbackground=THEME["accent"],
                                   font=(self.app.f_mono, 8), height=9,
                                   bd=0, highlightthickness=1,
                                   highlightbackground=THEME["accent_dim"],
                                   wrap="char")
        self.pad_token_t.pack(fill="both", expand=True, pady=(4, 8))

        bar = tk.Frame(parent, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", pady=(8, 0))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        tk.Label(inner, text="PASSPHRASE", bg=THEME["panel"],
                 fg=THEME["accent"], font=(self.app.f_mono, 8,
                 "bold")).pack(side="left")
        self.pad_pass_e = self.entry(inner, width=20,
                                     placeholder="pad key")
        self.pad_pass_e.pack(side="left", padx=(8, 12))
        self.pad_pass_e.config(show="*")
        NeonButton(inner, "SEAL ->", width=110, height=32,
                   font=(self.app.f_mono, 9, "bold"),
                   command=self._pad_seal).pack(side="left", padx=2)
        NeonButton(inner, "<- OPEN", width=110, height=32,
                   font=(self.app.f_mono, 9, "bold"),
                   command=self._pad_open).pack(side="left", padx=2)
        tk.Label(bar, text="share the token over any messenger; only "
                           "the passphrase holder can open it",
                 bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.app.f_mono, 7)).pack(anchor="w", padx=12,
                                                 pady=(0, 8))

    def _pad_seal(self):
        text = self.pad_plain_t.get("1.0", "end").rstrip("\n")
        if not text:
            self.status("EMPTY MESSAGE", THEME["warn"])
            return

        def work():
            return nxsec_seal_b64(text, self.pad_pass_e.get())

        def done(token):
            self.pad_token_t.delete("1.0", "end")
            self.pad_token_t.insert("1.0", token)
            self.status("SEALED {} CHARS".format(len(text)), THEME["ok"])
            self.app.store.log("COMMS", "seal-text", "cipher pad",
                               len(token))

        self.run(work, done, busy="SEALING")

    def _pad_open(self):
        token = self.pad_token_t.get("1.0", "end").strip()

        def work():
            return nxsec_open_b64(token, self.pad_pass_e.get())

        def done(text):
            self.pad_plain_t.delete("1.0", "end")
            self.pad_plain_t.insert("1.0", text)
            self.status("TOKEN OPENED", THEME["ok"])
            self.app.store.log("COMMS", "open-text", "cipher pad", "")

        def fail(e):
            self.status("OPEN FAILED", THEME["bad"])

        self.run(work, done, on_error=fail, busy="OPENING")

    # ==== FILE VAULT =========================================
    def _build_vault(self, parent):
        box = tk.Frame(parent, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        box.pack(fill="both", expand=True)
        inner = tk.Frame(box, bg=THEME["panel"])
        inner.pack(fill="both", expand=True, padx=12, pady=12)
        tk.Label(inner, text="FILE VAULT -- .NXSEC SEALED CONTAINERS",
                 bg=THEME["panel"], fg=THEME["glow"],
                 font=(self.app.f_mono, 10, "bold")).pack(anchor="w")
        tk.Label(inner, text="any file -> AES-256 container; container "
                             "-> original file",
                 bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.app.f_mono, 8)).pack(anchor="w", pady=(2, 10))
        row = tk.Frame(inner, bg=THEME["panel"])
        row.pack(fill="x", pady=2)
        tk.Label(row, text="PASSPHRASE", bg=THEME["panel"],
                 fg=THEME["accent"], font=(self.app.f_mono, 8,
                 "bold")).pack(side="left")
        self.vault_pass_e = self.entry(row, width=20, placeholder="vault key")
        self.vault_pass_e.pack(side="left", padx=(8, 0))
        self.vault_pass_e.config(show="*")
        row2 = tk.Frame(inner, bg=THEME["panel"])
        row2.pack(fill="x", pady=(8, 2))
        NeonButton(row2, "SEAL FILE", width=120, height=34,
                   font=(self.app.f_mono, 9, "bold"),
                   command=self._vault_seal).pack(side="left", padx=2)
        NeonButton(row2, "OPEN .NXSEC", width=140, height=34,
                   font=(self.app.f_mono, 9, "bold"),
                   command=self._vault_open).pack(side="left", padx=2)
        self.vault_out = tk.Label(inner, text="--", bg=THEME["panel"],
                                  fg=THEME["dim"],
                                  font=(self.app.f_mono, 8), anchor="w",
                                  justify="left")
        self.vault_out.pack(anchor="w", pady=(6, 0))
        tk.Label(inner, text="pure-python AES: best for files under a few "
                            "MB (configs, notes, exports)",
                 bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.app.f_mono, 7)).pack(anchor="w")

    def _vault_seal(self):
        src = filedialog.askopenfilename(title="FILE TO SEAL")
        if not src:
            return
        if os.path.getsize(src) > 2_000_000 and not messagebox.askyesno(
                "FILE VAULT",
                "file is larger than 2 MB -- pure-python AES will be "
                "slow. continue?"):
            return
        dst = filedialog.asksaveasfilename(title="SAVE SEALED CONTAINER",
                                           defaultextension=".nxsec",
                                           filetypes=[("NXSEC container",
                                                       "*.nxsec")])
        if not dst:
            return

        def work():
            return nxsec_seal_file(src, dst, self.vault_pass_e.get())

        def done(n):
            self.vault_out.config(
                text="SEALED: {} -> {} ({} bytes)".format(
                    os.path.basename(src), os.path.basename(dst), n),
                fg=THEME["ok"])
            self.status("FILE SEALED", THEME["ok"])
            self.app.store.log("COMMS", "seal-file",
                               os.path.basename(src),
                               os.path.basename(dst))

        self.run(work, done, busy="SEALING FILE")

    def _vault_open(self):
        src = filedialog.askopenfilename(
            title="OPEN SEALED CONTAINER",
            filetypes=[("NXSEC container", "*.nxsec"),
                       ("All files", "*.*")])
        if not src:
            return
        dst = filedialog.asksaveasfilename(title="SAVE DECRYPTED FILE",
                                           defaultextension=".bin")
        if not dst:
            return

        def work():
            return nxsec_open_file(src, dst, self.vault_pass_e.get())

        def done(n):
            self.vault_out.config(
                text="OPENED: {} -> {} ({} bytes)".format(
                    os.path.basename(src), os.path.basename(dst), n),
                fg=THEME["ok"])
            self.status("CONTAINER OPENED", THEME["ok"])
            self.app.store.log("COMMS", "open-file",
                               os.path.basename(src),
                               os.path.basename(dst))

        def fail(e):
            self.vault_out.config(text="OPEN FAILED: " + str(e)[:60],
                                  fg=THEME["bad"])
            self.status("OPEN FAILED", THEME["bad"])

        self.run(work, done, on_error=fail, busy="OPENING CONTAINER")


# ============================================================
#  TOOL 14 -- APK SENTINEL  (local AI APK / DEX analyzer)
# ============================================================
#  The flagship module: point it at an APK, the local model
#  (vault/model.nxm) grades how hard that build is to crack,
#  lists every crack-vector (VIP / license / debug / tamper
#  surface) found in the DEX + manifest, and ranks what to fix
#  BEFORE the app is published.
# ============================================================

class ApkPage(BasePage):

    TITLE = "APK SENTINEL"
    SUB = "LOCAL AI MODEL // APK + DEX PROTECTION SCORING"

    def build(self):
        m = model_stats()
        bar = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                       highlightbackground=THEME["accent_dim"])
        bar.pack(fill="x", padx=14, pady=(0, 8))
        inner = tk.Frame(bar, bg=THEME["panel"])
        inner.pack(fill="x", padx=10, pady=10)
        self.path_lbl = tk.Label(inner, text="no APK selected",
                                bg=THEME["panel"], fg=THEME["dim"],
                                font=(self.app.f_mono, 8), anchor="w",
                                width=42)
        self.path_lbl.pack(side="left", fill="x", expand=True)
        NeonButton(inner, "BROWSE", width=90, height=32,
                   font=(self.app.f_mono, 9, "bold"),
                   command=self.pick).pack(side="left", padx=4)
        self.scan_btn = NeonButton(inner, "SCAN", width=90, height=32,
                                   font=(self.app.f_mono, 10, "bold"),
                                   command=self.scan)
        self.scan_btn.pack(side="left", padx=4)
        NeonButton(inner, "EXPORT", width=90, height=32,
                   font=(self.app.f_mono, 9, "bold"),
                   command=self.export).pack(side="left", padx=4)
        tk.Label(inner, text="MODEL: {} v{} | {} RULES / {} CATS | "
                            "vault/{}".format(m["version"], m["name"],
                                             m["rules"], m["categories"],
                                             m["file"]),
                 bg=THEME["panel"], fg=THEME["accent"],
                 font=(self.app.f_mono, 7)).pack(side="left", padx=6)
        self.path = None
        self.report = None

        prog = tk.Frame(self, bg=THEME["panel"], highlightthickness=1,
                        highlightbackground=THEME["accent_dim"])
        prog.pack(fill="x", padx=14, pady=(0, 8))
        pi = tk.Frame(prog, bg=THEME["panel"])
        pi.pack(fill="x", padx=10, pady=8)
        self.stage_lbl = tk.Label(pi, text="IDLE", bg=THEME["panel"],
                                  fg=THEME["dim"],
                                  font=(self.app.f_mono, 8, "bold"))
        self.stage_lbl.pack(side="left")
        self.pct_lbl = tk.Label(pi, text="0%", bg=THEME["panel"],
                                fg=THEME["glow"],
                                font=(self.app.f_mono, 8, "bold"))
        self.pct_lbl.pack(side="right")
        self.pbar = ttk.Progressbar(pi, mode="determinate", maximum=100,
                                    length=420)
        self.pbar.pack(side="left", fill="x", expand=True, padx=8)

        body = tk.Frame(self, bg=THEME["bg"])
        body.pack(fill="both", expand=True, padx=14)
        left = tk.Frame(body, bg=THEME["bg"])
        left.pack(side="left", fill="y", padx=(0, 6))

        # -- score panel --
        sbox = tk.Frame(left, bg=THEME["panel"], highlightthickness=1,
                        highlightbackground=THEME["accent_dim"])
        sbox.pack(fill="x")
        sinner = tk.Frame(sbox, bg=THEME["panel"])
        sinner.pack(fill="x", padx=12, pady=12)
        tk.Label(sinner, text="PROTECTION SCORE", bg=THEME["panel"],
                 fg=THEME["glow"], font=(self.app.f_mono, 9,
                 "bold")).pack(anchor="w")
        gwrap = tk.Frame(sinner, bg=THEME["panel"])
        gwrap.pack(fill="x")
        self.gauge = tk.Canvas(gwrap, width=150, height=110,
                               bg=THEME["panel"], highlightthickness=0)
        self.gauge.pack(side="left", padx=(0, 12))
        gtxt = tk.Frame(gwrap, bg=THEME["panel"])
        gtxt.pack(side="left", fill="both", expand=True)
        self.grade_lbl = tk.Label(gtxt, text="--", bg=THEME["panel"],
                                  fg=THEME["dim"],
                                  font=(self.app.f_ui, 26, "bold"))
        self.grade_lbl.pack(anchor="w")
        self.verdict_lbl = tk.Label(gtxt, text="select an APK and scan",
                                    bg=THEME["panel"], fg=THEME["dim"],
                                    font=(self.app.f_mono, 7),
                                    wraplength=170, justify="left")
        self.verdict_lbl.pack(anchor="w")
        self.cats_cv = tk.Canvas(sinner, bg=THEME["panel"],
                                 highlightthickness=0, height=150,
                                 width=300)
        self.cats_cv.pack(fill="x", pady=(8, 0))

        # -- stats panel --
        stbox = tk.Frame(left, bg=THEME["panel"], highlightthickness=1,
                         highlightbackground=THEME["accent_dim"])
        stbox.pack(fill="both", expand=True, pady=(8, 0))
        st = tk.Frame(stbox, bg=THEME["panel"])
        st.pack(fill="x", padx=12, pady=12)
        tk.Label(st, text="PACKAGE SURFACE", bg=THEME["panel"],
                 fg=THEME["glow"], font=(self.app.f_mono, 9,
                 "bold")).pack(anchor="w")
        self.st_rows = {}
        for key in ("FILE", "SIZE", "SHA-256", "DEX FILES", "DEX SIZE",
                    "STRINGS", "CLASSES", "METHODS", "OBFUSCATION",
                    "NATIVE ABI", "V1 SIGNATURE", "MANIFEST FLAGS"):
            self.st_rows[key] = self.label_pair(st, key)

        # -- right column: crack vectors + findings --
        right = tk.Frame(body, bg=THEME["bg"])
        right.pack(side="left", fill="both", expand=True)

        cvbox = tk.Frame(right, bg=THEME["panel"], highlightthickness=1,
                         highlightbackground=THEME["bad"])
        cvbox.pack(fill="x")
        cinner = tk.Frame(cvbox, bg=THEME["panel"])
        cinner.pack(fill="x", padx=12, pady=(10, 8))
        tk.Label(cinner, text="CRACK VECTORS", bg=THEME["panel"],
                 fg=THEME["bad"], font=(self.app.f_mono, 10,
                 "bold")).pack(anchor="w")
        tk.Label(cinner, text="the exact paths an attacker uses to "
                             "unlock / patch your VIP logic",
                 bg=THEME["panel"], fg=THEME["dim"],
                 font=(self.app.f_mono, 7)).pack(anchor="w")
        self.crack_t = tk.Text(cinner, bg=THEME["panel2"],
                              fg=THEME["bad"],
                              font=(self.app.f_mono, 8), height=4, bd=0,
                              highlightthickness=1,
                              highlightbackground=THEME["accent_dim"],
                              state="disabled", wrap="word")
        self.crack_t.pack(fill="x", pady=(4, 10))

        fbox = tk.Frame(right, bg=THEME["panel"], highlightthickness=1,
                        highlightbackground=THEME["accent_dim"])
        fbox.pack(fill="both", expand=True, pady=(8, 0))
        tk.Label(fbox, text="FINDINGS", bg=THEME["panel"],
                 fg=THEME["glow"], font=(self.app.f_mono, 9, "bold")).pack(
            anchor="w", padx=12, pady=(10, 2))
        wrap = tk.Frame(fbox, bg=THEME["panel"])
        wrap.pack(fill="both", expand=True, padx=12, pady=(2, 4))
        cols = ("sev", "rule", "category", "title")
        self.tree = ttk.Treeview(wrap, columns=cols, show="headings",
                                 height=7)
        for cid, w in (("sev", 74), ("rule", 64), ("category", 130),
                       ("title", 250)):
            self.tree.heading(cid, text=cid.upper())
            self.tree.column(cid, width=w, anchor="w")
        vsb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.tree.pack(side="left", fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._pick)
        self._flattened = []
        self.detail = tk.Text(fbox, bg=THEME["panel2"], fg=THEME["text"],
                              font=(self.app.f_mono, 8), height=8, bd=0,
                              highlightthickness=1,
                              highlightbackground=THEME["accent_dim"],
                              wrap="word")
        self.detail.pack(fill="x", padx=12, pady=(2, 4))

        hist = tk.Frame(right, bg=THEME["panel"], highlightthickness=1,
                        highlightbackground=THEME["accent_dim"])
        hist.pack(fill="x", pady=(6, 0))
        tk.Label(hist, text="SESSION HISTORY", bg=THEME["panel"],
                 fg=THEME["dim"], font=(self.app.f_mono, 8,
                 "bold")).pack(anchor="w", padx=12, pady=(8, 2))
        hwrap = tk.Frame(hist, bg=THEME["panel"])
        hwrap.pack(fill="x", padx=12, pady=(2, 10))
        cols2 = ("file", "score", "grade", "date")
        self.hist = ttk.Treeview(hwrap, columns=cols2, show="headings",
                                 height=3)
        for cid, w in (("file", 200), ("score", 60), ("grade", 60),
                       ("date", 140)):
            self.hist.heading(cid, text=cid.upper())
            self.hist.column(cid, width=w, anchor="w")
        self.hist.pack(fill="x")
        self.hist.bind("<<TreeviewSelect>>", self._hist_pick)

    # ---- interaction ----------------------------------------
    def pick(self):
        path = filedialog.askopenfilename(
            title="SELECT APK / APKS FILE",
            filetypes=[("Android package", "*.apk *.apks"),
                       ("All files", "*.*")])
        if not path:
            return
        if not path.lower().endswith((".apk", ".apks")):
            messagebox.showwarning("APK SENTINEL",
                                   "this tool analyzes .apk packages "
                                   "(split .apks base masters work too)")
        self.path = path
        self.path_lbl.config(text=os.path.basename(path), fg=THEME["glow"])

    def _progress(self, stage, pct):
        self.app.q.put(("ok", lambda v: self._progress_ui(*v),
                       (stage, pct)))

    def _progress_ui(self, stage, pct):
        self.stage_lbl.config(text=stage)
        self.pct_lbl.config(text="{}%".format(pct))
        try:
            self.pbar["value"] = pct
        except Exception:
            pass

    def scan(self):
        if not self.path:
            messagebox.showwarning("APK SENTINEL", "pick an APK first")
            return
        path = self.path
        self._progress_ui("STARTING", 2)

        def work():
            return analyze_apk(path, load_model(), self._progress)

        def done(report):
            self.report = report
            self._render(report)
            self.app.store.add_apk_record(report)
            self.app.store.log("APK", "scan", report["file"],
                               "score {} / grade {}".format(
                                   report["score"], report["grade"]))
            self._refresh_hist()
            self.stage_lbl.config(text="DONE")
            self.status("SCORE {}/100 GRADE {}".format(report["score"],
                                                      report["grade"]),
                        THEME["bad"] if report["score"] < 60
                        else THEME["ok"])

        def fail(e):
            self._progress_ui("FAILED", 0)
            self.status("SCAN FAILED", THEME["bad"])
            messagebox.showerror("APK SENTINEL", str(e)[:200])

        self.run(work, done, on_error=fail, busy="ANALYZING PACKAGE")

    # ---- rendering ------------------------------------------
    def _render(self, report):
        score = report["score"]
        grade = report["grade"]
        color = (THEME["bad"] if score < 50 else
                 THEME["warn"] if score < 75 else THEME["ok"])
        self.gauge.delete("all")
        self.gauge.create_oval(10, 10, 120, 120, outline=THEME["dim"],
                              width=10)
        extent = int(360 * score / 100)
        if extent > 0:
            self.gauge.create_arc(10, 10, 120, 120, start=90,
                                  extent=-extent, style="arc",
                                  outline=color, width=10)
        self.gauge.create_text(65, 65, text=str(score),
                               font=(self.app.f_ui, 24, "bold"),
                               fill=color)
        self.grade_lbl.config(text=grade, fg=color)
        verdict = ("CRACKABLE -- fix the vectors below before "
                   "release" if score < 60 else
                   "HARDENED -- keep hardening" if score < 85 else
                   "WELL PROTECTED build")
        self.verdict_lbl.config(text=verdict, fg=color)
        # category penalty bars
        self.cats_cv.delete("all")
        cats = report.get("cats", {})
        y = 6
        if cats:
            mx = max(v for v in cats.values()) or 1
            for name, val in cats.items():
                self.cats_cv.create_text(0, y + 6, text=name[:24],
                                         anchor="w",
                                         font=(self.app.f_mono, 7),
                                         fill=THEME["dim"])
                w = int(120 * val / mx)
                self.cats_cv.create_rectangle(200, y, 200 + max(w, 2),
                                              y + 12,
                                              fill=THEME["accent_dim"],
                                              outline="")
                self.cats_cv.create_text(330, y + 6,
                                         text="-{}".format(val),
                                         anchor="e",
                                         font=(self.app.f_mono, 7),
                                         fill=THEME["warn"])
                y += 18
        else:
            self.cats_cv.create_text(4, 8, text="no category penalties",
                                     font=(self.app.f_mono, 7),
                                     fill=THEME["ok"], anchor="w")
        # stats
        vals = {
            "FILE": report["file"],
            "SIZE": "{:,} B".format(report["size"]),
            "SHA-256": report["sha256"][:20] + "...",
            "DEX FILES": str(report["dex_count"]),
            "DEX SIZE": "{} MB".format(report["dex_mb"]),
            "STRINGS": "{:,}".format(report["strings_total"]),
            "CLASSES": "{:,}".format(report["classes_total"]),
            "METHODS": "{:,}".format(report["methods_total"]),
            "OBFUSCATION": "{:.0%}".format(report.get("obf_ratio", 0)),
            "NATIVE ABI": ", ".join(report["native_abi"]) or "none",
            "V1 SIGNATURE": "present" if report["signed_v1"]
            else "absent (verify with apksigner)",
            "MANIFEST FLAGS": ", ".join(report["manifest_flags"]) or "-",
        }
        for k, v in vals.items():
            self.st_rows[k].config(text=str(v)[:60])
        # crack vectors
        self.crack_t.config(state="normal")
        self.crack_t.delete("1.0", "end")
        if report["crack"]:
            for c in report["crack"]:
                self.crack_t.insert("end", "[{}] {} -- {}\n".format(
                    c["sev"], c["id"], c["title"]))
        else:
            self.crack_t.insert("end", "no CRITICAL/HIGH crack vectors "
                              "detected\n")
        self.crack_t.config(state="disabled")
        # findings tree
        for w in self.tree.get_children():
            self.tree.delete(w)
        self._flattened = sorted(report["findings"],
                                 key=lambda f: {"CRITICAL": 0, "HIGH": 1,
                                                "MEDIUM": 2,
                                                "INFO": 3}.get(f["sev"], 9))
        sev_col = {"CRITICAL": THEME["bad"], "HIGH": THEME["bad"],
                   "MEDIUM": THEME["warn"], "INFO": THEME["dim"]}
        for f in self._flattened:
            self.tree.insert("", "end", values=(
                f["sev"], f["id"], f["cat"], f["title"]), tags=(f["sev"],))
            self.tree.tag_configure(f["sev"],
                                    foreground=sev_col.get(f["sev"],
                                                           THEME["text"]))
        self.detail.delete("1.0", "end")
        self.detail.insert("1.0", "{} findings -- select a row for the "
                            "full detail + remediation".format(
                                len(self._flattened)))

    def _pick(self, _e=None):
        sel = self.tree.selection()
        if not sel or not self._flattened:
            return
        try:
            f = self._flattened[self.tree.index(sel[0])]
        except IndexError:
            return
        sample = f.get("sample")
        self.detail.delete("1.0", "end")
        lines = ["{} {}  [{}]  ({})".format(f["id"], f["sev"], f["cat"],
                                            f["cat_name"]),
                 "TITLE   : " + f["title"]]
        if sample is not None and str(sample) != "":
            lines.append("SAMPLE  : " + str(sample)[:96])
        lines += ["DETAIL  : " + " ".join(f["detail"].split()),
                  "FIX     : " + " ".join(f["fix"].split())]
        self.detail.insert("1.0", "\n".join(lines))

    def _refresh_hist(self):
        for w in self.hist.get_children():
            self.hist.delete(w)
        for rec in self.app.store.apk_records()[:12]:
            self.hist.insert("", "end", values=(
                rec.get("file", "?"), rec.get("score", "?"),
                rec.get("grade", "?"), rec.get("scanned_at", "")))

    def _hist_pick(self, _e=None):
        sel = self.hist.selection()
        if not sel:
            return
        idx = self.hist.index(sel[0])
        recs = self.app.store.apk_records()
        if idx < len(recs):
            self.report = recs[idx]
            self._render(self.report)

    def on_show(self):
        self._refresh_hist()

    def export(self):
        if not self.report:
            messagebox.showwarning("APK SENTINEL", "scan an APK first")
            return
        path = filedialog.asksaveasfilename(
            title="EXPORT SENTINEL REPORT",
            defaultextension=".txt",
            filetypes=[("Text report", "*.txt"), ("JSON", "*.json"),
                       ("All files", "*.*")])
        if not path:
            return
        if path.lower().endswith(".json"):
            data = json.dumps(self.report, indent=1).encode("utf-8")
        else:
            data = apk_report_text(self.report).encode("utf-8")
        with open(path, "wb") as f:
            f.write(data)
        self.app.store.log("APK", "export", os.path.basename(path),
                           "{} bytes".format(len(data)))
        self.status("REPORT EXPORTED", THEME["ok"])
# ============================================================
#  REGISTRY + ENTRY POINT
# ============================================================

PAGE_CLASSES = {
    "ip": IpPage,
    "nmap": NmapPage,
    "fuzz": FuzzPage,
    "dns": DnsPage,
    "subd": SubdPage,
    "head": HeadersPage,
    "bann": BannerPage,
    "hash": HashPage,
    "enc": EncodePage,
    "mac": MacPage,
    "ping": PingPage,
    "pgen": PassGenPage,
    "log": LogPage,
    "apk": ApkPage,
    "coms": CommsPage,
    "tls": TlsPage,
    "vuln": VulnPage,
    "steg": StegPage,
}


def main():
    app = App()
    app.start_splash()
    app.mainloop()


if __name__ == "__main__":
    main()
